"""Observe existing VT operations around the first multiselect, never replay."""
import json
from pathlib import Path
import re
import resource

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
root = Path('/home/opencode/.cache/opencode-tmp/opencode/vis37-form-current-004')
control = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]|\x1b(?:\]|P|_).*?(?:\x07|\x1b\\)|\x1b.', re.DOTALL)

def tokens(value):
    result, previous = [], 0
    for match in control.finditer(value):
        if match.start() > previous:
            result.append(['print', value[previous:match.start()]])
        result.append(['control', match.group()])
        previous = match.end()
    if previous < len(value):
        result.append(['print', value[previous:]])
    return result

observations = []
for profile in ('small', 'wide', 'tall'):
    for side in ('oc', 'upstream'):
        frames = []
        for stage in ('question-pending', 'question-one-selected', 'question-multiple-selected'):
            base = root / profile / side / ('tool-preview-' + stage)
            vt = base.with_suffix('.vt').read_text()
            grid = json.loads(base.with_suffix('.cells.json').read_bytes())
            ops = tokens(vt)
            frames.append(dict(stage=stage, vt_bytes=base.with_suffix('.vt').stat().st_size,
                               cursor=grid['cursor'], final_operations=ops[-18:]))
        previous = (root / profile / side / 'tool-preview-question-one-selected.vt').read_bytes()
        current = (root / profile / side / 'tool-preview-question-multiple-selected.vt').read_bytes()
        common = 0
        for before, after in zip(previous, current):
            if before != after:
                break
            common += 1
        observations.append(dict(profile=profile, side=side, frames=frames,
                                 previous_is_prefix=current.startswith(previous),
                                 common_vt_prefix_bytes=common))
print(json.dumps(observations, ensure_ascii=False, indent=2))
