#!/usr/bin/env python3
"""Exclusive healthy Settings qualification after the real PTY consumer correction."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/home/opencode/ai/oc')
TMP = Path(os.environ['TMPDIR']) / 'opencode'
ROOT = TMP / 'vis36-mode-current-008'
PROFILES = {'wide': ('cli-wide-r8', 121), 'small': ('cli-small-r8', 79)}
assert os.getuid() == 1003 and sys.argv[1:] and sys.argv[1] in PROFILES
profile, columns = PROFILES[sys.argv[1]]
OWNER = 'T44 VIS42/VIS36 current008: the healthy provider owner data stays admitted but adds no permanent Settings summary; all real pending/failed/catalog/diagnostic routes remain. Current PTY consumer expects the required healthy absence, preserving all nonready and refusal guards. Same CLI auto/root-child/Once-Deny/relaunch at121x40 and79x40. All001007 originals/helpers/bytes/metadata/effects immutable, no replay/mask/tolerance/cursor or clock normalization. Frozen fee0123 successful Shell override unchanged.\n'
if not ROOT.exists():
    ROOT.mkdir()
    with (ROOT / 'owner.txt').open('x') as owner:
        owner.write(OWNER)
assert ROOT.is_dir() and ROOT.stat().st_uid == 1003 and (ROOT / 'owner.txt').read_text() == OWNER
assert not (ROOT / profile).exists()
command = ['node', str(REPO / 'scripts/tui_capture/capture.mjs'),
           '--reference', str(TMP / 't44-reference/package/bin/opencode'),
           '--oc', str(REPO / 'target/debug/oc'), '--build-oc', 'true',
           '--geometry', 'true', '--sample', 'short', '--sidebar', 'hide',
           '--permission', 'true', '--permission-mode', 'auto-cli',
           '--columns', str(columns), '--rows', '40', '--output', str(ROOT / profile)]
env = {**os.environ, 'CARGO_BUILD_JOBS': '3', 'RUST_TEST_THREADS': '2', 'PYTHONDONTWRITEBYTECODE': '1'}
started = time.monotonic_ns()
with (ROOT / (profile + '.log')).open('xb') as log:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
facts = {'command': command, 'exit_code': result.returncode, 'elapsed_ns': time.monotonic_ns() - started}
with (ROOT / (profile + '.json')).open('x') as output:
    json.dump(facts, output, indent=2)
    output.write('\n')
checks = {}
for side in ['upstream', 'oc']:
    path = ROOT / profile / side / 'permission-checks.json'
    if path.exists():
        checks[side] = json.loads(path.read_text())
print(json.dumps({**facts, 'observed_behavior': {s: d['status'] for s, d in checks.items()},
                  'observed_checks': {s: len(d['checks']) for s, d in checks.items()}}))
raise SystemExit(0 if result.returncode in (0, 1) and len(checks) == 2 and
                 all(d['status'] == 'PASS' for d in checks.values()) else 1)
