"""Read-only structured acquisition/effect summary; no replay or product mutation."""
import collections
import json
from pathlib import Path

ROOT = Path('/home/opencode/.cache/opencode-tmp/opencode/vis36-prompt-current-001')
for profile in ('prompt-wide-r1', 'prompt-small-r1'):
    episode = ROOT / profile
    lock = json.loads((episode / 'capture.lock.json').read_bytes())
    result = {'profile': profile, 'captures': len(lock['captures']),
              'comparisons': dict(collections.Counter(i['status'] for i in lock['attempts'])),
              'stages': [i['scenario'] for i in lock['attempts'] if i['mode'] == 'grid'], 'sides': {}}
    for side in ('upstream', 'oc'):
        checks = json.loads((episode / side / 'permission-checks.json').read_bytes())
        protocol = json.loads((episode / side / 'protocol.json').read_bytes())
        events = protocol['events'] if isinstance(protocol, dict) else protocol
        kinds = collections.Counter(i['kind'] for i in events)
        providers = [i for i in events if i['kind'] == 'provider']
        rows = checks['checks']
        snaps = [i for i in rows if 'snapshot' in i]
        proofs = [{k:v for k,v in i.items() if k not in ('snapshot', 'actual_results')}
                  for i in rows if 'proof' in i['stage'] or i['stage'] == 'counts']
        states = []
        for item in snaps:
            snapshot = item['snapshot']
            tables = [o['data'] for o in snapshot['observations']]
            grants = [g for t in tables for g in t.get('permission_grants', t.get('permission', []))]
            operations = [op for t in tables for op in t.get('tool_operations', [])]
            states.append({'stage':item['stage'], 'grants':grants,
                           'operation_states':dict(collections.Counter(op['state'] for op in operations)),
                           'saved_mode':snapshot['cli']['session']['permissions'],
                           'mcp_calls':sum(i['method'] == 'tools/call' for i in snapshot['mcp'])})
        result['sides'][side] = {'status':checks['status'], 'checks':len(rows), 'kinds':dict(kinds),
                                'provider_operations':dict(collections.Counter(i['operation'] for i in providers)),
                                'cases':dict(collections.Counter(i.get('case') for i in providers)),
                                'valid':sum(i['valid'] for i in providers),
                                'tool_cases':dict(collections.Counter(i['case'] for i in events if i['kind'] == 'fixture_tool_call')),
                                'exits':[i for i in events if i['kind'] == 'exit'], 'proofs':proofs,
                                'snapshot_states':states}
    print(json.dumps({k:v for k,v in result.items() if k not in ('sides', 'stages')}))
    print(json.dumps({'stages':result['stages']}))
    for side, facts in result['sides'].items():
        print(json.dumps({'profile':profile, 'side':side, **{k:v for k,v in facts.items() if k not in ('proofs', 'snapshot_states')}}))
        for item in facts['proofs']:
            print(json.dumps({'profile':profile, 'side':side, 'proof':item}))
        for item in facts['snapshot_states']:
            print(json.dumps({'profile':profile, 'side':side, 'snapshot':item}))
