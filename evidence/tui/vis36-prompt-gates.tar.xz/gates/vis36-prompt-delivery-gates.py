"""Exclusive bounded command retention, independently inverted; facts do not rerun a capture."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2,) * 2)
REPO, TMP = Path('/home/opencode/ai/oc'), Path('/home/opencode/.cache/opencode-tmp/opencode')
sys.path.insert(0, str(REPO / 'scripts'))
import archive_failed_capture as storage
import retain_syntax_proof as producer
spec = importlib.util.spec_from_file_location('sealed_prompt_manual', TMP / 'vis37-form-independent-20261012-sole-verifier/owner_refinement.py')
observer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observer)
check = observer.v.inverse
producer.ROOTS = check.ROOTS = {'gates': TMP}
OUT = REPO / 'evidence/tui'
PREFIX = 'vis37-form-gate-vis36-prompt-'
FAILED = {'facts', 'before', 'before-qualified', 'before-bounded', 'before-profile-scope'}
records = {p.name[len(PREFIX):-5]: json.loads(p.read_bytes()) for p in TMP.glob(PREFIX + '*.json')}
assert all(r['exit_code'] == (1 if label in FAILED else 0) for label, r in records.items())
assert 'Ran 71 tests' in Path(records['python']['log']).read_text()
assert all(label in records for label in ('before-verified', 'wide-pack', 'wide-audit', 'small-pack', 'small-audit', 'after'))
before = json.loads((OUT / 'vis36-prompt-before.json').read_bytes())
after = json.loads((OUT / 'vis36-prompt-after.json').read_bytes())
assert after['totals']['pairs'] == 102 and after['totals']['pngs'] == 204
if sys.argv[1:] == ['facts']:
    print(json.dumps(dict(source_sha256=check.producer_sha(before['source_and_elf']['source']), elf=after['source_and_elf']['elf'],
                         totals=after['totals'], preserved_prior_proofs=after['preserved_prior_proofs'],
                         allocated_bytes=storage.owned_allocation(), cap=storage.CAP,
                         headroom_bytes=storage.CAP-storage.owned_allocation(), memory=after['memory'])))
elif sys.argv[1:] == ['pack']:
    assert all(label in records for label in ('docs-final', 'progress-final'))
    paths = [TMP / (PREFIX + label + suffix) for label in records for suffix in ('.json', '.log')]
    paths += [TMP / 'vis36-prompt-facts-r1.py', TMP / 'vis37-form-gate-20261012.py', Path(__file__)]
    files = {'gates/' + p.name: check.read_bytes(p) for p in paths}
    sealed = {'gates/' + p.name: dict(path=str(p), bytes=len(files['gates/' + p.name]), sha256=check.digest(p)) for p in paths}
    encoded, raw_sha, raw_bytes = producer.encode(files, {})
    raw, xz = check.inverse_xz(encoded)
    restored, inverse = check.inverse_ustar(raw, sealed)
    expected = inverse['inventory']
    assert restored == files and check.sha(raw) == raw_sha and len(raw) == raw_bytes
    receipt = dict(version=1, archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=check.sha(raw),
                   tar_bytes=len(raw), inventory=expected, command_labels=sorted(records), helper_sha256=check.digest(Path(__file__)))
    del raw, restored
    archive = OUT / 'vis36-prompt-gates.tar.xz'
    report = OUT / 'vis36-prompt-gates.inventory.json'
    data = (json.dumps(receipt, indent=2) + '\n').encode()
    assert len(encoded) <= producer.MAX_FILE and len(data) <= producer.MAX_FILE
    assert storage.owned_allocation() + sum((len(b)+4095)//4096*4096 for b in (encoded, data)) <= storage.CAP
    storage.durable(archive, encoded)
    storage.durable(report, data)
    raw, xz = check.inverse_xz(check.read_bytes(archive))
    restored, inverse = check.inverse_ustar(raw, sealed)
    assert restored == files and inverse['inventory'] == expected and check.digest(archive) == receipt['archive_sha256']
    assert storage.owned_allocation() <= storage.CAP
    print(json.dumps(dict(status='FULL_COMMAND_BYTES_MANUAL_INVERSE', archive=receipt,
                         allocated_bytes=storage.owned_allocation(), headroom_bytes=storage.CAP-storage.owned_allocation(), memory=check.proc_memory())))
else:
    raise SystemExit('facts or pack; outputs are exclusive')
