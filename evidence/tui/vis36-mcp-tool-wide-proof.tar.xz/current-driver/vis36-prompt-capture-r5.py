"""Fresh, exclusive Prompt005 after the test-only strict-Clippy correction."""
import ast
from pathlib import Path

SOURCE = Path('/home/opencode/.cache/opencode-tmp/opencode/vis36-prompt-capture-r4.py')
tree = ast.parse(SOURCE.read_bytes(), filename=str(SOURCE))
replacements = {'vis36-prompt-current-004': 'vis36-prompt-current-005',
                'prompt-wide-r4': 'prompt-wide-r5', 'prompt-small-r4': 'prompt-small-r5'}
hits = {key: 0 for key in replacements}
for node in ast.walk(tree):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        if node.value in replacements:
            hits[node.value] += 1
            node.value = replacements[node.value]
        elif node.value.startswith('T44 VIS36 typed generic Tool(action) qualification.'):
            node.value += 'Fresh Prompt005 follows a test-only cloned-slice Clippy correction; Prompt004, its driver and independent BEFORE remain historical and immutable.\n'
assert set(hits.values()) == {1}
exec(compile(tree, str(SOURCE), 'exec'))
