"""Read-only independent inverse of historical form bytes and current gate bytes."""
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys

sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
REPO = Path('/home/opencode/ai/oc')
HERE = TMP / 'vis37-form-independent-20261012-sole-verifier'
spec = importlib.util.spec_from_file_location('historical_independent_inverse', HERE / 'verifier.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
check = old.inverse
check.require(os.getuid() == 1003, 'dedicated non-root owner')
before = check.load(HERE / 'before.json')
check.require(old.inventory() == before['originals'], 'all001/002/003 original bytes and directory metadata preserved')
archive = REPO / 'evidence/tui/vis37-form-proof.tar.xz'
receipt = check.load(REPO / 'evidence/tui/vis37-form-proof.inventory.json')
raw, xz = check.inverse_xz(check.read_bytes(archive))
restored, inverse = check.inverse_ustar(raw, before['originals']['files'])
check.require(check.digest(archive) == receipt['archive_sha256'] and check.sha(raw) == receipt['tar_sha256']
              and inverse['inventory'] == receipt['inventory'], 'historical complete inverse matches frozen inventory')
result = {'status': 'INDEPENDENT_HISTORICAL_FORM_AND_CURRENT_GATE_BYTES_ONLY_T44_NOT_PASS',
          'historical_form': {'files': len(restored), 'inventory': inverse['inventory'],
              'archive_sha256': receipt['archive_sha256'], 'all_original_metadata_unchanged': True,
              'scope': '001/002/003 bytes only; 003 source is now historical, no current-source promotion'}}
del restored, inverse, raw
gate_receipt = check.load(REPO / 'evidence/tui/vis37-form-gates.inventory.json')
expected = {}
for fact in gate_receipt['gates']:
    for suffix in ('.json', '.log'):
        name = 'vis37-form-gate-' + fact['label'] + suffix
        path = TMP / name
        expected['gates/' + name] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': check.digest(path)}
for label in ('r4-measure-default-detailed', 'r4-measure-strong', 'r4-independent-recount'):
    for suffix in ('.json', '.log'):
        name = 'vis37-form-gate-' + label + suffix
        path = TMP / name
        expected['gates/' + name] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': check.digest(path)}
for name in ('vis37-form-retain-gates-20261012.py', 'vis37-form-gate-20261012.py'):
    path = TMP / name
    expected['gates/' + name] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': check.digest(path)}
check.ROOTS = {'gates': TMP}
archive = REPO / 'evidence/tui/vis37-form-gates.tar.xz'
raw, xz = check.inverse_xz(check.read_bytes(archive))
restored, inverse = check.inverse_ustar(raw, expected)
check.require(len(restored) == gate_receipt['files'] == 52 and check.sha(raw) == gate_receipt['tar_sha256']
              and check.digest(archive) == gate_receipt['archive_sha256'] and not inverse['alias_rows'], 'complete current gate inverse')
result['current_gates'] = {'files': len(restored), 'archive_sha256': gate_receipt['archive_sha256'],
                         'inventory': inverse['inventory'], 'xz': xz}
result['helper_sha256'] = check.digest(Path(__file__))
result['memory'] = check.proc_memory()
result['scope'] = 'No004 capture archive or inverse exists; current code gates do not waive full pixel/effect/final R6/V09 acceptance.'
data = (json.dumps(result, indent=2) + '\n').encode()
output = TMP / 'vis37-form-delivery-inverse-20261012.json'
check.require(len(data) <= check.FILE, 'bounded independent receipt')
with output.open('xb') as stream:
    stream.write(data)
    stream.flush()
    os.fsync(stream.fileno())
print(json.dumps({'output': str(output), 'bytes': len(data), 'sha256': check.sha(data),
                  'historical_members': result['historical_form']['files'], 'gate_members': len(restored),
                  'memory': result['memory']}, sort_keys=True))
