#!/usr/bin/env python3
"""Independent, no-extraction inverse of the already sealed VIS37 campaign."""
import resource
import sys

sys.dont_write_bytecode = True
AS, FILE, TOTAL, OWNED = 384 * 1024**2, 16 * 1024**2, 128 * 1024**2, 1024**3
MEMBERS, XZ_DICT, XZ_DECODE = 2000, 16 * 1024**2, 32 * 1024**2
resource.setrlimit(resource.RLIMIT_AS, (AS, AS))
resource.setrlimit(resource.RLIMIT_FSIZE, (FILE, FILE))

import ast
import base64
import collections
import ctypes
import functools
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import subprocess
import time
import zlib
from PIL import Image

REPO = Path('/home/opencode/ai/oc')
TEMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
HERE = TEMP / 'vis37-independent-20261012-sole-verifier'
ARCHIVE = REPO / 'evidence/tui/vis37-proof.tar.xz'
RECEIPT = REPO / 'evidence/tui/vis37-proof.inventory.json'
CURRENT, OLD = TEMP / 'vis37-current-002', TEMP / 'vis37-current-001'
HEAD = 'c5adde0f7c8bab926592fb885a98c47c09da74e3'
DONOR = '2670273ff17da96f85c5826ced57aa1b368754fa'
INITIAL_HELPER_SHA = '052acc768f2952b8c3521bcd621e13277680913a5c4379813663a588682e06f7'
INITIAL_REPORT_SHA = '37ce01eec0be76b2379da1a8f9db6ab59ff9ced3d4fd7a9695b6028ce5499d37'
ROOTS = {'failed-wide': OLD/'wide', 'current-small': CURRENT/'small',
         'current-wide': CURRENT/'wide', 'current-tall': CURRENT/'tall',
         'failed-logs': OLD, 'current-logs': CURRENT,
         'failed-driver': TEMP/'vis37-capture.py', 'current-driver': TEMP/'vis37-capture-r2.py'}
PROFILES = {'small': (80,24), 'wide': (120,40), 'tall': (160,48)}
SCOPE = ['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates','scripts/tui_capture',
         'tui-recovery/scripts/compare_frames.py','tui-recovery/scripts/test_compare_frames.py']
STAGES = ('question-home question-pending question-one-selected question-multiple-selected '
          'question-long-field question-custom-empty question-custom-edited question-review '
          'question-completed question-answered-card question-switched question-reopened '
          'question-restarted question-cancel-pending question-dismissed question-cancel-switched '
          'question-cancel-reopened').split()
FIELDS = {'symbol','fg','bg','modifiers','width'}
PROMPT = 'VIS37 paired question consumer'
CANCEL = 'VIS37 dismiss the next question'
DONE = 'VIS37-DONE: owned answers accepted.'
ANSWERS = [['Rust','Python'],['custom Ω界']]
# Independent literal contract, never imported from a producer/retainer.
QUESTIONS = {'questions': [
    {'header':'Languages and native runtimes','question':'Pick languages?','multiple':True,
     'options':[{'label':'Rust','description':'Native owner and a bounded ordered answer.'},
                {'label':'Python','description':'Fixture peer, not a production runtime dependency.'}]},
    {'header':'Platform and execution targets','multiple':False,
     'question':'Where Ω界? Choose an explicit host for the current workspace and retain this long question in metadata order.',
     'options':[{'label':'Linux','description':'Current GNU/Linux host, with no external service or paid effect.'},
                {'label':'Other','description':'An explicit custom selection remains owned by this question.'}]}]}
DONOR_RESULT = 'User has answered your questions: ' + ', '.join(
    '"'+q['question']+'"="'+', '.join(a)+'"' for q,a in zip(QUESTIONS['questions'],ANSWERS,strict=True)
) + ". You can now continue with the user's answers in mind."
PREFIXES = ('model-shell','subagent','root-','syntax-','write-','wrap-','hover-','raster-',
            'caret-','blink-','mcp-label-','shell-wrap-','middle-tabs-','rail-width-',
            'compact-layout-','compact-controls-','vis12-','vis37-')


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(1024**2):
            h.update(block)
    return h.hexdigest()


def read_bytes(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= FILE, 'bounded regular input: '+str(path))
    return path.read_bytes()


def load(path):
    return json.loads(read_bytes(path))


def canonical_sha(value):
    return sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())


def metadata(path):
    s = Path(path).lstat()
    require(s.st_uid == os.getuid() and not Path(path).is_symlink(), 'owned non-symlink original')
    return [s.st_size,s.st_mode,s.st_uid,s.st_gid,s.st_dev,s.st_ino,s.st_mtime_ns]


def git(*args):
    p = subprocess.run(['git','--no-optional-locks','-c','core.preloadIndex=false',*args],
                       cwd=REPO,capture_output=True,timeout=30)
    require(p.returncode == 0 and len(p.stdout) <= FILE, 'bounded read-only Git')
    return p.stdout


def producer_sha(value):
    # Match the captured JavaScript localeCompare canonicalization, using ICU only.
    lib = ctypes.CDLL('/usr/lib/x86_64-linux-gnu/libicui18n.so.76.1')
    op = lib.ucol_open_76
    op.argtypes,op.restype = [ctypes.c_char_p,ctypes.POINTER(ctypes.c_int32)],ctypes.c_void_p
    error = ctypes.c_int32(0)
    collator = op(b'en_US',ctypes.byref(error))
    require(collator and error.value <= 0, 'ICU producer-order collator')
    cmp = lib.ucol_strcollUTF8_76
    cmp.argtypes = [ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int32,ctypes.c_char_p,ctypes.c_int32,ctypes.POINTER(ctypes.c_int32)]
    cmp.restype = ctypes.c_int
    close = lib.ucol_close_76
    close.argtypes = [ctypes.c_void_p]
    def compare(a,b):
        a,b = a.encode(),b.encode()
        result = cmp(collator,a,len(a),b,len(b),ctypes.byref(error))
        require(error.value <= 0, 'successful ICU collation')
        return result
    def order(v):
        if isinstance(v,dict):
            return {k:order(v[k]) for k in sorted(v,key=functools.cmp_to_key(compare))}
        return [order(i) for i in v] if isinstance(v,list) else v
    try:
        return sha(json.dumps(order(value),ensure_ascii=False,separators=(',',':')).encode())
    finally:
        close(collator)


def proc_memory():
    fields = {}
    for line in Path('/proc/self/status').read_text().splitlines():
        key,_,value = line.partition(':')
        if key in ('VmPeak','VmSize','VmHWM','VmRSS'):
            parts = value.split()
            require(len(parts) == 2 and parts[1] == 'kB', 'actual process memory units')
            fields[key+'_bytes'] = int(parts[0])*1024
    require(len(fields) == 4 and fields['VmPeak_bytes'] <= AS, 'actual /proc memory within hard AS')
    return fields


def quota():
    # Metadata-only accounting; none of these historical files are byte-audited.
    seen,allocated = set(),0
    for root in (REPO/'evidence/tui').iterdir():
        if not root.name.startswith(PREFIXES):
            continue
        for p in [root,*root.rglob('*')] if root.is_dir() else [root]:
            s = p.lstat()
            require(not p.is_symlink(), 'quota does not follow links')
            key = s.st_dev,s.st_ino
            if key not in seen:
                seen.add(key)
                allocated += s.st_blocks*512
    require(allocated <= OWNED, 'established evidence/tui allocation <=1GiB')
    return {'allocated_bytes':allocated,'quota_bytes':OWNED,'headroom_bytes':OWNED-allocated,
            'stat_only_unique_inodes':len(seen),'prefixes':list(PREFIXES),
            'scope':'Only established evidence/tui prefixes including vis37-; TMP excluded; not a historical byte audit'}


def tmp_allocation():
    return {'directory':str(HERE),'allocated_bytes':sum(p.stat().st_blocks*512 for p in [HERE,*HERE.iterdir()]),
            'logical_file_bytes':sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()),
            'scope':'Independent verifier scratch only, separately reported and not charged to owned evidence quota'}


def preservation(initial, compare_bytes=True):
    files,records,total,members = {},{},0,0
    for root_name,inventory in initial['byte_and_metadata_preservation'].items():
        root = Path(root_name)
        actual = [root,*sorted(root.rglob('*'))] if root.is_dir() else [root]
        rows = inventory['rows']
        require(len(actual) == len(rows) and canonical_sha(rows) == inventory['bytes_and_metadata_sha256'], 'sealed original row membership')
        for path,row in zip(actual,rows,strict=True):
            rel = path.relative_to(root).as_posix() if path != root else '.'
            require(rel == row[0] and path.is_dir() is row[1] and metadata(path) == row[2:9], 'exact pre-pack original metadata: '+str(path))
            members += 1
            if row[1]:
                require(row[9] is None, 'directory has no invented content seal')
                continue
            require(row[2] <= FILE and digest(path) == row[9], 'original input still sealed: '+str(path))
            if root == CURRENT or root == OLD:
                parts = PurePosixPath(rel).parts
                if len(parts) == 1:
                    key = ('current-logs' if root == CURRENT else 'failed-logs')+'/'+rel
                elif root == OLD:
                    require(parts[0] == 'wide', 'only failed wide episode')
                    key = 'failed-wide/'+'/'.join(parts[1:])
                else:
                    require(parts[0] in PROFILES, 'only three current episodes')
                    key = 'current-'+parts[0]+'/'+'/'.join(parts[1:])
            else:
                require(root in (ROOTS['failed-driver'],ROOTS['current-driver']), 'only sealed parent helper roots')
                key = ('failed-driver' if root == ROOTS['failed-driver'] else 'current-driver')+'/'+root.name
            require(key not in files, 'no duplicate parent/episode original')
            files[key] = {'path':str(path),'bytes':row[2],'sha256':row[9],'original_metadata':row[2:9]}
            total += row[2]
        records[root_name] = {k:v for k,v in inventory.items() if k != 'rows'}
    require(len(files) <= MEMBERS and total <= TOTAL and members <= MEMBERS, 'original selected campaign bounds')
    return files,{'files':len(files),'directories':members-len(files),'members_in_initial_inventory':members,
                  'logical_bytes':total,'roots':records,'original_inventory_seal':canonical_sha(initial['byte_and_metadata_preservation'])}


def vli(buf,pos,end):
    value = 0
    for i in range(9):
        require(pos < end, 'complete XZ VLI')
        b = buf[pos]
        pos += 1
        value |= (b&127) << (7*i)
        if not b&128:
            require(i == 0 or b != 0, 'canonical minimally encoded XZ VLI')
            return value,pos
    raise AssertionError('XZ VLI exceeds 63 bits')


def inverse_xz(encoded):
    require(24 <= len(encoded) <= FILE and encoded[:6] == b'\xfd7zXZ\0', 'bounded actual XZ header')
    flags = encoded[6:8]
    require(flags == b'\0\x0a' and zlib.crc32(flags) == struct.unpack_from('<I',encoded,8)[0], 'SHA256 stream flags/header CRC')
    footer = encoded[-12:]
    require(footer[-2:] == b'YZ' and footer[8:10] == flags and
            zlib.crc32(footer[4:10]) == struct.unpack_from('<I',footer)[0], 'matching XZ footer flags/CRC')
    index_size = (struct.unpack_from('<I',footer,4)[0]+1)*4
    index_start = len(encoded)-12-index_size
    require(index_start >= 12 and index_size >= 8 and index_size%4 == 0, 'footer backward index size')
    index = encoded[index_start:len(encoded)-12]
    require(index[0] == 0 and zlib.crc32(index[:-4]) == struct.unpack_from('<I',index,len(index)-4)[0], 'XZ Index indicator/CRC')
    count,pos = vli(index,1,len(index)-4)
    require(1 <= count <= MEMBERS, 'bounded nonempty XZ block count')
    pairs = []
    for _ in range(count):
        packed,pos = vli(index,pos,len(index)-4)
        unpacked,pos = vli(index,pos,len(index)-4)
        require(packed > 0 and 0 < unpacked <= TOTAL, 'bounded indexed block sizes')
        pairs.append((packed,unpacked))
    require(len(index)-4-pos <= 3 and not any(index[pos:-4]), 'canonical zero XZ index padding')
    require(sum(u for _,u in pairs) <= TOTAL, 'indexed TAR <=128MiB before decode')
    offset,blocks,max_dict = 12,[],0
    for packed,unpacked in pairs:
        require(offset < index_start and encoded[offset] != 0, 'actual XZ block header')
        header_size = (encoded[offset]+1)*4
        header = encoded[offset:offset+header_size]
        require(len(header) == header_size and header_size >= 8 and
                zlib.crc32(header[:-4]) == struct.unpack_from('<I',header,header_size-4)[0], 'block header size/CRC')
        block_flags = header[1]
        require(block_flags&0x3f == 0, 'single filter and no reserved block flags')
        cursor,declared_packed,declared_unpacked = 2,None,None
        if block_flags&0x40:
            declared_packed,cursor = vli(header,cursor,header_size-4)
        if block_flags&0x80:
            declared_unpacked,cursor = vli(header,cursor,header_size-4)
        filter_id,cursor = vli(header,cursor,header_size-4)
        props_size,cursor = vli(header,cursor,header_size-4)
        require(filter_id == 0x21 and props_size == 1 and cursor < header_size-4, 'only one LZMA2 filter/property')
        prop = header[cursor]
        cursor += 1
        require(prop <= 40 and not any(header[cursor:-4]), 'valid dictionary property and canonical header padding')
        dictionary = 0xffffffff if prop == 40 else (2|(prop&1)) << (prop//2+11)
        require(dictionary <= XZ_DICT, 'LZMA2 dictionary <=16MiB')
        max_dict = max(max_dict,dictionary)
        compressed_size = packed-header_size-32
        padded_size = (packed+3)//4*4
        require(compressed_size > 0 and offset+padded_size <= index_start and
                (declared_packed is None or declared_packed == compressed_size) and
                (declared_unpacked is None or declared_unpacked == unpacked), 'exact indexed block extent/optional sizes')
        compressed_end = offset+header_size+compressed_size
        check_start = offset+padded_size-32
        require(check_start-compressed_end in range(4) and not any(encoded[compressed_end:check_start]), 'canonical block alignment padding')
        blocks.append({'offset':offset,'header_bytes':header_size,'unpadded_bytes':packed,
                       'uncompressed_bytes':unpacked,'dictionary_bytes':dictionary,
                       'check_sha256':encoded[check_start:check_start+32].hex()})
        offset += padded_size
    require(offset == index_start, 'all indexed blocks exactly precede single index')
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=XZ_DECODE)
    raw = decoder.decompress(encoded,max_length=TOTAL+1)
    require(decoder.eof and decoder.check == lzma.CHECK_SHA256 and not decoder.unused_data and
            len(raw) == sum(u for _,u in pairs) <= TOTAL, 'complete single SHA256-checked XZ, no trailing bytes/concatenation')
    start = 0
    for block in blocks:
        end = start+block['uncompressed_bytes']
        require(sha(memoryview(raw)[start:end]) == block['check_sha256'], 'independent block SHA256 check')
        start = end
    return raw,{'blocks':blocks,'single_stream':True,'sha256_check':True,'footer_index_and_header_crcs':True,
                'no_trailing_bytes':True,'max_dictionary_bytes':max_dict,'decoder_memlimit_bytes':XZ_DECODE,
                'index_bytes':index_size,'index_offset':index_start}


def cstring(field):
    split = field.find(b'\0')
    require(split >= 0 and not any(field[split:]), 'canonical zero-padded USTAR string')
    return field[:split].decode('ascii')


def octal(field):
    require(field[-1:] == b'\0' and all(c in b'01234567' for c in field[:-1]), 'canonical zero-padded USTAR octal')
    return int(field[:-1],8)


def make_header(name,size,target):
    # Construct the canonical USTAR header directly, without tarfile or retainer.
    b = bytearray(512)
    require(len(name.encode('ascii')) < 100 and len(target.encode('ascii')) < 100, 'short canonical USTAR paths')
    b[:len(name)] = name.encode('ascii')
    for offset,width,value in ((100,8,0o644),(108,8,0),(116,8,0),(124,12,size),(136,12,0)):
        encoded = f'{value:0{width-1}o}'.encode()+b'\0'
        require(len(encoded) == width, 'USTAR numeric width')
        b[offset:offset+width] = encoded
    b[148:156] = b' '*8
    b[156:157] = b'1' if target else b'0'
    b[157:157+len(target)] = target.encode('ascii')
    b[257:265] = b'ustar\00000'
    checksum = sum(b)
    b[148:156] = f'{checksum:06o}'.encode()+b'\0 '
    return bytes(b)


def path_ok(name):
    p = PurePosixPath(name)
    require(not p.is_absolute() and p.as_posix() == name and '\0' not in name and
            all(part not in ('','.','..') for part in name.split('/')) and len(p.parts) >= 2 and p.parts[0] in ROOTS,
            'confined archive path')
    return p


def inverse_ustar(raw,expected):
    buf,files,aliases,headers = memoryview(raw),{},{},[]
    offset,stored = 0,0
    while offset+512 <= len(raw) and any(buf[offset:offset+512]):
        require(len(files) < MEMBERS, 'TAR member bound')
        header = bytes(buf[offset:offset+512])
        name,target = cstring(header[:100]),cstring(header[157:257])
        path_ok(name)
        require(name in expected and name not in files, 'exact independent sealed member set, no duplicates')
        require(header[156:157] in (b'0',b'1'), 'only regular files or direct PNG aliases; no directory/PAX/GNU/special members')
        size = octal(header[124:136])
        require(size <= FILE and header == make_header(name,size,target), 'entire canonical USTAR header/checksum: '+name)
        offset += 512
        require(offset+size <= len(raw), 'complete member content')
        if target:
            a,b = path_ok(name),path_ok(target)
            require(size == 0 and a.parts[:2] == b.parts[:2] and a.parts[1] in ('oc','upstream') and
                    name.endswith('.png') and target.endswith('.png') and target in files and target not in aliases,
                    'direct preceding same-run/same-side PNG alias only')
            files[name],aliases[name] = files[target],target
        else:
            files[name] = buf[offset:offset+size]
            padding = (-size)%512
            require(not any(buf[offset+size:offset+size+padding]), 'zero member alignment bytes')
            offset += size+padding
            stored += size
        record = expected[name]
        require(len(files[name]) == record['bytes'] and sha(files[name]) == record['sha256'] and
                files[name] == read_bytes(record['path']), 'every original file byte exactly restored: '+name)
        headers.append({'name':name,'stored_bytes':size,'logical_bytes':len(files[name]),
                        'sha256':sha(files[name]),'alias_target':target or None,'header_sha256':sha(header)})
    require(set(files) == set(expected), 'complete829 member inverse, no omission/addition')
    end_bytes = len(raw)-offset
    require(len(raw)%10240 == 0 and end_bytes >= 1024 and not any(buf[offset:]) and
            len(raw) == ((offset+1024+10239)//10240)*10240, 'two TAR end blocks, canonical record padding, no trailing stream')
    suffixes = ('.cells.json','.png','.render.json','.vt','.txt','.trace.json')
    ordering = lambda name: (next((i for i,s in enumerate(suffixes) if name.endswith(s)),len(suffixes)),name.rsplit('/',1)[-1],name)
    require([r['name'] for r in headers] == sorted(files,key=ordering), 'canonical stable whole-file archive order')
    first,expected_aliases = {},{}
    for name in sorted(files):
        if not name.endswith('.png'):
            continue
        p = path_ok(name)
        key = p.parts[:2],sha(files[name])
        if key in first:
            require(files[name] == files[first[key]], 'PNG alias exact encoded bytes')
            expected_aliases[name] = first[key]
        else:
            first[key] = name
    require(aliases == expected_aliases, 'all and only canonical original same-run/side PNG aliases')
    logical = sum(map(len,files.values()))
    require(logical <= TOTAL, 'logical expanded alias bytes <=128MiB')
    rows = [[n,len(files[n]),sha(files[n]),aliases.get(n)] for n in sorted(files)]
    inventory = {'members':len(files),'logical_bytes':logical,'member_inventory_sha256':sha(json.dumps(rows,separators=(',',':')).encode()),
                 'same_side_png_aliases':len(aliases)}
    return files,{'inventory':inventory,'stored_regular_members':len(files)-len(aliases),'stored_payload_bytes':stored,
                  'tar_end_padding_bytes':end_bytes,'canonical_ustar_headers':True,'member_rows':headers,
                  'alias_rows':aliases,'no_directory_members':True,'no_extraction':True,
                  'metadata_scope':'Canonical archive headers mode0644/uid0/gid0/mtime0; original loose metadata independently unchanged versus initial sealed report'}


def archived(files,episode,name):
    return json.loads(bytes(files[episode+'/'+name]))


def compare_grid(a,b):
    require(a['origin'] == 'upstream' and b['origin'] == 'oc', 'actual distinct capture origins')
    for k in ('schema_version','scenario','fixture_sha256','environment_id','columns','rows'):
        require(a[k] == b[k], 'same full styled-grid contract: '+k)
    require(a['producer_commit'] == DONOR and b['producer_commit'] == HEAD, 'pinned producer identities')
    w,h = a['columns'],a['rows']
    require(len(a['cells']) == len(b['cells']) == h, 'full grid rows')
    diffs,fields = [],collections.Counter()
    for y,(ar,br) in enumerate(zip(a['cells'],b['cells'],strict=True)):
        require(len(ar) == len(br) == w, 'full grid columns')
        for x,(ac,bc) in enumerate(zip(ar,br,strict=True)):
            require(set(ac) == set(bc) == FIELDS, 'all five styled-cell fields')
            if ac != bc:
                changed = sorted(k for k in FIELDS if ac[k] != bc[k])
                diffs.append({'x':x,'y':y,'different_fields':changed})
                fields.update(changed)
    box = [min(d['x'] for d in diffs),min(d['y'] for d in diffs),max(d['x'] for d in diffs),max(d['y'] for d in diffs)] if diffs else None
    return {'cells_checked':w*h,'different_cells':len(diffs),'cursor_differs':a['cursor'] != b['cursor'],
            'difference_bbox_inclusive':box,'different_fields':dict(fields)},diffs


def decode_png(data):
    with Image.open(io.BytesIO(data)) as im:
        require(im.format == 'PNG' and im.n_frames == 1 and im.width*im.height*4 <= FILE, 'bounded whole single PNG')
        rgba = im.convert('RGBA')
        require(rgba.getextrema()[3] == (255,255), 'whole captured PNG fully opaque')
        return rgba.size,rgba.tobytes()


def compare_png(a,b):
    size,ab = decode_png(a)
    size_b,bb = decode_png(b)
    require(size == size_b, 'entire paired PNG dimensions')
    w,h = size
    count,left,top,right,bottom = 0,w,h,-1,-1
    for i in range(0,len(ab),4):
        if ab[i:i+4] != bb[i:i+4]:
            count += 1
            x,y = (i//4)%w,(i//4)//w
            left,top,right,bottom = min(left,x),min(top,y),max(right,x),max(bottom,y)
    return {'width':w,'height':h,'pixels_checked':w*h,'different_pixels':count,
            'difference_bbox_inclusive':[left,top,right,bottom] if count else None}


def card_owner(grids,diffs):
    positions = {}
    for side,g in grids.items():
        rows = [''.join(c['symbol'] for c in row) for row in g['cells']]
        title = [i for i,s in enumerate(rows) if '# Questions' in s]
        require(len(title) == 1, 'unique answered card owner')
        answers = [i for i,s in enumerate(rows) if 'custom Ω' in s and i > title[0]]
        require(len(answers) == 1, 'complete real Unicode answer')
        start,end = title[0]-1,answers[0]+1
        positions[side] = {'top':start,'bottom':end,'rows':rows[start:end+1]}
    require(positions['oc'] == positions['upstream'], 'answered owner geometry/symbols/order/spacing/wrap')
    owner = [d for d in diffs if positions['oc']['top'] <= d['y'] <= positions['oc']['bottom']]
    details = [{**d,'reference':grids['upstream']['cells'][d['y']][d['x']],
                'actual':grids['oc']['cells'][d['y']][d['x']]} for d in owner]
    require(all(d['reference']['symbol'].strip() == d['actual']['symbol'].strip() == '' for d in details), 'only blank-styled owner residuals')
    return {'owner_rows':positions,'owner_differences':details,'styled_cell_differences_in_owner_rows':len(owner),
            'visible_whole_card_geometry_aligned':True,'full_visible_card_symbols_equal':True,
            'all_nonblank_card_glyph_styled_cells_equal':True,'diagnostic_only_no_crop_or_comparator_mask':True}


def side_facts(files,episode,side,lock,initial_facts):
    read = lambda n: archived(files,episode,side+'/'+n)
    checks,protocol,inputs,spec = (read(n) for n in ('tool-preview-checks.json','protocol.json','inputs.json','bridge-spec.json'))
    require(checks == lock['tool_preview'][side] and checks['status'] == 'PASS_BEHAVIOR_ONLY', 'current behavior-only side status')
    require([s['stage'] for s in checks['stages']] == STAGES and
            [s['requests'] for s in checks['stages']] == [0]+[2]*7+[3]*5+[4]*4 and
            [s['calls'] for s in checks['stages']] == [0]+[1]*12+[2]*4, 'owned stage generation/no editing/review/reopen/restart requests')
    providers = [e for e in protocol if e['kind'] == 'provider']
    require(providers == initial_facts['providers'] and len(providers) == 4 and all(p['valid'] is True for p in providers), 'all four original valid requests')
    require(collections.Counter(p['operation'] for p in providers) == {'question_main':3,'question_title':1} and
            collections.Counter(p['operation'] for p in protocol if p['kind'] == 'provider_completed') ==
            collections.Counter(p['operation'] for p in providers), 'exact completed main/title counts')
    mains = [p for p in providers if p['operation'] == 'question_main']
    require([p['index'] for p in mains] == [1,2,3] and all(p['registered_tools'] == ['question'] for p in mains) and
            [p['user_texts'] for p in mains] == [[PROMPT],[PROMPT],[PROMPT,CANCEL]], 'exact observed users and question-only catalog')
    require(mains[0]['actual_results'] == [] and mains[1]['actual_results'] == mains[2]['actual_results'], 'only explicit accepted result, unchanged on second intentional turn')
    calls = [e for e in protocol if e['kind'] == 'fixture_tool_call']
    require([e['call_id'] for e in calls] == ['call_vis37_answer','call_vis37_cancel'] and
            all(e['name'] == 'question' and e['arguments'] == QUESTIONS for e in calls), 'literal full typed question inputs')
    results = mains[1]['actual_results']
    require(len(results) == 1 and results[0]['type'] == 'function_call_output' and results[0]['call_id'] == 'call_vis37_answer', 'bound typed wire output')
    output = results[0]['output']
    require(output == initial_facts['wire_output'] and sha(output.encode()) == initial_facts['wire_output_sha256'], 'initial wire string byte-exact')
    if side == 'oc':
        require(json.loads(output) == {**QUESTIONS,'answers':ANSWERS} and len(output.encode()) == 716, 'complete native typed QuestionResult')
    else:
        require(output == DONOR_RESULT, 'actual donor canonical toModelContent')
    snapshots = [e for e in protocol if e['kind'] == 'tool_preview_snapshot']
    require([s['request_id'] for s in snapshots] == ['question_completed','question_reopened','question_restarted','question_dismissed','question_cancel_reopened'], 'exact five recorded snapshots')
    require(snapshots[0]['observations'] == snapshots[1]['observations'] == snapshots[2]['observations'] and
            snapshots[3]['observations'] == snapshots[4]['observations'], 'unchanged durable/RAW observations across actual reopen/restart/dismissed reopen')
    require([canonical_sha(s['observations']) for s in snapshots] == initial_facts['full_source_observation_seals'], 'initial complete source observation seals')
    facts = checks['question_forms']
    require([facts[k] for k in ('completed','reopened','restarted','dismissed','final')] == snapshots, 'facts are actual protocol observations')
    raw,operations_final = [],[]
    for i,s in enumerate(snapshots):
        require(s['artifacts'] == {} and s['shell_effect'] is None and s['mcp_calls'] == s['mcp_lifecycle'] == [], 'no observed extra project/Shell/MCP effects')
        records = [o['data']['question_records'] for o in s['observations'] if 'question_records' in o['data']]
        require(len(records) == 1 and records[0]['readonly'] is True, 'captured actual readonly SQL source')
        records = records[0]
        operations = records['operations']
        require(len(operations) == (1 if i < 3 else 2), 'only owned answered/dismissed operations')
        if side == 'oc':
            completed = [o for o in operations if o['state'] == 'completed']
            require(len(completed) == 1 and completed[0]['provider_call_id'] == 'call_vis37_answer' and
                    completed[0]['name'] == 'question' and completed[0]['output'] == output and
                    json.loads(completed[0]['input']) == QUESTIONS, 'native durable typed output equals actual next-wire bytes')
            expected = [(1,'user',PROMPT),(2,'assistant',DONE)]+([(3,'user',CANCEL)] if i >= 3 else [])
            require([(m['seq'],m['role'],m['text']) for m in records['messages']] == expected and
                    [m['id'] for m in records['messages']] == ['m000'+str(j+1) for j in range(len(expected))] and
                    all(m['session_id'] == completed[0]['session_id'] for m in records['messages']), 'native complete RAW source IDs/seq/session/text')
            for ob in s['observations']:
                data = ob['data']
                require(data.get('tool_output_resources',[]) == [] and
                        all(o['name'] == 'question' for o in data.get('tool_operations',[])) and
                        all(not p['presentation'].get('generated_guidance') and not p['presentation'].get('body_limited') for p in data.get('presentation',[])), 'native truthful complete typed presentation, no extra owner')
            if i >= 3:
                cancelled = [o for o in operations if o['provider_call_id'] == 'call_vis37_cancel']
                require(len(cancelled) == 1 and cancelled[0]['state'] == 'cancelled' and cancelled[0]['output'] == 'error: question dismissed', 'native cancelled never answered')
        else:
            completed = [o for o in operations if o['data']['state']['status'] == 'completed']
            require(len(completed) == 1, 'one completed donor operation')
            part = completed[0]['data']
            require(part['id'] == 'call_vis37_answer' and part['name'] == 'question' and
                    part['state']['input'] == QUESTIONS and part['state']['metadata']['answers'] == ANSWERS and
                    part['state']['content'] == [{'type':'text','text':DONOR_RESULT}], 'actual donor V2 durable metadata/canonical content')
            messages = {m['id']:m for m in records['messages']}
            for op in operations:
                m = messages[op['message_id']]
                require(m['session_id'] == op['session_id'] and m['seq'] == op['seq'] and
                        json.loads(m['data'])['content'][op['part_index']] == op['data'], 'donor actual V2 RAW content[]/source IDs association')
            require([json.loads(m['data'])['text'] for m in records['messages'] if m['type'] == 'user'] ==
                    [PROMPT]+([CANCEL] if i >= 3 else []), 'donor immutable RAW user text source')
            if i >= 3:
                cancelled = [o for o in operations if o['data']['id'] == 'call_vis37_cancel']
                require(len(cancelled) == 1 and cancelled[0]['data']['state']['status'] == 'error' and
                        not cancelled[0]['data']['state'].get('metadata',{}).get('answers'), 'donor cancellation not answered')
        if i == 4:
            raw,operations_final = records['messages'],operations
    require(raw == initial_facts['final_raw_messages'] and operations_final == initial_facts['final_source_operations'], 'complete initial RAW/durable rows immutable')
    restart = next(i for i,e in enumerate(protocol) if e['kind'] == 'relaunch')
    cancel = next(i for i,e in enumerate(protocol) if e['kind'] == 'provider' and e.get('operation') == 'question_main' and e.get('index') == 3)
    require(not any(e['kind'] in ('provider','fixture_tool_call') for e in protocol[restart:cancel]) and
            not any(e['kind'] in ('provider','fixture_tool_call') for e in protocol[cancel+2:]), 'no reask/replay/restart or cancellation continuation')
    decoded = [(e['kind'],base64.b64decode(e['base64'],validate=True)) for e in inputs]
    expected_input = {'question_user_prompt':b'\x1b[200~'+PROMPT.encode()+b'\x1b[201~','question_user_submit':b'\r',
                      'question_select_rust':b' ','question_select_python':b'\x1b[B ','question_next_field':b'\t',
                      'question_custom_select':b'3','question_custom_paste':b'\x1b[200~custom \xce\xa9\xe7\x95\x8c\x1b[201~',
                      'question_commit_custom':b'\r','question_explicit_reply':b'\r',
                      'question_cancel_prompt':b'\x1b[200~'+CANCEL.encode()+b'\x1b[201~','question_cancel_submit':b'\r','question_owned_dismiss':b'\x1b'}
    for k,v in expected_input.items():
        require([b for a,b in decoded if a == k] == [v], 'exact actual unique gesture '+k)
    allowed = set(expected_input)|{'terminal_reply','question_command','question_command_enter','question_reopen','question_clean_exit','question_actual_scroll_up','question_actual_scroll_down'}
    require(all(k in allowed for k,_ in decoded) and dict(collections.Counter(k for k,_ in decoded)) == initial_facts['input_kind_counts'], 'no additional unowned gestures')
    terminal = rb'\x1b(?:\](?:10|11);rgb:[0-9a-f]{4}/[0-9a-f]{4}/[0-9a-f]{4}\x1b\\|\[\d+;\d+R|\[\?\d+;[0-4]\$y|\[\?\d+;\d+c|\[I)'
    require(all(re.fullmatch(terminal,v) for k,v in decoded if k == 'terminal_reply'), 'automatic negotiation only')
    require([v for k,v in decoded if k == 'question_command'] == [b'/new',b'/sessions',b'/sessions',b'/new',b'/sessions'] and
            [v for k,v in decoded if k == 'question_command_enter'] == [b'\r']*5 and
            len([v for k,v in decoded if k == 'question_reopen']) == 3 and
            [v for k,v in decoded if k == 'question_clean_exit'] == [b'\x03'], 'exact view-only gestures and one clean restart')
    for k in ('question_actual_scroll_up','question_actual_scroll_down'):
        require(sum(a == k for a,_ in decoded) <= 8, 'bounded actual scroll gestures')
    require(facts['answers'] == ANSWERS and [facts[k] for k in ('provider_requests','main_requests','explicit_user_submissions','explicit_answer_submissions','question_calls')] == [4,3,2,1,2], 'consistent explicit observed submission facts')
    launches = [e for e in protocol if e['kind'] in ('launch','relaunch')]
    root = initial_facts['launch_root']
    require([e['kind'] for e in launches] == ['launch','relaunch'] and spec['isolated_root'] == root and
            spec['question_forms'] is True and spec['tool_preview'] is True, 'same exclusive generation root')
    for e in launches:
        require(e['cwd'] == root+'/project' and e['argv'][0] == lock[side]['executable_path'], 'actual ELF/cwd launch association')
    env = launches[0]['env']
    home = root+'/'+side+'/home'
    require(env['HOME'] == env['OPENCODE_TEST_HOME'] == home, 'owned isolated HOME')
    for k,tail in [('CONFIG','config'),('CACHE','cache'),('DATA','data'),('STATE','state')]:
        require(env['XDG_'+k+'_HOME'] == home+'/'+tail, 'actual isolated XDG source')
    config = json.loads(env['OPENCODE_CONFIG_CONTENT'])
    require(config['snapshots'] is False and config['compaction']['auto'] is False and
            config['mcp'] == ({'servers':{}} if side == 'upstream' else {}), 'snapshot/autoDCP/MCP disabled in bounded fixture')
    provider = config['providers' if side == 'upstream' else 'provider']['fixture']
    url = provider['settings' if side == 'upstream' else 'options']['baseURL']
    require(url.startswith('http://127.0.0.1:') and url.endswith('/v1'), 'actual loopback deterministic provider')
    exits = [e for e in protocol if e['kind'] == 'exit']
    require(exits == initial_facts['exits'] and len(exits) == 2 and exits[0]['generation'] == 0 and
            exits[0]['code'] == 0 and exits[0]['termination'] == 'natural' and
            exits[1]['generation'] == 1 and exits[1]['termination'] == 'forced_stop', 'natural first exit and forced final harness teardown disclosed')
    return {'provider_requests':4,'main_requests':3,'title_requests':1,'calls':2,'explicit_user_enters':2,
            'explicit_answer_submissions':1,'readonly_snapshots':5,'wire_sha256':sha(output.encode()),
            'typed_answers':ANSWERS,'complete_initial_raw_and_operations_equal':True,
            'native_typed_result_or_actual_donor_v2_content_validated':True,'no_replay':True,
            'no_observed_extra_effects':True,'exits':exits,
            'scope':'Captured SQL/RAW/wire source only. No independent DB opening; Original DCP tables unread. Generation1 FORCED_STOP is not clean-final proof.'}


def elf(path):
    with Path(path).open('rb') as stream:
        header = stream.read(64)
        require(header[:6] == b'\x7fELF\x02\x01', 'actual ELF64 LE')
        kind,machine = struct.unpack_from('<HH',header,16)
        require(kind in (2,3) and machine == 62 and os.access(path,os.X_OK), 'actual executable x86_64 ELF')
        h = hashlib.sha256(header)
        while block := stream.read(1024**2):
            h.update(block)
        size = stream.tell()
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest(),'elf_type':kind,'machine':machine}


def episode_checks(files,episode,initial,source_names,tree):
    current = episode.startswith('current-')
    profile = episode.split('-',1)[1] if current else 'wide'
    ep = ROOTS[episode]
    prior = initial['profiles'][profile] if current else initial['preserved_failed001']
    read = lambda n: archived(files,episode,n)
    lock,manifest,commands = (read(n) for n in ('capture.lock.json','source-manifest.json','commands.json'))
    for n,seal in prior['seals'].items():
        require(sha(files[episode+'/'+n]) == seal, 'initial four lock/source/command/tooling seals')
    require(set(manifest) == source_names and lock['oc']['commit'] == HEAD and lock['oc']['tree'] == tree and
            lock['sources']['upstream_commit'] == DONOR and producer_sha(manifest) == lock['oc']['source_manifest_sha256'], 'exact complete manifest and HEAD/tree/donor seals')
    if current:
        require(lock['oc']['source_manifest_sha256'] == initial['source']['producer_canonical_sha256'] and
                manifest == {n:digest(REPO/n) for n in source_names}, 'all713 current physical source bytes match each captured manifest')
    for n,seal in lock['runner_hashes'].items():
        require(manifest['scripts/tui_capture/'+n] == seal, 'every captured runner owner included in source seal')
    enumeration = [c for c in commands if c['argv'] == ['git','ls-files','-z','--cached','--others','--exclude-standard','--',*SCOPE]]
    require(len(enumeration) == 1 and enumeration[0]['exit_code'] == 0 and
            {n for n in enumeration[0]['stdout'].split('\0') if n} == source_names, 'exact actual captured713 source enumeration')
    diffs = [c for c in commands if c['argv'] == ['git','diff','--binary']]
    require(len(diffs) == 1 and sha(diffs[0]['stdout'].encode()) == lock['oc']['dirty_diff_sha256'], 'original unmodified captured dirty diff seal')
    builds = [c for c in commands if c['argv'][0] == 'cargo']
    require(len(builds) == 1 and builds[0]['argv'] == ['cargo','build','--locked'] and builds[0]['exit_code'] == 0 and
            builds[0] == prior['captured_one_build' if current else 'captured_build'], 'every one actual successful captured locked Cargo build, no audit rerun')
    invocation = commands[0]
    opts = dict(zip(invocation['argv'][2::2],invocation['argv'][3::2],strict=True))
    require(invocation['role'] == 'capture runner invocation' and invocation['exit_code'] == 1 and opts == {
        '--reference':str(TEMP/'t44-reference/package/bin/opencode'),'--oc':str(REPO/'target/debug/oc'),
        '--build-oc':'true','--geometry':'true','--sample':'short','--sidebar':'hide','--tool-preview':'true',
        '--question-forms':'true','--columns':str(PROFILES[profile][0]),'--rows':str(PROFILES[profile][1]),'--output':str(ep)}, 'exact actual parent-exclusive capture argv')
    driver = [d for p,d in initial['direct_parent_drivers'].items() if d['data']['output'] == str(ep)]
    require(len(driver) == 1 and driver[0]['data']['attempts'] == lock['attempts'] and
            driver[0]['data']['exit_code'] == lock['exit_code'] == 1, 'sealed direct parent-driver/capture-lock association')
    attempts = collections.Counter(a['status'] for a in lock['attempts'])
    require(attempts == ({'DIFFERENT':34} if current else {'DIFFERENT':20,'BLOCKED':10}), 'actual strict status cardinality including blocked failed attempts')
    comparators = [c for c in commands if len(c['argv']) > 1 and c['argv'][1] == str(REPO/'tui-recovery/scripts/compare_frames.py')]
    require(len(comparators) == attempts['DIFFERENT'], 'every actual strict comparator recorded')
    for a in lock['attempts']:
        if a['status'] == 'BLOCKED':
            continue
        scenario,mode = a['scenario'],a['mode']
        suffix = '.cells.json' if mode == 'grid' else '.png'
        expected = ['/usr/bin/python3',str(REPO/'tui-recovery/scripts/compare_frames.py'),mode,
                    str(ep/'upstream'/(scenario+suffix)),str(ep/'oc'/(scenario+suffix)),
                    '--report',str(ep/(scenario+'.'+mode+'-diff.json'))]
        matching = [c for c in comparators if c['argv'] == expected]
        record = read(scenario+'.'+mode+'-diff.json')
        require(len(matching) == 1 and matching[0]['exit_code'] == a['exit_code'] == 1 and
                json.loads(matching[0]['stdout']) == record and record['status'] == 'FAIL' and record['kind'] == mode and
                record['reference_sha256'] == sha(files[episode+'/upstream/'+scenario+suffix]) and
                record['actual_sha256'] == sha(files[episode+'/oc/'+scenario+suffix]), 'exact strict argv/inputs/outputs; no crop/mask/tolerance')
    captures = {(c['origin'],c['scenario']):c for c in lock['captures']}
    require(len(captures) == len(lock['captures']) == (34 if current else 25), 'complete unique original captured frames')
    environment = producer_sha(lock['profile'])
    for (side,scenario),c in captures.items():
        for field,suffix in [('cells','.cells.json'),('png','.png'),('render','.render.json'),('text','.txt'),('vt','.vt')]:
            require(sha(files[episode+'/'+side+'/'+scenario+suffix]) == c[field+'_sha256'], 'every original capture sidecar seal unchanged')
        g,r = read(side+'/'+scenario+'.cells.json'),read(side+'/'+scenario+'.render.json')
        require((g['columns'],g['rows']) == PROFILES[profile] and g['environment_id'] == r['environment_id'] == c['environment_id'] == environment and
                g['fixture_sha256'] == lock['fixture_sha256'], 'full grid/profile/render capture association')
        require(r['terminal_refresh_from_buffer'] is False and r['layout_changed_during_screenshot'] is False and
                r['before']['screen_rect'] == r['after']['screen_rect'] and
                r['screenshot']['clip'] == {k:r['after']['screen_rect'][k] for k in ('x','y','width','height')}, 'whole real terminal screenshot with unchanged geometry')
        png_size,_ = decode_png(files[episode+'/'+side+'/'+scenario+'.png'])
        require(png_size == (r['screenshot']['png_width'],r['screenshot']['png_height']), 'opaque full PNG original render dimensions')
        if current:
            require(c['status'] == 'CAPTURED_TOOL_PREVIEW' and r['after']['logical_buffer_cursor'] == {k:g['cursor'][k] for k in ('x','y')} and
                    lock['tool_preview'][side]['stages'][STAGES.index(scenario.removeprefix('tool-preview-'))]['cursor'] == g['cursor'], 'source accepted stable full grid/cursor association')
    pairs,card = [],None
    scenarios = ['tool-preview-'+s for s in STAGES] if current else sorted({a['scenario'] for a in lock['attempts'] if a['status'] == 'DIFFERENT'})
    for scenario in scenarios:
        grids = {s:read(s+'/'+scenario+'.cells.json') for s in ('upstream','oc')}
        grid,diffs = compare_grid(grids['upstream'],grids['oc'])
        png = compare_png(files[episode+'/upstream/'+scenario+'.png'],files[episode+'/oc/'+scenario+'.png'])
        for metric,mode in ((grid,'grid'),(png,'png')):
            recorded = read(scenario+'.'+mode+'-diff.json')
            require(all(recorded[k] == v for k,v in metric.items() if k != 'different_fields'), 'independent decoded full-frame metrics agree with original comparator')
        require(grid['different_cells'] > 0 and png['different_pixels'] > 0, 'strict residuals remain visible')
        pair = {'scenario':scenario,'grid':grid,'png':png}
        original_pairs = prior['pairs'] if current else prior['independently_recounted_paired_frames']
        original = next(p for p in original_pairs if (p.get('scenario') or 'tool-preview-'+p['stage']) == scenario)
        require(grid == original['grid'] and png == original['png'], 'initial independently measured complete frame results immutable')
        pairs.append(pair)
        if current and scenario == 'tool-preview-question-answered-card':
            card = card_owner(grids,diffs)
            card['full_frame_grid'],card['full_frame_png'] = grid,png
            for k,v in card.items():
                require(prior['answered_card'][k] == v, 'initial answered glyph-only owner result immutable')
    facts = {}
    for side in ('upstream','oc'):
        if current:
            facts[side] = side_facts(files,episode,side,lock,prior['facts'][side])
        else:
            checks,proto = read(side+'/tool-preview-checks.json'),read(side+'/protocol.json')
            providers = [e for e in proto if e['kind'] == 'provider']
            require(checks['status'] == 'FAILED' and len(checks['stages']) == (9 if side == 'upstream' else 14) and
                    checks.get('reason') == prior['sides'][side]['reason'] and providers == prior['sides'][side]['providers'], 'actual failed001 observer state/partial wire untouched')
            facts[side] = {'status':checks['status'],'stages':len(checks['stages']),'reason':checks.get('reason'),
                          'partial_valid_requests':len(providers),'whole_pngs':sum(s == side for s,_ in captures)}
    return {'seals':prior['seals'],'captured_build':builds[0],'captured_invocation':invocation,
            'runner_hashes':lock['runner_hashes'],'producer_source_sha256':lock['oc']['source_manifest_sha256'],
            'dirty_diff_sha256':lock['oc']['dirty_diff_sha256'],'captures':len(captures),
            'strict_status_counts':dict(attempts),'independent_full_frame_pairs':pairs,'answered_card':card,'side_facts':facts},manifest,lock


def main():
    started = time.monotonic()
    require(os.getuid() != 0 and Path(os.environ['TMPDIR'])/'opencode' == TEMP and
            Path(__file__).resolve().parent == HERE and not (HERE/'inverse_report.json').exists() and not sys.argv[1:], 'approved exclusive nonroot inverse scratch')
    preserved = {str(p):{'metadata':metadata(p),'sha256':digest(p)} for p in (HERE/'verifier.py',HERE/'report.json',ARCHIVE,RECEIPT)}
    require(preserved[str(HERE/'verifier.py')]['sha256'] == INITIAL_HELPER_SHA and
            preserved[str(HERE/'report.json')]['sha256'] == INITIAL_REPORT_SHA, 'initial independent helper/report fixed seals')
    initial,receipt = load(HERE/'report.json'),load(RECEIPT)
    require(initial['helper_sha256'] == INITIAL_HELPER_SHA and initial['head'] == HEAD and initial['donor'] == DONOR,
            'sealed initial report/helper/HEAD association')
    require(receipt['version'] == 1 and receipt['codec'] == 'stdlib USTAR + single XZ; original encoded PNGs unchanged' and
            receipt['source_roots'] == {n:str(p) for n,p in ROOTS.items()}, 'actual authoritative receipt exact eight roots')
    require(receipt['retainer_source_sha256'] == digest(REPO/'scripts/retain_syntax_proof.py'), 'physical retainer source seal association, never imported/executed')
    quota_before,memory_start = quota(),proc_memory()
    expected,original_inventory = preservation(initial)
    require(original_inventory['files'] == 829 and original_inventory['directories'] == 14 and
            original_inventory['logical_bytes'] == 64853986, 'derived pre-pack selected file inventory reconciled')
    encoded = read_bytes(ARCHIVE)
    require(len(encoded) == receipt['archive_bytes'] == 2404048 and sha(encoded) == receipt['archive_sha256'], 'actual encoded archive seal/size')
    raw,xz = inverse_xz(encoded)
    require(len(raw) == receipt['tar_bytes'] and sha(raw) == receipt['tar_sha256'], 'actual complete decoded TAR seal/size')
    files,tar = inverse_ustar(raw,expected)
    require(tar['inventory'] == receipt['inventory'] and tar['inventory']['same_side_png_aliases'] == 31, 'actual complete inventory seal and31 direct aliases')
    require(sum(n.endswith('.png') for n in files) == 127, 'all127 original whole opaque PNG members retained')
    require(git('rev-parse','HEAD').decode().strip() == HEAD, 'actual HEAD fixed')
    tree = git('rev-parse','HEAD^{tree}').decode().strip()
    names = {n for n in git('ls-files','-z','--cached','--others','--exclude-standard','--',*SCOPE).decode().split('\0') if n and (REPO/n).exists()}
    require(len(names) <= MEMBERS and all((REPO/n).is_file() and not (REPO/n).is_symlink() and (REPO/n).stat().st_size <= FILE for n in names), 'actual bounded source membership')
    source_before = {n:digest(REPO/n) for n in names}
    source_bytes = sum((REPO/n).stat().st_size for n in names)
    require(source_bytes+original_inventory['logical_bytes'] <= TOTAL and
            len(names) == initial['source']['derived_members'] and source_bytes == initial['source']['logical_bytes'], '713physical source bytes separate from829 archive files, combined bound')
    fixture_tree = ast.parse((REPO/'scripts/tui_capture/question_fixture.py').read_text())
    actual_questions = next(ast.literal_eval(n.value) for n in fixture_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'QUESTIONS' for t in n.targets))
    require(actual_questions == QUESTIONS, 'current producer source AST literal independently equals complete typed contract, no imports')
    episodes,manifests,locks = {},{},{}
    for episode in ('failed-wide','current-small','current-wide','current-tall'):
        episodes[episode],manifests[episode],locks[episode] = episode_checks(files,episode,initial,names,tree)
    require(all(manifests[e] == source_before for e in episodes if e.startswith('current-')) and
            producer_sha(source_before) == initial['source']['producer_canonical_sha256'], 'all three captured complete manifests still current')
    changed = {n:{'failed':manifests['failed-wide'][n],'current':source_before[n]} for n in names if manifests['failed-wide'][n] != source_before[n]}
    require(changed == initial['preserved_failed001']['source_differences_from_current'], 'only initial documented observer/test differences, no runtime changes between attempts')
    executables = {s:elf(locks['current-wide'][s]['executable_path']) for s in ('oc','upstream')}
    for s,identity in executables.items():
        require(identity['sha256'] == initial['executables'][s]['sha256'] and identity['bytes'] == initial['executables'][s]['bytes'] and
                all(lock[s]['executable_sha256'] == identity['sha256'] for lock in locks.values()), 'physical actual ELF still exactly every sealed captured executable')
    parent_members = {n:expected[n] for n in expected if n.startswith(('failed-logs/','current-logs/','failed-driver/','current-driver/'))}
    require(len(parent_members) == 8, 'six direct parent log/owner files plus two producer drivers, no double-counted episode files')
    for p,d in initial['direct_parent_drivers'].items():
        key = next(n for n,r in expected.items() if r['path'] == p)
        require(sha(files[key]) == d['sha256'] and len(files[key]) == d['bytes'] and json.loads(bytes(files[key])) == d['data'], 'complete initial direct-parent driver bytes/data preserved')
    require(all(b'sole-parent' in bytes(files[n]) for n in parent_members if n.endswith('/owner.txt')), 'direct ownership markers preserved')
    actual_reports = []
    for episode,e in episodes.items():
        actual_reports.append({'episode':episode,'captures':e['captures'],'current_source':episode.startswith('current-'),
                               'scope':'ANSWER_CONSUMER_CARD_GLYPHS_ONLY' if episode.startswith('current-') else 'FAILED_OBSERVER_PROJECTION',
                               'statuses':{s:'PASS_BEHAVIOR_ONLY' if episode.startswith('current-') else 'FAILED' for s in ('oc','upstream')},
                               'comparisons':e['strict_status_counts']})
    require(receipt['producer_reports'] == actual_reports, 'physical receipt reports correspond to unchanged actual observations')
    all_pairs = [p for n,e in episodes.items() if n.startswith('current-') for p in e['independent_full_frame_pairs']]
    totals = {**initial['totals'],'different_cells':sum(p['grid']['different_cells'] for p in all_pairs),
              'different_pixels':sum(p['png']['different_pixels'] for p in all_pairs),
              'equal_cursor_pairs':sum(not p['grid']['cursor_differs'] for p in all_pairs),
              'different_cursor_pairs':sum(p['grid']['cursor_differs'] for p in all_pairs),
              'checked_cells':sum(p['grid']['cells_checked'] for p in all_pairs),
              'checked_pixels':sum(p['png']['pixels_checked'] for p in all_pairs)}
    require(totals == initial['totals'] and len(all_pairs) == 51, 'current complete visual/behavior totals unchanged')
    card_blanks = sum(e['answered_card']['styled_cell_differences_in_owner_rows'] for n,e in episodes.items() if n.startswith('current-'))
    require(card_blanks == 57, 'exact57 owner blank-styled cell residuals, never hidden')
    source = (REPO/'scripts/tui_capture/capture.mjs').read_text()
    require('const key = sha(JSON.stringify(f));' in source and 'stable = key===previous ? stable+1 : 0;' in source and
            'stable >= 4' in source and 'await sleep(200);' in source and
            'sha(JSON.stringify(afterFrame)) !== sha(JSON.stringify(f))' in source and
            'if(freshRoot && fs.existsSync(isolated))throw Error' in source, 'current sealed five-observation/stable-paint/exclusive-root enforcement')
    require(preservation(initial)[0] == expected and {n:digest(REPO/n) for n in names} == source_before, 'all original bytes/metadata and713 source bytes immutable through inverse')
    for p,record in preserved.items():
        require(metadata(p) == record['metadata'] and digest(p) == record['sha256'], 'initial independent files/new archive/receipt immutable through inverse')
    quota_after,memory_end = quota(),proc_memory()
    result = {'schema_version':1,'status':'INDEPENDENT_FULL_BYTE_EXACT_INVERSE_QUALIFIED_STRICT_VIS37_R6_T44_NOT_PASS',
              'head':HEAD,'donor':DONOR,'elapsed_seconds':round(time.monotonic()-started,3),
              'archive':{'path':str(ARCHIVE),'bytes':len(encoded),'sha256':sha(encoded),'tar_bytes':len(raw),'tar_sha256':sha(raw),
                         'receipt_path':str(RECEIPT),'receipt_sha256':preserved[str(RECEIPT)]['sha256'],'xz':xz,'ustar':tar},
              'prepack_original_inventory':original_inventory,'all_original_member_associations':expected,
              'direct_parent_members':parent_members,'episodes':episodes,'current_totals':totals,
              'answered_card_owner_blank_differences':card_blanks,'source':{'members':len(names),'logical_bytes':source_bytes,
                  'source_bytes_are_not_archive_members':True,'producer_canonical_sha256':producer_sha(source_before),
                  'physical_source_hashes':source_before,'failed_to_current_observer_test_differences':changed,
                  'current_dirty_paths':git('diff','--name-only').decode().splitlines()},
              'executables':executables,'immutable_preexisting_files':preserved,
              'pending_form_residual':initial['pending_form_residual'],'helper_sha256':digest(__file__),
              'resources':{'hard_address_space_bytes':AS,'hard_each_file_bytes':FILE,'logical_tar_bytes_bound':TOTAL,
                  'logical_original_bytes':original_inventory['logical_bytes'],'logical_source_bytes_separate':source_bytes,
                  'logical_source_plus_original_bytes':source_bytes+original_inventory['logical_bytes'],
                  'members_bound':MEMBERS,'xz_dictionary_bytes_bound':XZ_DICT,'xz_decoder_bytes_bound':XZ_DECODE,
                  'owned_evidence_before':quota_before,'owned_evidence_after':quota_after,
                  'tmp_scratch_before_new_report':tmp_allocation(),'actual_proc_memory_start':memory_start,'actual_proc_memory_end':memory_end,
                  'initial_ru_maxrss_scope':'Initial report remains immutable; its 4609867776-byte ru_maxrss was exec-inherited highwater, not actual auditor memory. This audit uses /proc/self/status VmPeak/VmHWM.'},
              'scope':'Independent stdlib manual XZ/container/USTAR inverse plus exact originals/initial inventory/source/ELF/full-frame/wire/SQL-source requalification. No extraction/Cargo/runtime/provider/capture/worktree writes. Original DCP tables unread; final generation1 forced harness teardown disclosed. No broader historical artifact byte claim. No crop/mask/tolerance/golden/clock edits. Full VIS37/R6/T44 NOT PASS.',
              'defects':[]}
    report = json.dumps(result,ensure_ascii=False,indent=2).encode()+b'\n'
    require(len(report) <= FILE and proc_memory()['VmPeak_bytes'] <= AS, 'bounded new independent report/memory')
    fd = os.open(HERE/'inverse_report.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(report)
        stream.flush()
        os.fsync(stream.fileno())
    require(preservation(initial)[0] == expected, 'originals immutable after exclusive report write')
    for p,record in preserved.items():
        require(metadata(p) == record['metadata'] and digest(p) == record['sha256'], 'immutable initial proofs after final report')
    print(json.dumps({'status':result['status'],'archive_sha256':result['archive']['sha256'],
                      'receipt_sha256':result['archive']['receipt_sha256'],'tar_sha256':result['archive']['tar_sha256'],
                      'inventory':tar['inventory'],'current_totals':totals,'owner_blank_differences':card_blanks,
                      'source':{k:v for k,v in result['source'].items() if k not in ('physical_source_hashes','failed_to_current_observer_test_differences')},
                      'executables':executables,'memory_after_report':proc_memory(),'owned_evidence':quota(),
                      'tmp_scratch_after_report':tmp_allocation(),'helper_path':str(HERE/'inverse_verifier.py'),
                      'helper_sha256':digest(__file__),'report_path':str(HERE/'inverse_report.json'),
                      'report_sha256':digest(HERE/'inverse_report.json'),'report_bytes':len(report)},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
