"""Retain audit programs/reports only; this is NOT the blocked004 capture proof."""
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys

sys.dont_write_bytecode = True
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
sys.path.insert(0, str(REPO / 'scripts'))
import retain_syntax_proof as producer

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
producer.require(os.getuid() == 1003, 'dedicated owner')
sources = {
    'form-before.json': TMP / 'vis37-form-independent-20261012-sole-verifier/before.json',
    'form-after.json': TMP / 'vis37-form-independent-20261012-sole-verifier/after.json',
    'form-verifier.py': TMP / 'vis37-form-independent-20261012-sole-verifier/verifier.py',
    'owner-refinement.py': TMP / 'vis37-form-independent-20261012-sole-verifier/owner_refinement.py',
    'prior-inverse.py': TMP / 'vis37-independent-20261012-sole-verifier/inverse_verifier.py',
    'prior-verifier.py': TMP / 'vis37-independent-20261012-sole-verifier/verifier.py',
    **{name: TMP / name for name in ('vis37-form-r4-independent.py', 'vis37-form-r4-independent.json',
        'vis37-form-capture-r4.py', 'vis37-form-r4-codec-diagnostic.py',
        'vis37-form-delivery-inverse-20261012.py', 'vis37-form-delivery-inverse-20261012.json')},
    Path(__file__).name: Path(__file__),
}
for label in ('r4-independent-recount', 'final-independent-delivery', 'final-retain-gates'):
    for suffix in ('.log', '.json'):
        name = 'vis37-form-gate-' + label + suffix
        sources[name] = TMP / name
files = {'audit/' + name: path.read_bytes() for name, path in sources.items()}
producer.require(len(files) < 2000 and all(len(data) <= producer.MAX_FILE for data in files.values()), 'bounded audit files')
encoded, tar_sha, tar_bytes = producer.encode(files, {})
spec = importlib.util.spec_from_file_location('manual_audit_inverse', sources['prior-inverse.py'])
inverse = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inverse)
inverse.ROOTS = {'audit': TMP}
expected = {'audit/' + name: {'path': str(path), 'bytes': path.stat().st_size, 'sha256': inverse.digest(path)}
            for name, path in sources.items()}
raw, xz = inverse.inverse_xz(encoded)
restored, facts = inverse.inverse_ustar(raw, expected)
producer.require(inverse.sha(raw) == tar_sha and len(raw) == tar_bytes and len(restored) == len(files), 'manual whole audit inverse')
archive = REPO / 'evidence/tui/vis37-form-audits.tar.xz'
receipt = REPO / 'evidence/tui/vis37-form-audits.inventory.json'
producer.require(not archive.exists() and not receipt.exists(), 'exclusive audit retention')
record = {'status': 'AUDIT_RECORDS_RETAINED_ONLY_CURRENT004_CAPTURE_RETENTION_BLOCKED_T44_NOT_PASS',
          'archive_bytes': len(encoded), 'archive_sha256': inverse.sha(encoded),
          'tar_bytes': len(raw), 'tar_sha256': inverse.sha(raw), 'inventory': facts['inventory'],
          'original_audit_files': expected,
          'scope': 'Audit reports and programs only, including current004 recount and historical003 inverse; no004 captured images/styled cells/VT/protocol retained here.'}
metadata = (json.dumps(record, indent=2) + '\n').encode()
extra = sum((len(data) + 4095) // 4096 * 4096 for data in (encoded, metadata))
before = producer.storage.owned_allocation()
producer.require(len(encoded) <= producer.MAX_FILE and before + extra <= producer.storage.CAP, 'unchanged retained cap')
producer.storage.durable(archive, encoded)
producer.storage.durable(receipt, metadata)
producer.require(archive.read_bytes() == encoded and receipt.read_bytes() == metadata, 'audit durable reopen')
print(json.dumps({'files': len(files), 'archive_bytes': len(encoded), 'archive_sha256': inverse.sha(encoded),
                  'receipt_bytes': len(metadata), 'receipt_sha256': inverse.sha(metadata),
                  'quota_before': before, 'quota_after': producer.storage.owned_allocation(),
                  'scope': record['scope']}, sort_keys=True))
