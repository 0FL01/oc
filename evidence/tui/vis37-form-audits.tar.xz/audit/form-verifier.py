#!/usr/bin/env python3
"""Independent pre-pack inventory, manual inverse and whole-frame recount."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
import os
from pathlib import Path
import resource

TEMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
HERE = TEMP / 'vis37-form-independent-20261012-sole-verifier'
OLD_HELPERS = TEMP / 'vis37-independent-20261012-sole-verifier'
def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, OLD_HELPERS / filename)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

inverse = module('prior_manual_inverse', 'inverse_verifier.py')
frames = module('prior_whole_frame_reader', 'verifier.py')
HEAD = '661a17bcd752b5ff60a511bd2f6b96c64b189c54'
inverse.HEAD = frames.HEAD = HEAD
inverse.HERE = HERE
REPO = inverse.REPO
ROOTS = {'failed-wide': TEMP / 'vis37-form-current-001/wide'}
ROOTS.update({period + '-' + profile: TEMP / ('vis37-form-current-' + attempt) / profile
              for period, attempt in (('historical', '002'), ('current', '003'))
              for profile in ('small', 'wide', 'tall')})
for period, attempt, helper in (('failed', '001', 'vis37-form-capture.py'),
                                ('historical', '002', 'vis37-form-capture-r2.py'),
                                ('current', '003', 'vis37-form-capture-r3.py')):
    ROOTS[period + '-logs'] = TEMP / ('vis37-form-current-' + attempt)
    ROOTS[period + '-driver'] = TEMP / helper
inverse.ROOTS = ROOTS

def inventory():
    files, directories = {}, {}
    for role, root in ROOTS.items():
        driver, direct = role.endswith('-driver'), role.endswith('-logs')
        inverse.require(root.exists() and root.resolve().is_relative_to(TEMP), 'confined actual capture root')
        if not driver:
            directories[str(root)] = inverse.metadata(root)
        paths = [root] if driver else sorted(root.glob('*') if direct else root.rglob('*'))
        for path in paths:
            meta = inverse.metadata(path)
            if path.is_dir():
                if not direct:
                    directories[str(path)] = meta
                continue
            inverse.require(path.is_file() and meta[0] <= inverse.FILE, 'bounded regular original')
            name = role + '/' + (path.name if driver else path.relative_to(root).as_posix())
            inverse.path_ok(name)
            inverse.require(name not in files, 'no duplicate original')
            files[name] = {'path': str(path), 'bytes': meta[0], 'sha256': inverse.digest(path), 'original_metadata': meta}
            inverse.require(meta == inverse.metadata(path), 'unchanged while sealing')
    inverse.require(len(files) <= inverse.MEMBERS and sum(r['bytes'] for r in files.values()) <= inverse.TOTAL,
                    'all complete and failed originals fit unchanged member/logical bounds')
    return {'files': files, 'directories': directories}

def source():
    names = {name for name in inverse.git('ls-files', '-z', '--cached', '--others', '--exclude-standard', '--', *inverse.SCOPE).decode().split('\0')
             if name and (REPO / name).exists()}
    return {name: inverse.digest(REPO / name) for name in sorted(names)}

def write(name, report):
    data = json.dumps(report, ensure_ascii=False, indent=2).encode() + b'\n'
    inverse.require(len(data) <= inverse.FILE, 'bounded independent output')
    with (HERE / name).open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({'output': str(HERE / name), 'bytes': len(data), 'sha256': inverse.sha(data),
                      'status': report['status'], 'memory': inverse.proc_memory(), 'owned_evidence': inverse.quota()}, indent=2))

def current_facts(ep, side):
    checks, protocol, inputs = (inverse.load(ep / side / name) for name in ('tool-preview-checks.json', 'protocol.json', 'inputs.json'))
    inverse.require(checks['status'] == 'PASS_BEHAVIOR_ONLY' and [s['stage'] for s in checks['stages']] == inverse.STAGES,
                    'real complete17-stage form behavior')
    inverse.require([s['requests'] for s in checks['stages']] == [0] + [2]*7 + [3]*5 + [4]*4 and
                    [s['calls'] for s in checks['stages']] == [0] + [1]*12 + [2]*4, 'no edit or review continuation')
    providers = [p for p in protocol if p['kind'] == 'provider']
    mains = [p for p in providers if p['operation'] == 'question_main']
    calls = [p for p in protocol if p['kind'] == 'fixture_tool_call']
    inverse.require(len(providers) == 4 and len(mains) == 3 and all(p['valid'] for p in providers) and
                    [p['user_texts'] for p in mains] == [[inverse.PROMPT], [inverse.PROMPT], [inverse.PROMPT, inverse.CANCEL]] and
                    all(p['registered_tools'] == ['question'] for p in mains) and
                    [p['call_id'] for p in calls] == ['call_vis37_answer', 'call_vis37_cancel'] and
                    all(p['arguments'] == inverse.QUESTIONS for p in calls), 'exact typed wire and question ownership')
    result = mains[1]['actual_results']
    inverse.require(mains[0]['actual_results'] == [] and result == mains[2]['actual_results'] and len(result) == 1 and
                    result[0]['call_id'] == 'call_vis37_answer' and
                    (json.loads(result[0]['output']) == {**inverse.QUESTIONS, 'answers': inverse.ANSWERS} if side == 'oc' else
                     result[0]['output'] == inverse.DONOR_RESULT), 'one exact native typed/original canonical result')
    snapshots = [p for p in protocol if p['kind'] == 'tool_preview_snapshot']
    inverse.require(len(snapshots) == 5 and snapshots == [checks['question_forms'][k] for k in ('completed', 'reopened', 'restarted', 'dismissed', 'final')],
                    'actual owner snapshots, not invented source facts')
    inverse.require(snapshots[0]['observations'] == snapshots[1]['observations'] == snapshots[2]['observations'] and
                    snapshots[3]['observations'] == snapshots[4]['observations'], 'source IDs and RAW unchanged through viewing/restart')
    for i, snap in enumerate(snapshots):
        inverse.require(snap['artifacts'] == {} and snap['shell_effect'] is None and snap['mcp_calls'] == snap['mcp_lifecycle'] == [], 'no extra observed effects')
        records = [o['data']['question_records'] for o in snap['observations'] if 'question_records' in o['data']]
        inverse.require(len(records) == 1 and records[0]['readonly'] and len(records[0]['operations']) == (1 if i < 3 else 2), 'actual read-only source records')
        ops = records[0]['operations']
        if side == 'oc':
            inverse.require(ops[0]['provider_call_id'] == 'call_vis37_answer' and ops[0]['state'] == 'completed' and
                            ops[0]['output'] == result[0]['output'], 'durable native question result')
            if i >= 3:
                inverse.require(ops[1]['provider_call_id'] == 'call_vis37_cancel' and ops[1]['state'] == 'cancelled' and
                                ops[1]['output'] == 'error: question dismissed', 'cancellation is not an answer')
        else:
            part = ops[0]['data']
            inverse.require(part['id'] == 'call_vis37_answer' and part['state']['metadata']['answers'] == inverse.ANSWERS, 'actual Original V2 metadata')
            for op in ops:
                message = next(m for m in records[0]['messages'] if m['id'] == op['message_id'])
                inverse.require(json.loads(message['data'])['content'][op['part_index']] == op['data'], 'Original source part/RAW IDs bound')
            if i >= 3:
                inverse.require(ops[1]['data']['state']['status'] == 'error' and not ops[1]['data']['state'].get('metadata', {}).get('answers'), 'honest Original dismissal')
    expected = [('question_empty_custom_tab', 'CQ=='), ('question_empty_custom_backtab', 'G1ta'),
                ('question_custom_tab_commit', 'CQ=='), ('question_custom_backtab', 'G1ta'),
                ('question_custom_reopen_edit', 'DQ=='), ('question_commit_custom', 'DQ=='), ('question_explicit_reply', 'DQ==')]
    inverse.require([(p['kind'], p['base64']) for p in inputs if p['kind'] in dict(expected)] == expected,
                    'real optional-empty Tab and custom Tab/Shift+Tab/reedit, explicit reply only')
    exits = [p for p in protocol if p['kind'] == 'exit']
    inverse.require(len(exits) == 2 and exits[0]['generation'] == 0 and exits[0]['code'] == 0 and
                    exits[1]['generation'] == 1 and exits[1]['termination'] == 'forced_stop', 'natural first exit, honest forced final teardown')
    return {'valid_provider_requests': 4, 'main_requests': 3, 'title_requests': 1, 'question_calls': 2,
            'explicit_user_submissions': 2, 'explicit_answer_submissions': 1, 'readonly_snapshots': 5}

def owner(grids, title):
    ranges = {}
    for side, grid in grids.items():
        hits = [(y, x) for y, row in enumerate(grid['cells']) if title in ''.join(c['symbol'] for c in row)
                for x, cell in enumerate(row) if cell['symbol'] == '┃']
        inverse.require(len(hits) == 1, 'unique real bordered owner title')
        y, x = hits[0]
        first = last = y
        while first > 0 and grid['cells'][first-1][x]['symbol'] == '┃': first -= 1
        while last+1 < grid['rows'] and grid['cells'][last+1][x]['symbol'] == '┃': last += 1
        ranges[side] = [first, last, x]
    aligned = ranges['oc'] == ranges['upstream']
    differences = []
    if aligned:
        for y in range(ranges['oc'][0], ranges['oc'][1]+1):
            for x, (a, b) in enumerate(zip(grids['upstream']['cells'][y], grids['oc']['cells'][y], strict=True)):
                if a != b: differences.append({'x': x, 'y': y, 'original': a, 'native': b})
    return {'geometry': ranges, 'aligned': aligned, 'all_owner_styled_cells_equal': aligned and not differences,
            'differences': differences, 'diagnostic_only_full_frames_remain_strictly_compared': True}

def after():
    before = inverse.load(HERE / 'before.json')
    inverse.require(before['originals'] == inventory() and before['source'] == source(), 'complete original bytes/metadata/source preserved before inverse')
    archive = REPO / 'evidence/tui/vis37-form-proof.tar.xz'
    receipt = inverse.load(REPO / 'evidence/tui/vis37-form-proof.inventory.json')
    encoded = inverse.read_bytes(archive)
    raw, xz = inverse.inverse_xz(encoded)
    files, tar = inverse.inverse_ustar(raw, before['originals']['files'])
    inverse.require(inverse.sha(encoded) == receipt['archive_sha256'] and inverse.sha(raw) == receipt['tar_sha256'] and
                    len(raw) == receipt['tar_bytes'] and tar['inventory'] == receipt['inventory'], 'independent entire inverse matches physical receipt')
    pairs, facts, locks = [], {}, []
    for profile in ('small', 'wide', 'tall'):
        ep = ROOTS['current-' + profile]
        lock, manifest, commands = (inverse.load(ep / name) for name in ('capture.lock.json', 'source-manifest.json', 'commands.json'))
        locks.append(lock)
        inverse.require(manifest == before['source'] and inverse.producer_sha(manifest) == lock['oc']['source_manifest_sha256'], 'all713 current producer paths/bytes')
        builds = [c for c in commands if c['argv'][0] == 'cargo']
        inverse.require(len(builds) == 1 and builds[0]['argv'] == ['cargo', 'build', '--locked'] and builds[0]['exit_code'] == 0,
                        'one real acquisition build, no later gates inserted')
        frames.strict_commands(ep, lock, commands)
        for side in ('oc', 'upstream'):
            facts[profile + '-' + side] = current_facts(ep, side)
            inverse.require(before['elf'][side]['sha256'] == lock[side]['executable_sha256'] == inverse.digest(lock[side]['executable_path']), 'same real current ELF')
        for stage in inverse.STAGES:
            scenario = 'tool-preview-' + stage
            grids = {s: inverse.load(ep / s / (scenario + '.cells.json')) for s in ('oc', 'upstream')}
            metric, _ = frames.compare_grid(grids['upstream'], grids['oc'])
            png = frames.compare_png(ep / 'upstream' / (scenario + '.png'), ep / 'oc' / (scenario + '.png'))
            for mode, value in (('grid', metric), ('png', png)):
                recorded = inverse.load(ep / (scenario + '.' + mode + '-diff.json'))
                inverse.require(all(recorded[k] == v for k, v in value.items() if k != 'different_fields'), 'independent whole-grid/opaque-PNG recount agrees')
            row = {'profile': profile, 'stage': stage, 'grid': metric, 'png': png}
            if stage in inverse.STAGES[1:8] + ['question-cancel-pending']:
                row['pending_owner'] = owner(grids, 'Questions')
            if stage == 'question-answered-card': row['answered_owner'] = owner(grids, '# Questions')
            pairs.append(row)
    del files, raw
    inverse.require(before['originals'] == inventory() and before['source'] == source(), 'every original remains byte/metadata exact after all independent reads')
    totals = {'paired_frames': len(pairs), 'whole_pngs': len(pairs)*2,
              'different_cells': sum(p['grid']['different_cells'] for p in pairs),
              'different_pixels': sum(p['png']['different_pixels'] for p in pairs),
              'checked_cells': sum(p['grid']['cells_checked'] for p in pairs),
              'checked_pixels': sum(p['png']['pixels_checked'] for p in pairs),
              'equal_cursor_pairs': sum(not p['grid']['cursor_differs'] for p in pairs),
              'pending_owner_equal_pairs': sum(p.get('pending_owner', {}).get('all_owner_styled_cells_equal', False) for p in pairs),
              'answered_owner_equal_pairs': sum(p.get('answered_owner', {}).get('all_owner_styled_cells_equal', False) for p in pairs)}
    write('after.json', {'status': 'INDEPENDENT_FULL_BYTE_EXACT_FORM_BEHAVIOR_ONLY_T44_NOT_PASS', 'totals': totals,
                        'pairs': pairs, 'effects': facts, 'archive_sha256': inverse.sha(encoded), 'xz': xz, 'tar': tar,
                        'source_manifest_sha256': locks[0]['oc']['source_manifest_sha256'], 'elf': before['elf'],
                        'before_sha256': inverse.digest(HERE / 'before.json'), 'helper_sha256': inverse.digest(__file__),
                        'memory': inverse.proc_memory(), 'quota': inverse.quota(), 'tmp_allocation': inverse.tmp_allocation(),
                        'scope': 'All001/002/003 original files, directory metadata, helpers and direct logs preserved. Independent manual inverse; current003 whole frames/source/ELF/wire/source effects. Full strict DIFFERENT remains; no masks/crops/tolerance/goldens. DCP tables unread. Finalgeneration1 is forced teardown. No blanket historical byte audit.'})

if __name__ == '__main__':
    inverse.require(os.getuid() != 0 and inverse.git('rev-parse', 'HEAD').decode().strip() == HEAD, 'actual nonroot base')
    if sys.argv[1:] == ['before']:
        write('before.json', {'status': 'INDEPENDENT_SEALED_PREPACK_ORIGINALS', 'originals': inventory(), 'source': source(),
                             'elf': {s: frames.elf(REPO / 'target/debug/oc' if s == 'oc' else TEMP / 't44-reference/package/bin/opencode') for s in ('oc', 'upstream')},
                             'immutable_reused_helpers': {p.name: inverse.digest(p) for p in OLD_HELPERS.glob('*.py')},
                             'helper_sha256': inverse.digest(__file__)})
    elif sys.argv[1:] == ['after']:
        after()
    else:
        raise SystemExit('before or after required; no capture/replay/extraction')
