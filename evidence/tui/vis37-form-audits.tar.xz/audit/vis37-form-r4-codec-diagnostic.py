"""Bounded in-memory attribution; never retain/offload a candidate archive."""
import resource
import sys
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
sys.dont_write_bytecode = True
sys.path.insert(0, '/home/opencode/ai/oc/scripts')
import retain_syntax_proof as p
p.ROOTS = p.vis37_form_roots(current_only=True)
files = p.source_files()
for kind in ('png', 'cells', 'other'):
    suffix = '.png' if kind == 'png' else '.cells.json'
    chosen = {n: b for n, b in files.items() if
              (not n.endswith(('.png', '.cells.json')) if kind == 'other' else n.endswith(suffix))}
    encoded, _, tar_bytes = p.encode(chosen, p.png_aliases(chosen))
    print(dict(kind=kind, members=len(chosen), logical_bytes=sum(map(len, chosen.values())),
               tar_bytes=tar_bytes, encoded_bytes=len(encoded), png_aliases=len(p.png_aliases(chosen))))
