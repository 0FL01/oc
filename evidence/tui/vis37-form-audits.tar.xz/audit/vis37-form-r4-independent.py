"""Read-only current004 recount; explicitly NOT durable archive/inverse proof."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
import os
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
TEMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OLD = TEMP / 'vis37-form-independent-20261012-sole-verifier'
spec = importlib.util.spec_from_file_location('immutable_form_owner_reader', OLD / 'owner_refinement.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
v = module.v
v.ROOTS = {**{'current-' + p: TEMP / 'vis37-form-current-004' / p for p in ('small', 'wide', 'tall')},
           'current-logs': TEMP / 'vis37-form-current-004', 'current-driver': TEMP / 'vis37-form-capture-r4.py'}
v.inverse.ROOTS = v.ROOTS
originals, sources = v.inventory(), v.source()
v.inverse.require(os.getuid() != 0 and v.inverse.git('rev-parse', 'HEAD').decode().strip() == v.HEAD, 'owned nonroot base')
helpers = {str(p): v.inverse.digest(p) for p in [Path(__file__), OLD / 'verifier.py', OLD / 'owner_refinement.py',
           *sorted(v.OLD_HELPERS.glob('*.py'))]}
prior = {str(v.REPO / ('evidence/tui/vis37-form-proof' + suffix)): v.inverse.digest(v.REPO / ('evidence/tui/vis37-form-proof' + suffix))
         for suffix in ('.tar.xz', '.inventory.json')}
elf = {s: v.frames.elf(v.REPO / 'target/debug/oc' if s == 'oc' else TEMP / 't44-reference/package/bin/opencode')
       for s in ('oc', 'upstream')}
pairs, facts, seals = [], {}, []
for profile in ('small', 'wide', 'tall'):
    ep = v.ROOTS['current-' + profile]
    lock, manifest, commands = (v.inverse.load(ep / n) for n in ('capture.lock.json', 'source-manifest.json', 'commands.json'))
    v.inverse.require(manifest == sources and v.inverse.producer_sha(manifest) == lock['oc']['source_manifest_sha256'], 'all actual713 current source bytes')
    seals.append(lock['oc']['source_manifest_sha256'])
    builds = [c for c in commands if c['argv'][0] == 'cargo']
    v.inverse.require(len(builds) == 1 and builds[0]['argv'] == ['cargo', 'build', '--locked'] and builds[0]['exit_code'] == 0,
                      'one exact acquisition build')
    v.frames.strict_commands(ep, lock, commands)
    for side in ('oc', 'upstream'):
        facts[profile + '-' + side] = v.current_facts(ep, side)
        v.inverse.require(elf[side]['sha256'] == lock[side]['executable_sha256'] == v.inverse.digest(lock[side]['executable_path']), 'actual source-current ELF')
    for stage in v.inverse.STAGES:
        scenario = 'tool-preview-' + stage
        grids = {s: v.inverse.load(ep / s / (scenario + '.cells.json')) for s in ('oc', 'upstream')}
        metric, _ = v.frames.compare_grid(grids['upstream'], grids['oc'])
        png = v.frames.compare_png(ep / 'upstream' / (scenario + '.png'), ep / 'oc' / (scenario + '.png'))
        for mode, value in (('grid', metric), ('png', png)):
            recorded = v.inverse.load(ep / (scenario + '.' + mode + '-diff.json'))
            v.inverse.require(all(recorded[k] == value[k] for k in value if k != 'different_fields'), 'strict whole-frame independent recount')
        pair = dict(profile=profile, stage=stage, grid=metric, png=png)
        if stage in v.inverse.STAGES[1:8] + ['question-cancel-pending']:
            pair['pending_owner'] = v.owner(grids, 'Questions')
        if stage == 'question-answered-card':
            pair['answered_owner'] = v.owner(grids, '# Questions')
        pairs.append(pair)
v.inverse.require(originals == v.inventory() and sources == v.source() and all(v.inverse.digest(p) == sha for p, sha in helpers.items())
                  and all(v.inverse.digest(p) == sha for p, sha in prior.items()), 'all004 bytes/metadata, current source, reused helpers and prior retained proof preserved')
totals = dict(paired_frames=len(pairs), whole_pngs=len(pairs)*2, different_cells=sum(p['grid']['different_cells'] for p in pairs),
              different_pixels=sum(p['png']['different_pixels'] for p in pairs), checked_cells=sum(p['grid']['cells_checked'] for p in pairs),
              checked_pixels=sum(p['png']['pixels_checked'] for p in pairs), equal_cursor_pairs=sum(not p['grid']['cursor_differs'] for p in pairs),
              pending_owner_equal_pairs=sum(p.get('pending_owner', {}).get('all_owner_styled_cells_equal', False) for p in pairs),
              answered_owner_equal_pairs=sum(p.get('answered_owner', {}).get('all_owner_styled_cells_equal', False) for p in pairs))
report = dict(status='INDEPENDENT_CURRENT004_RECOUNT_ONLY_RETENTION_BLOCKED_T44_NOT_PASS', totals=totals, pairs=pairs,
              effects=facts, source_manifest_sha256=seals[0], elf=elf, original_inventory=originals,
              immutable_helper_sha256=helpers, preserved_prior_proof_sha256=prior, memory=v.inverse.proc_memory(),
              owned_evidence=v.inverse.quota(), scope='No004 archive pack or independent inverse claimed. All full frames DIFFERENT; no crop/mask/tolerance/goldens. DCP tables unread; final generation1 forced teardown.')
data = (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode()
v.inverse.require(len(data) <= v.inverse.FILE, 'bounded read-only audit output')
output = TEMP / 'vis37-form-r4-independent.json'
with output.open('xb') as stream:
    stream.write(data)
    stream.flush()
    os.fsync(stream.fileno())
print(json.dumps(dict(output=str(output), bytes=len(data), sha256=v.inverse.sha(data), totals=totals,
                     source_manifest_sha256=seals[0], elf=elf, memory=report['memory'], owned_evidence=report['owned_evidence']), indent=2))
