#!/usr/bin/env python3
"""Read-only, independent full-frame qualification of already acquired VIS37 bytes."""
import ast
import base64
import collections
import ctypes
import functools
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
import struct
import subprocess
import sys
import time

sys.dont_write_bytecode = True
AS, FILE, TOTAL, OWNED = 384 * 1024**2, 16 * 1024**2, 128 * 1024**2, 1024**3
MEMBERS, XZ_DICT, XZ_DECODE = 2000, 16 * 1024**2, 32 * 1024**2
resource.setrlimit(resource.RLIMIT_AS, (AS, AS))
resource.setrlimit(resource.RLIMIT_FSIZE, (FILE, FILE))
from PIL import Image

REPO = Path('/home/opencode/ai/oc')
TEMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
HERE = TEMP / 'vis37-independent-20261012-sole-verifier'
CURRENT, OLD = TEMP / 'vis37-current-002', TEMP / 'vis37-current-001'
HEAD = 'c5adde0f7c8bab926592fb885a98c47c09da74e3'
DONOR = '2670273ff17da96f85c5826ced57aa1b368754fa'
ORIGINAL_SHA = '2b0825721cb12f9bca3d5099588087d557a21ed2b5b56efebea3f17dc5f79e6a'
PROFILES = {'small': (80, 24), 'wide': (120, 40), 'tall': (160, 48)}
STAGES = ('question-home question-pending question-one-selected question-multiple-selected '
          'question-long-field question-custom-empty question-custom-edited question-review '
          'question-completed question-answered-card question-switched question-reopened '
          'question-restarted question-cancel-pending question-dismissed question-cancel-switched '
          'question-cancel-reopened').split()
FIELDS = {'symbol', 'fg', 'bg', 'modifiers', 'width'}
PROMPT, CANCEL, DONE = 'VIS37 paired question consumer', 'VIS37 dismiss the next question', 'VIS37-DONE: owned answers accepted.'
ANSWERS = [['Rust', 'Python'], ['custom Ω界']]
SCOPE = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'scripts/tui_capture',
         'tui-recovery/scripts/compare_frames.py', 'tui-recovery/scripts/test_compare_frames.py']


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(1024**2):
            h.update(chunk)
    return h.hexdigest()


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def load(path):
    path = Path(path)
    require(0 < path.stat().st_size <= FILE, 'bounded JSON: ' + str(path))
    return json.loads(path.read_bytes())


def git(*args):
    p = subprocess.run(['git', '--no-optional-locks', '-c', 'core.preloadIndex=false', *args],
                       cwd=REPO, capture_output=True, timeout=30)
    require(p.returncode == 0 and len(p.stdout) <= FILE, 'read-only bounded Git: ' + p.stderr.decode(errors='replace')[:1024])
    return p.stdout


def producer_seal(manifest):
    lib = ctypes.CDLL('/usr/lib/x86_64-linux-gnu/libicui18n.so.76.1')
    op = lib.ucol_open_76
    op.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int32)]
    op.restype = ctypes.c_void_p
    error = ctypes.c_int32(0)
    collator = op(b'en_US', ctypes.byref(error))
    require(collator and error.value <= 0, 'ICU producer-order collator')
    cmp = lib.ucol_strcollUTF8_76
    cmp.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int32, ctypes.c_char_p, ctypes.c_int32, ctypes.POINTER(ctypes.c_int32)]
    cmp.restype = ctypes.c_int
    close = lib.ucol_close_76
    close.argtypes = [ctypes.c_void_p]
    def compare(a, b):
        a, b = a.encode(), b.encode()
        result = cmp(collator, a, len(a), b, len(b), ctypes.byref(error))
        require(error.value <= 0, 'ICU successful source collation')
        return result
    try:
        def order(value):
            if isinstance(value, dict):
                return {k: order(value[k]) for k in sorted(value, key=functools.cmp_to_key(compare))}
            if isinstance(value, list):
                return [order(v) for v in value]
            return value
        ordered = order(manifest)
        return hashlib.sha256(json.dumps(ordered, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
    finally:
        close(collator)


def inventory(root):
    root = Path(root)
    require(root.exists() and not root.is_symlink(), 'existing real evidence root')
    paths = [root, *sorted(root.rglob('*'))] if root.is_dir() else [root]
    rows, total = [], 0
    for path in paths:
        s = path.lstat()
        require(s.st_uid == os.getuid() and not path.is_symlink(), 'owned non-symlink evidence')
        require(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode), 'regular input or directory')
        require(len(rows) < MEMBERS, 'bounded evidence members')
        directory = stat.S_ISDIR(s.st_mode)
        if not directory:
            require(s.st_size <= FILE, 'input file <=16MiB')
            total += s.st_size
            require(total <= TOTAL, 'selected logical input <=128MiB')
        seal = None if directory else digest(path)
        after = path.lstat()
        require((s.st_size, s.st_mode, s.st_ino, s.st_mtime_ns) ==
                (after.st_size, after.st_mode, after.st_ino, after.st_mtime_ns), 'unchanged during read')
        rows.append([str(path.relative_to(root)) if path != root else '.', directory,
                     s.st_size, s.st_mode, s.st_uid, s.st_gid, s.st_dev, s.st_ino, s.st_mtime_ns, seal])
    return {'files': sum(not r[1] for r in rows), 'members': len(rows), 'logical_bytes': total,
            'bytes_and_metadata_sha256': canonical_sha(rows), 'rows': rows}


def owned_allocation():
    # Same established retained-evidence quota scope; stat-only, not an old-byte audit.
    tree = ast.parse((REPO / 'scripts/archive_failed_capture.py').read_text())
    prefixes = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'PREFIXES' for t in n.targets))
    prefixes = tuple(set(prefixes) | {'vis37-'})
    seen, allocated, paths = set(), 0, 0
    for root in (REPO / 'evidence/tui').iterdir():
        if not root.name.startswith(prefixes):
            continue
        for path in [root, *root.rglob('*')] if root.is_dir() else [root]:
            s = path.lstat()
            require(not path.is_symlink(), 'owned evidence quota symlink refused')
            key = (s.st_dev, s.st_ino)
            if key not in seen:
                seen.add(key)
                allocated += s.st_blocks * 512
                paths += 1
    return {'allocated_bytes': allocated, 'stat_only_unique_inodes': paths,
            'quota_bytes': OWNED, 'headroom_bytes': OWNED-allocated,
            'scope': 'Established evidence/tui prefixes plus vis37-; metadata-only, no claim of old-byte validation'}


def elf(path):
    path = Path(path)
    with path.open('rb') as stream:
        h = stream.read(64)
        require(h[:6] == b'\x7fELF\x02\x01', 'real ELF64 little-endian')
        kind, machine = struct.unpack_from('<HH', h, 16)
        require(kind in (2, 3) and machine == 62 and os.access(path, os.X_OK), 'executable native x86_64 ELF')
        seal = hashlib.sha256(h)
        while chunk := stream.read(1024**2):
            seal.update(chunk)
        size = stream.tell()
    return {'path': str(path), 'bytes': size, 'sha256': seal.hexdigest(), 'elf_type': kind, 'machine': machine}


def compare_grid(a, b):
    require(a['origin'] == 'upstream' and b['origin'] == 'oc', 'real side origins')
    for field in ('schema_version', 'scenario', 'fixture_sha256', 'environment_id', 'columns', 'rows'):
        require(a[field] == b[field], 'same grid contract: ' + field)
    require(a['producer_commit'] == DONOR and b['producer_commit'] == HEAD, 'real producer commits')
    w, h = a['columns'], a['rows']
    require(len(a['cells']) == len(b['cells']) == h, 'full grid height')
    diffs, fields = [], collections.Counter()
    for y, (ar, br) in enumerate(zip(a['cells'], b['cells'], strict=True)):
        require(len(ar) == len(br) == w, 'full grid width')
        for x, (ac, bc) in enumerate(zip(ar, br, strict=True)):
            require(set(ac) == set(bc) == FIELDS, 'all styled fields retained')
            if ac != bc:
                changed = sorted(k for k in FIELDS if ac[k] != bc[k])
                diffs.append({'x': x, 'y': y, 'different_fields': changed})
                fields.update(changed)
    bbox = [min(d['x'] for d in diffs), min(d['y'] for d in diffs),
            max(d['x'] for d in diffs), max(d['y'] for d in diffs)] if diffs else None
    return {'cells_checked': w*h, 'different_cells': len(diffs), 'cursor_differs': a['cursor'] != b['cursor'],
            'difference_bbox_inclusive': bbox, 'different_fields': dict(fields)}, diffs


def compare_png(a, b):
    with Image.open(a) as ai, Image.open(b) as bi:
        require(ai.format == bi.format == 'PNG' and ai.size == bi.size and ai.n_frames == bi.n_frames == 1,
                'actual whole equal-sized single PNG')
        w, h = ai.size
        require(w*h*4 <= FILE, 'bounded full RGBA decode')
        ab, bb = ai.convert('RGBA').tobytes(), bi.convert('RGBA').tobytes()
    count, left, top, right, bottom = 0, w, h, -1, -1
    for i in range(0, len(ab), 4):
        if ab[i:i+4] != bb[i:i+4]:
            count += 1
            x, y = (i//4) % w, (i//4)//w
            left, top, right, bottom = min(left,x), min(top,y), max(right,x), max(bottom,y)
    return {'width': w, 'height': h, 'pixels_checked': w*h, 'different_pixels': count,
            'difference_bbox_inclusive': [left,top,right,bottom] if count else None}


def plain(grid):
    return [''.join(c['symbol'] for c in row) for row in grid['cells']]


def answered_owner(grids, diffs):
    positions = {}
    for side, g in grids.items():
        rows = plain(g)
        header = [i for i, s in enumerate(rows) if '# Questions' in s]
        require(len(header) == 1, 'unique actual visible answered heading')
        h = header[0]
        answers = [i for i, s in enumerate(rows) if 'custom Ω' in s and i > h]
        require(len(answers) == 1, 'visible actual final Unicode answer')
        end = answers[0] + 1
        start = h-1
        positions[side] = {'top': start, 'bottom': end, 'rows': rows[start:end+1]}
    aligned = positions['oc']['top'] == positions['upstream']['top'] and positions['oc']['bottom'] == positions['upstream']['bottom']
    owner_diffs = [d for d in diffs if positions['oc']['top'] <= d['y'] <= positions['oc']['bottom']] if aligned else []
    details = [{**d, 'reference': grids['upstream']['cells'][d['y']][d['x']],
                'actual': grids['oc']['cells'][d['y']][d['x']]} for d in owner_diffs]
    content_equal = aligned and all(grids['oc']['cells'][y][5:] == grids['upstream']['cells'][y][5:]
                                   for y in range(positions['oc']['top'], positions['oc']['bottom']+1))
    glyph_equal = aligned and all(grids['oc']['cells'][y][x] == grids['upstream']['cells'][y][x]
                                 for y in range(positions['oc']['top'], positions['oc']['bottom']+1)
                                 for x in range(grids['oc']['columns'])
                                 if grids['oc']['cells'][y][x]['symbol'].strip())
    return {'visible_whole_card_geometry_aligned': aligned,
            'full_visible_card_symbols_equal': positions['oc']['rows'] == positions['upstream']['rows'],
            'full_visible_card_styled_content_from_column5_equal': content_equal,
            'all_nonblank_card_glyph_styled_cells_equal': glyph_equal,
            'owner_rows': positions, 'styled_cell_differences_in_owner_rows': len(owner_diffs),
            'owner_differences': details, 'diagnostic_only_no_crop_or_comparator_mask': True}


def strict_commands(ep, lock, commands):
    comparisons = [c for c in commands if len(c['argv']) > 1 and
                   c['argv'][1] == str(REPO/'tui-recovery/scripts/compare_frames.py')]
    expected = [a for a in lock['attempts'] if a['status'] != 'BLOCKED']
    require(len(comparisons) == len(expected), 'exact executed strict comparator command count')
    for attempt in expected:
        scenario, mode = attempt['scenario'], attempt['mode']
        suffix = '.cells.json' if mode == 'grid' else '.png'
        ref, actual = ep/'upstream'/(scenario+suffix), ep/'oc'/(scenario+suffix)
        report = ep/(scenario+'.'+mode+'-diff.json')
        argv = ['/usr/bin/python3', str(REPO/'tui-recovery/scripts/compare_frames.py'), mode,
                str(ref), str(actual), '--report', str(report)]
        found = [c for c in comparisons if c['argv'] == argv]
        require(len(found) == 1 and found[0]['exit_code'] == attempt['exit_code'] == 1,
                'exact strict argv with no mask/crop/tolerance: '+scenario+'/'+mode)
        record = load(report)
        require(json.loads(found[0]['stdout']) == record and record['kind'] == mode and
                record['status'] == 'FAIL' and record['reference_sha256'] == digest(ref) and
                record['actual_sha256'] == digest(actual), 'exact comparator output/input SHA association')
        if mode == 'grid':
            require(record['scenario'] == scenario and record['fixture_sha256'] == lock['fixture_sha256'] and
                    record['environment_id'] == producer_seal(lock['profile']) and
                    record['reference_commit'] == DONOR and record['actual_commit'] == HEAD,
                    'full styled-grid comparator metadata association')
    return {'executed':len(comparisons), 'blocked':len(lock['attempts'])-len(expected),
            'all_exact_strict_argv_and_input_output_seals':True}


def captured_source_members(commands):
    enumeration = [c for c in commands if c['argv'] ==
                   ['git','ls-files','-z','--cached','--others','--exclude-standard','--',*SCOPE]]
    require(len(enumeration) == 1 and enumeration[0]['exit_code'] == 0, 'exact captured source enumeration command')
    return {n for n in enumeration[0]['stdout'].split('\0') if n}


def side_facts(ep, side, lock, root):
    base = ep / side
    checks, protocol, inputs, spec = (load(base / n) for n in ('tool-preview-checks.json', 'protocol.json', 'inputs.json', 'bridge-spec.json'))
    require(checks == lock['tool_preview'][side] and checks['status'] == 'PASS_BEHAVIOR_ONLY', 'sealed side behavior only')
    require([s['stage'] for s in checks['stages']] == STAGES, 'all17 actual stages')
    require([s['requests'] for s in checks['stages']] == [0]+[2]*7+[3]*5+[4]*4, 'no provider request while editing/review/reopen/restart')
    require([s['calls'] for s in checks['stages']] == [0]+[1]*12+[2]*4, 'only two owned calls')
    require(spec['question_forms'] is True and spec['tool_preview'] is True and spec['isolated_root'] == str(root), 'actual exclusive fresh question root')
    launches = [e for e in protocol if e['kind'] in ('launch', 'relaunch')]
    require([p['kind'] for p in launches] == ['launch', 'relaunch'], 'one initial and one same-root relaunch')
    for p in launches:
        require(p['cwd'] == str(root/'project') and p['argv'][0] == lock[side]['executable_path'], 'actual source-sealed executable/root')
    env = launches[0]['env']
    home = root / side / 'home'
    require(env['HOME'] == env['OPENCODE_TEST_HOME'] == str(home), 'isolated home')
    for name, tail in [('CONFIG','config'),('CACHE','cache'),('DATA','data'),('STATE','state')]:
        require(env['XDG_'+name+'_HOME'] == str(home/tail), 'isolated XDG')
    require(launches[0]['version_exit'] == 0 and launches[0]['version'] == lock[side]['version'], 'captured real version')
    config = json.loads(env['OPENCODE_CONFIG_CONTENT'])
    require(config['snapshots'] is False and config['compaction']['auto'] is False and
            config['mcp'] == ({'servers': {}} if side == 'upstream' else {}), 'no extra MCP/snapshot/autoDCP effects configured')
    provider_config = config['providers' if side == 'upstream' else 'provider']['fixture']
    base_url = provider_config['settings' if side == 'upstream' else 'options']['baseURL']
    require(base_url.startswith('http://127.0.0.1:') and base_url.endswith('/v1'), 'local deterministic fixture')
    providers = [e for e in protocol if e['kind'] == 'provider']
    require(len(providers) == 4 and all(p['valid'] is True for p in providers), 'four valid real requests')
    require(collections.Counter(p['operation'] for p in providers) == {'question_main':3,'question_title':1}, 'three main/one title')
    require(collections.Counter(p['operation'] for p in protocol if p['kind'] == 'provider_completed') ==
            collections.Counter(p['operation'] for p in providers), 'all real requests completed')
    mains = [p for p in providers if p['operation'] == 'question_main']
    require([p['index'] for p in mains] == [1,2,3] and all(p['registered_tools'] == ['question'] for p in mains), 'only question catalog on three main requests')
    require([p['user_texts'] for p in mains] == [[PROMPT],[PROMPT],[PROMPT,CANCEL]], 'exact owned user texts/order')
    require(mains[0]['actual_results'] == [] and mains[1]['actual_results'] == mains[2]['actual_results'], 'unchanged accepted result on intentional second user turn')
    calls = [p for p in protocol if p['kind'] == 'fixture_tool_call']
    require([p['call_id'] for p in calls] == ['call_vis37_answer','call_vis37_cancel'] and
            all(p['name'] == 'question' for p in calls) and calls[0]['arguments'] == calls[1]['arguments'], 'exact two actual calls')
    questions = calls[0]['arguments']['questions']
    fixture_ast = ast.parse((REPO/'scripts/tui_capture/question_fixture.py').read_text())
    fixture_questions = next(ast.literal_eval(n.value) for n in fixture_ast.body if isinstance(n, ast.Assign)
                             and any(isinstance(t, ast.Name) and t.id == 'QUESTIONS' for t in n.targets))
    require(calls[0]['arguments'] == fixture_questions, 'complete actual call arguments equal sealed real fixture')
    require([q['multiple'] for q in questions] == [True,False] and [len(q['options']) for q in questions] == [2,2], 'real multiple/single question input')
    donor_result = 'User has answered your questions: ' + ', '.join('"'+q['question']+'"="'+', '.join(a)+'"' for q,a in zip(questions,ANSWERS,strict=True)) + ". You can now continue with the user's answers in mind."
    results = mains[1]['actual_results']
    require(len(results) == 1 and results[0]['type'] == 'function_call_output' and results[0]['call_id'] == 'call_vis37_answer', 'typed owned call result')
    if side == 'oc':
        require(json.loads(results[0]['output']) == {'questions':questions,'answers':ANSWERS}, 'actual full native QuestionResult wire')
    else:
        require(results[0]['output'] == donor_result, 'exact donor canonical model content wire')
    snapshots = [p for p in protocol if p['kind'] == 'tool_preview_snapshot']
    require([p['request_id'] for p in snapshots] == ['question_completed','question_reopened','question_restarted','question_dismissed','question_cancel_reopened'], 'five real snapshots')
    require(snapshots[0]['observations'] == snapshots[1]['observations'] == snapshots[2]['observations'], 'byte-exact source observation through reopen/restart')
    require(snapshots[3]['observations'] == snapshots[4]['observations'], 'byte-exact dismissed source through reopen')
    facts = checks['question_forms']
    require([facts[k] for k in ('completed','reopened','restarted','dismissed','final')] == snapshots, 'side facts actually come from recorded protocol')
    raw = []
    operations_final = []
    for i, snapshot in enumerate(snapshots):
        require(snapshot['artifacts'] == {} and snapshot['shell_effect'] is None and snapshot['mcp_calls'] == snapshot['mcp_lifecycle'] == [], 'no observed extra project/Shell/MCP effects')
        records = [o['data']['question_records'] for o in snapshot['observations'] if 'question_records' in o['data']]
        require(len(records) == 1 and records[0]['readonly'] is True, 'actual read-only source records')
        records = records[0]
        operations = records['operations']
        require(len(operations) == (1 if i < 3 else 2), 'source operation counts')
        if side == 'oc':
            completed = [o for o in operations if o['state'] == 'completed']
            require(len(completed) == 1 and completed[0]['provider_call_id'] == 'call_vis37_answer' and
                    completed[0]['output'] == results[0]['output'] and json.loads(completed[0]['input']) == calls[0]['arguments'], 'exact native durable full result and provider_call_id')
            expected = [(1,'user',PROMPT),(2,'assistant',DONE)] + ([(3,'user',CANCEL)] if i >= 3 else [])
            require([(m['seq'],m['role'],m['text']) for m in records['messages']] == expected and
                    [m['id'] for m in records['messages']] == ['m000'+str(j+1) for j in range(len(expected))], 'full native RAW IDs/seq/roles/text')
            require(all(m['session_id'] == completed[0]['session_id'] for m in records['messages']), 'RAW session association')
            for ob in snapshot['observations']:
                data = ob['data']
                require(data.get('tool_output_resources',[]) == [], 'typed output not a cold truncated envelope')
                require(all(o['name'] == 'question' for o in data.get('tool_operations',[])), 'no extra native tool operations')
                require(all(not p['presentation'].get('generated_guidance') and not p['presentation'].get('body_limited')
                            for p in data.get('presentation',[])), 'unlimited truthful result presentation')
            if i >= 3:
                cancelled = [o for o in operations if o['provider_call_id'] == 'call_vis37_cancel']
                require(len(cancelled) == 1 and cancelled[0]['state'] == 'cancelled' and cancelled[0]['output'] == 'error: question dismissed', 'durable native cancellation with no answer')
        else:
            completed = [o for o in operations if o['data']['state']['status'] == 'completed']
            require(len(completed) == 1, 'one completed Original question')
            original = completed[0]['data']
            require(original['id'] == 'call_vis37_answer' and original['state']['input'] == calls[0]['arguments'] and
                    original['state']['metadata']['answers'] == ANSWERS and
                    original['state']['content'] == [{'type':'text','text':donor_result}], 'actual Original metadata and canonical persisted content')
            messages = {m['id']:m for m in records['messages']}
            for operation in operations:
                message = messages[operation['message_id']]
                require(message['session_id'] == operation['session_id'] and message['seq'] == operation['seq'] and
                        json.loads(message['data'])['content'][operation['part_index']] == operation['data'], 'Original V2 source IDs/seq/content[] association')
            users = [json.loads(m['data'])['text'] for m in records['messages'] if m['type'] == 'user']
            require(users == [PROMPT]+([CANCEL] if i >= 3 else []), 'actual Original immutable RAW user texts')
            if i >= 3:
                dismissed = [o for o in operations if o['data']['id'] == 'call_vis37_cancel']
                require(len(dismissed) == 1 and dismissed[0]['data']['state']['status'] == 'error' and
                        not dismissed[0]['data']['state'].get('metadata',{}).get('answers'), 'Original dismissed error is not answered')
        if i == 4:
            raw, operations_final = records['messages'], operations
    restart = next(i for i,e in enumerate(protocol) if e['kind'] == 'relaunch')
    cancel = next(i for i,e in enumerate(protocol) if e['kind'] == 'provider' and e.get('operation') == 'question_main' and e.get('index') == 3)
    require(not any(e['kind'] in ('provider','fixture_tool_call') for e in protocol[restart:cancel]), 'no replay/reasking on restart')
    require(not any(e['kind'] in ('provider','fixture_tool_call') for e in protocol[cancel+2:] if e['kind'] != 'provider_completed'), 'no dismissal continuation/replay')
    decoded = [(e['kind'],base64.b64decode(e['base64'],validate=True)) for e in inputs]
    expected_input = {'question_user_prompt': b'\x1b[200~'+PROMPT.encode()+b'\x1b[201~', 'question_user_submit':b'\r',
                      'question_select_rust':b' ', 'question_select_python':b'\x1b[B ', 'question_next_field':b'\t',
                      'question_custom_select':b'3', 'question_custom_paste':b'\x1b[200~custom \xce\xa9\xe7\x95\x8c\x1b[201~',
                      'question_commit_custom':b'\r','question_explicit_reply':b'\r',
                      'question_cancel_prompt':b'\x1b[200~'+CANCEL.encode()+b'\x1b[201~', 'question_cancel_submit':b'\r',
                      'question_owned_dismiss':b'\x1b'}
    for kind, value in expected_input.items():
        require([v for k,v in decoded if k == kind] == [value], 'actual unique input gesture: '+kind)
    allowed = set(expected_input) | {'terminal_reply','question_command','question_command_enter','question_reopen',
                                    'question_clean_exit','question_actual_scroll_up','question_actual_scroll_down'}
    require(all(k in allowed for k,_ in decoded), 'no extra unowned input')
    terminal_pattern = rb'\x1b(?:\](?:10|11);rgb:[0-9a-f]{4}/[0-9a-f]{4}/[0-9a-f]{4}\x1b\\|\[\d+;\d+R|\[\?\d+;[0-4]\$y|\[\?\d+;\d+c|\[I)'
    require(all(re.fullmatch(terminal_pattern,v) for k,v in decoded if k == 'terminal_reply'),
            'automatic terminal replies only color/cursor/mode/device/focus negotiation')
    require([v for k,v in decoded if k == 'question_command'] == [b'/new',b'/sessions',b'/sessions',b'/new',b'/sessions'] and
            [v for k,v in decoded if k == 'question_command_enter'] == [b'\r']*5 and
            len([v for k,v in decoded if k == 'question_reopen']) == 3 and
            [v for k,v in decoded if k == 'question_clean_exit'] == [b'\x03'], 'exact view-only navigation and one clean restart input')
    for kind in ('question_actual_scroll_up','question_actual_scroll_down'):
        require(len([v for k,v in decoded if k == kind]) <= 8, 'bounded real scrolling')
    require(facts['answers'] == ANSWERS and facts['provider_requests'] == 4 and facts['main_requests'] == 3 and
            facts['explicit_user_submissions'] == 2 and facts['explicit_answer_submissions'] == 1 and facts['question_calls'] == 2,
            'consistent observed question facts')
    exits = [e for e in protocol if e['kind'] == 'exit']
    require(len(exits) == 2 and exits[0]['generation'] == 0 and exits[0]['code'] == 0 and
            exits[0]['termination'] == 'natural' and exits[1]['generation'] == 1 and
            exits[1]['termination'] == 'forced_stop',
            'actual clean first lifecycle and disclosed forced final harness teardown')
    return {'status':checks['status'],'stages':len(checks['stages']), 'provider_requests':4,'main_requests':3,'title_requests':1,
            'explicit_user_enters':2,'explicit_answer_submissions':1,'calls':2,'snapshots':5,
            'typed_answers':ANSWERS,'wire_output':results[0]['output'], 'wire_output_sha256':hashlib.sha256(results[0]['output'].encode()).hexdigest(),
            'providers':providers,'final_source_operations':operations_final,'final_raw_messages':raw,
            'full_source_observation_seals':[canonical_sha(s['observations']) for s in snapshots],
            'no_edit_review_generation':True,'no_reopen_restart_replay':True,'cancel_not_answered':True,
            'no_observed_extra_project_shell_mcp_dcp_effects':True,'launch_root':str(root),'exits':exits,
            'input_kind_counts':dict(collections.Counter(k for k,_ in decoded)),
            'final_teardown_scope':'Generation1 forced by capture harness; not a clean-final-lifecycle proof'}


def inspect():
    result = {}
    for ep in [CURRENT/n for n in PROFILES] + [OLD/'wide']:
        lock = load(ep/'capture.lock.json')
        p = {'lock_fields':list(lock), 'profile':lock.get('profile'), 'capture':lock['captures'][0],
             'upstream':lock['upstream'],'source_count':len(load(ep/'source-manifest.json')),
             'commands_first':load(ep/'commands.json')[0], 'sides':{}}
        for side in ('upstream','oc'):
            proto = load(ep/side/'protocol.json')
            checks = load(ep/side/'tool-preview-checks.json')
            render = load(ep/side/'tool-preview-question-home.render.json')
            p['sides'][side] = {'status':checks['status'],'stages':len(checks['stages']), 'reason':checks.get('reason'),
                'protocol_kinds':dict(collections.Counter(e['kind'] for e in proto)), 'exits':[e for e in proto if e['kind']=='exit'],
                'render_fields':list(render),'render_stability':{k:v for k,v in render.items() if k not in ('before','after')}}
        result[str(ep)] = p
    result['owned_quota'] = owned_allocation()
    result['drivers'] = {p.name:p.read_text()[-2048:] for p in CURRENT.glob('driver-*.log')}
    print(json.dumps(result,ensure_ascii=False,indent=2))


def detail():
    old = load(OLD/'wide/capture.lock.json')
    facts = {'old_capture_status':dict(collections.Counter(c['status'] for c in old['captures'])),
             'old_capture_count':len(old['captures']), 'old_attempts':old['attempts'],
             'old_commands':[{'argv':c['argv'],'exit_code':c['exit_code']} for c in load(OLD/'wide/commands.json')],
             'current_owner':(CURRENT/'owner.txt').read_text(), 'failed_owner':(OLD/'owner.txt').read_text(),
             'cards':{}}
    for p in PROFILES:
        grids = {s:load(CURRENT/p/s/'tool-preview-question-answered-card.cells.json') for s in ('oc','upstream')}
        metric,diffs = compare_grid(grids['upstream'],grids['oc'])
        facts['cards'][p] = answered_owner(grids,diffs)
    print(json.dumps(facts,ensure_ascii=False,indent=2))


def main():
    require(os.getuid() != 0 and Path(os.environ['TMPDIR'])/'opencode' == TEMP, 'approved nonroot TMP only')
    require(Path(__file__).parent == HERE and not (HERE/'report.json').exists(), 'exclusive scratch/report')
    if sys.argv[1:] == ['--inspect']:
        inspect()
        return
    if sys.argv[1:] == ['--detail']:
        detail()
        return
    require(sys.argv[1:] == [], 'only bounded read-only verifier modes')
    started = time.monotonic()
    quota_before = owned_allocation()
    require(quota_before['headroom_bytes'] > 1024**2, 'owned 1GiB guard before report')
    paths = [CURRENT, OLD, TEMP/'vis37-capture.py', TEMP/'vis37-capture-r2.py']
    before = {str(p):inventory(p) for p in paths}
    require(sum(i['logical_bytes'] for i in before.values()) <= TOTAL and sum(i['members'] for i in before.values()) <= MEMBERS,
            'entire selected4 episodes/helpers/member logical bounds')
    require(git('rev-parse','HEAD').decode().strip() == HEAD, 'actual exact HEAD')
    actual_tree = git('rev-parse','HEAD^{tree}').decode().strip()
    names = {n for n in git('ls-files','-z','--cached','--others','--exclude-standard','--',*SCOPE).decode().split('\0') if n and (REPO/n).exists()}
    manifests, locks, results = {}, {}, {}
    current_hashes = {n:digest(REPO/n) for n in names}
    input_source_bytes = sum((REPO/n).stat().st_size for n in names)
    require(len(names) <= MEMBERS and input_source_bytes <= TOTAL and all((REPO/n).stat().st_size <= FILE for n in names), 'bounded current source set')
    require(input_source_bytes+sum(i['logical_bytes'] for i in before.values()) <= TOTAL,
            'source plus capture selected logical inputs together <=128MiB')
    drivers = {}
    for name, root in [('current',CURRENT),('failed',OLD)]:
        require('sole-parent' in (root/'owner.txt').read_text(), 'direct parent ownership marker retained')
        for p in root.glob('driver-*.log'):
            driver = load(p)
            drivers[str(p)] = {'sha256':digest(p),'bytes':p.stat().st_size,'data':driver}
    for profile, dimensions in PROFILES.items():
        ep = CURRENT/profile
        lock, manifest, commands = (load(ep/n) for n in ('capture.lock.json','source-manifest.json','commands.json'))
        locks[profile], manifests[profile] = lock, manifest
        require(lock['oc']['commit'] == HEAD and lock['oc']['tree'] == actual_tree and lock['sources']['upstream_commit'] == DONOR, 'captured HEAD/tree/pinned donor')
        require(set(manifest) == names and manifest == current_hashes, 'exact derived current source membership and every source byte: '+profile)
        require(captured_source_members(commands) == set(manifest), 'captured actual enumeration equals derived source membership')
        require(producer_seal(manifest) == lock['oc']['source_manifest_sha256'], 'producer canonical complete manifest seal')
        require(lock['profile']['question_forms'] is True and
                (lock['profile']['columns'],lock['profile']['rows']) == dimensions and
                lock['profile']['refresh_before_capture'] is False and
                lock['profile']['same_side_identical_png_links'] is False and
                lock['profile']['cells_encoding'] == 'json' and lock['profile']['frame_sidecars_encoding'] == 'plain',
                'actual original plain full-frame profile without byte rewriting')
        fixture_files = {p.name:digest(p) for p in (REPO/'tui-recovery/fixtures').iterdir()}
        require(fixture_files == lock['fixture_files'], 'exact real input fixture bytes')
        fixture_object = {'files':fixture_files,'sample':'short','variants':False,'question_forms':True,
                          'probe':manifest['scripts/tui_capture/tool_preview.mjs'],
                          'fixture':manifest['scripts/tui_capture/tool_preview_fixture.py'],
                          'tool_preview':True,'mcp_status':False,'mcp_footer':None,
                          'mcp':manifest['scripts/tui_capture/tool_preview_mcp.py'],
                          'models_interaction':False,'protocol':manifest['scripts/tui_capture/bridge.py']}
        # The exact existing producer object spreads assign probe/fixture again
        # for toolPreview. Independent question probe/fixture seals remain in
        # runner_hashes and the complete source manifest; do not invent a seal.
        require(producer_seal(fixture_object) == lock['fixture_sha256'], 'exact fixture producer seal including actual spread semantics')
        environment = producer_seal(lock['profile'])
        for n,seal in lock['runner_hashes'].items():
            require(manifest['scripts/tui_capture/'+n] == seal, 'sealed runner/source owner')
        diffs = [c for c in commands if c['argv'] == ['git','diff','--binary']]
        require(len(diffs) == 1 and hashlib.sha256(diffs[0]['stdout'].encode()).hexdigest() == lock['oc']['dirty_diff_sha256'], 'captured full dirty diff seal')
        builds = [c for c in commands if c['argv'][0] == 'cargo']
        require(len(builds) == 1 and builds[0]['argv'] == ['cargo','build','--locked'] and builds[0]['exit_code'] == 0 and
                lock['oc']['build_command'] == builds[0]['argv'], 'one actual successful locked build per profile')
        invocation = commands[0]
        options = dict(zip(invocation['argv'][2::2],invocation['argv'][3::2],strict=True))
        require(invocation['role'] == 'capture runner invocation' and invocation['exit_code'] == 1 and options == {
                '--reference':str(TEMP/'t44-reference/package/bin/opencode'),'--oc':str(REPO/'target/debug/oc'),
                '--build-oc':'true','--geometry':'true','--sample':'short','--sidebar':'hide',
                '--tool-preview':'true','--question-forms':'true','--columns':str(dimensions[0]),'--rows':str(dimensions[1]),'--output':str(ep)}, 'exact exclusive capture invocation')
        profile_drivers = [d['data'] for d in drivers.values() if d['data']['output'] == str(ep)]
        require(len(profile_drivers) == 1 and profile_drivers[0]['exit_code'] == lock['exit_code'] == 1 and
                profile_drivers[0]['attempts'] == lock['attempts'], 'direct driver result matches exact sealed capture lock')
        require(len(lock['captures']) == len(lock['attempts']) == 34 and
                all(a['status'] == 'DIFFERENT' and a['exit_code'] == 1 for a in lock['attempts']), 'all34 strict comparisons remain different')
        require({(a['scenario'],a['mode']) for a in lock['attempts']} == {('tool-preview-'+s,m) for s in STAGES for m in ('grid','png')}, 'exact all17x2 comparison membership')
        comparator_commands = strict_commands(ep,lock,commands)
        root = TEMP/'t44-reference/runs'/(profile+'-'+hashlib.sha256(str(ep).encode()).hexdigest()[:12])
        sides = {s:side_facts(ep,s,lock,root) for s in ('upstream','oc')}
        captures = {(c['origin'],c['scenario']):c for c in lock['captures']}
        require(len(captures) == 34, 'unique34 actual captured frames')
        pairs, answered = [], None
        for stage in STAGES:
            scenario, grids, renders = 'tool-preview-'+stage, {}, {}
            for side in ('upstream','oc'):
                c = captures[(side,scenario)]
                require(c['status'] == 'CAPTURED_TOOL_PREVIEW', 'actual stable capture')
                for field,suffix in [('cells','.cells.json'),('png','.png'),('render','.render.json'),('text','.txt'),('vt','.vt')]:
                    require(digest(ep/side/(scenario+suffix)) == c[field+'_sha256'], 'exact full original sidecar seal')
                g,r = load(ep/side/(scenario+'.cells.json')),load(ep/side/(scenario+'.render.json'))
                grids[side],renders[side] = g,r
                require((g['columns'],g['rows']) == dimensions and r['origin'] == side and r['scenario'] == scenario and
                        r['environment_id'] == g['environment_id'] == c['environment_id'] == environment and
                        g['fixture_sha256'] == lock['fixture_sha256'], 'actual profile/full frame association')
                require(r['terminal_refresh_from_buffer'] is False and r['layout_changed_during_screenshot'] is False,
                        'no synthetic repaint and stable real screen')
                screen = r['after']['screen_rect']
                require(r['before']['screen_rect'] == screen and r['screenshot']['clip'] == {k:screen[k] for k in ('x','y','width','height')}, 'entire terminal screenshot, never cropped partial owner')
                require(r['after']['logical_buffer_cursor'] == {k:g['cursor'][k] for k in ('x','y')} and
                        lock['tool_preview'][side]['stages'][STAGES.index(stage)]['cursor'] == g['cursor'], 'actual stage/render/grid cursor association')
            grid,diffs = compare_grid(grids['upstream'],grids['oc'])
            png = compare_png(ep/'upstream'/(scenario+'.png'),ep/'oc'/(scenario+'.png'))
            recorded_grid,recorded_png = load(ep/(scenario+'.grid-diff.json')),load(ep/(scenario+'.png-diff.json'))
            for metric,record in ((grid,recorded_grid),(png,recorded_png)):
                require(record['status'] == 'FAIL', 'strict real nonpass')
                for k,v in metric.items():
                    if k != 'different_fields':
                        require(record[k] == v, 'independent full comparator agrees: '+k)
            for side in ('upstream','oc'):
                require(png['width'] == renders[side]['screenshot']['png_width'] and png['height'] == renders[side]['screenshot']['png_height'], 'full actual pixel dimensions')
            require(grid['different_cells'] > 0 and png['different_pixels'] > 0, 'strict residuals in both independent comparisons')
            pairs.append({'stage':stage,'grid':grid,'png':png,'cursors':{s:g['cursor'] for s,g in grids.items()}})
            if stage == 'question-answered-card':
                answered = answered_owner(grids,diffs)
                answered['full_frame_grid'],answered['full_frame_png'] = grid,png
        results[profile] = {'seals':{n:digest(ep/n) for n in ('capture.lock.json','source-manifest.json','commands.json','tooling.package-lock.json')},
             'producer_canonical_source_seal':lock['oc']['source_manifest_sha256'], 'dirty_diff_seal':lock['oc']['dirty_diff_sha256'],
             'runner_hashes':lock['runner_hashes'],'captured_one_build':builds[0], 'captured_invocation':invocation,
             'actual_profile':lock['profile'],'fixture_sha256':lock['fixture_sha256'],'environment_id':environment,
             'side_inventory':{s:{k:v for k,v in inventory(ep/s).items() if k != 'rows'} for s in ('oc','upstream')},
              'facts':sides,'pairs':pairs,'answered_card':answered,'fresh_hash_root':str(root)}
        results[profile]['strict_comparator_commands'] = comparator_commands
    require(all(m == manifests['wide'] for m in manifests.values()), 'all3 producer source byte identities equal')
    identities = {s:elf(locks['wide'][s]['executable_path']) for s in ('oc','upstream')}
    for side in ('oc','upstream'):
        captured = {l[side]['executable_sha256'] for l in locks.values()}
        require(len(captured) == 1, 'one fixed ELF captured on all3 geometries')
        identities[side]['captured_sha256'] = next(iter(captured))
        identities[side]['matches_captured_now'] = identities[side]['sha256'] == next(iter(captured))
    require(identities['upstream']['matches_captured_now'] and identities['upstream']['sha256'] == ORIGINAL_SHA, 'actual pinned Original ELF')
    previous_lock = load(OLD/'wide/capture.lock.json')
    old_manifest = load(OLD/'wide/source-manifest.json')
    require(producer_seal(old_manifest) == previous_lock['oc']['source_manifest_sha256'], 'failed001 manifest producer seal intact')
    old_commands = load(OLD/'wide/commands.json')
    require(captured_source_members(old_commands) == set(old_manifest) == names and
            previous_lock['oc']['commit'] == HEAD and previous_lock['oc']['tree'] == actual_tree and
            previous_lock['sources']['upstream_commit'] == DONOR, 'failed001 captured membership and pinned source identities')
    old_drivers = [d['data'] for d in drivers.values() if d['data']['output'] == str(OLD/'wide')]
    require(len(old_drivers) == 1 and old_drivers[0]['exit_code'] == previous_lock['exit_code'] == 1 and
            old_drivers[0]['attempts'] == previous_lock['attempts'], 'failed direct-driver/capture-lock association')
    old_comparators = strict_commands(OLD/'wide',previous_lock,old_commands)
    old_diffs = [c for c in old_commands if c['argv'] == ['git','diff','--binary']]
    require(len(old_diffs) == 1 and hashlib.sha256(old_diffs[0]['stdout'].encode()).hexdigest() == previous_lock['oc']['dirty_diff_sha256'], 'prior dirty diff retained seal')
    old_builds = [c for c in old_commands if c['argv'][0] == 'cargo']
    require(len(old_builds) == 1 and old_builds[0]['argv'] == ['cargo','build','--locked'] and old_builds[0]['exit_code'] == 0, 'failed capture still one successful actual build')
    for n,seal in previous_lock['runner_hashes'].items():
        require(old_manifest['scripts/tui_capture/'+n] == seal, 'prior source/runner seal association')
    for c in previous_lock['captures']:
        for field,suffix in [('cells','.cells.json'),('png','.png'),('render','.render.json'),('text','.txt'),('vt','.vt')]:
            require(digest(OLD/'wide'/c['origin']/(c['scenario']+suffix)) == c[field+'_sha256'], 'every failed prior capture byte seal retained')
    previous = {'seals':{n:digest(OLD/'wide'/n) for n in ('capture.lock.json','source-manifest.json','commands.json','tooling.package-lock.json')},
                'producer_canonical_source_sha256':previous_lock['oc']['source_manifest_sha256'],
                'dirty_diff_sha256':previous_lock['oc']['dirty_diff_sha256'],'source_members':len(old_manifest),
                'runner_hashes':previous_lock['runner_hashes'],'captured_build':old_builds[0],
                'capture_count':len(previous_lock['captures']),'attempts':previous_lock['attempts'],
                'strict_comparator_commands':old_comparators,
                'side_inventory':{s:{k:v for k,v in inventory(OLD/'wide'/s).items() if k!='rows'} for s in ('oc','upstream')},'sides':{}}
    old_pairs = []
    scenarios = {a['scenario'] for a in previous_lock['attempts'] if a['status'] == 'DIFFERENT'}
    for scenario in sorted(scenarios):
        grid,_ = compare_grid(load(OLD/'wide/upstream'/(scenario+'.cells.json')), load(OLD/'wide/oc'/(scenario+'.cells.json')))
        png = compare_png(OLD/'wide/upstream'/(scenario+'.png'),OLD/'wide/oc'/(scenario+'.png'))
        for metric,mode in ((grid,'grid'),(png,'png')):
            record = load(OLD/'wide'/(scenario+'.'+mode+'-diff.json'))
            require(all(record[k] == v for k,v in metric.items() if k != 'different_fields'),
                    'independent failed001 full comparator agrees')
        old_pairs.append({'scenario':scenario,'grid':grid,'png':png})
    previous['independently_recounted_paired_frames'] = old_pairs
    for side in ('oc','upstream'):
        p = OLD/'wide'/side
        checks,proto = load(p/'tool-preview-checks.json'),load(p/'protocol.json')
        providers = [e for e in proto if e['kind']=='provider']
        previous['sides'][side] = {'status':checks['status'],'stages':len(checks['stages']),'reason':checks.get('reason'),
             'png_files':len(list(p.glob('*.png'))),'providers':providers,'failure_frames':[f.name for f in p.glob('*failure*')]}
    require(previous['sides']['upstream']['status'] == previous['sides']['oc']['status'] == 'FAILED' and
            previous['sides']['upstream']['stages'] == 9 and previous['sides']['oc']['stages'] == 14, 'preserved actual first failure statuses')
    require([len(previous['sides'][s]['providers']) for s in ('upstream','oc')] == [3,4] and
            sum(s['png_files'] for s in previous['sides'].values()) == 25 and
            all(p['valid'] is True for s in previous['sides'].values() for p in s['providers']), 'preserved25 prior wholePNGs and known partial valid wire')
    previous['source_differences_from_current'] = {n:{'failed':old_manifest.get(n),'current':current_hashes.get(n)} for n in old_manifest.keys()|names if old_manifest.get(n) != current_hashes.get(n)}
    previous['native_captured_same_elf'] = previous_lock['oc']['executable_sha256'] == locks['wide']['oc']['executable_sha256']
    require(set(previous['source_differences_from_current']) == {
                'scripts/tui_capture/question_fixture.py','scripts/tui_capture/question_forms.mjs',
                'scripts/tui_capture/test_question_fixture.py'} and
            previous['native_captured_same_elf'], 'only observer and its regression test changed between captures, same native ELF')
    source = (REPO/'scripts/tui_capture/capture.mjs').read_text()
    require('|| questionForms' in source and "path.basename(output)+'-'+sha(Buffer.from(output)).slice(0,12)" in source and
            'if(freshRoot && fs.existsSync(isolated))throw Error' in source, 'sealed exclusive full-output SHA root/preexisting refusal')
    require('const key = sha(JSON.stringify(f));' in source and 'stable = key===previous ? stable+1 : 0;' in source and
            'stable >= 4' in source and 'await sleep(200);' in source and
            'sha(JSON.stringify(afterFrame)) !== sha(JSON.stringify(f))' in source, 'sealed five-full-grid/cursor observations and through-paint stability enforcement')
    observer = (REPO/'scripts/tui_capture/tool_preview_fixture.py').read_text()
    require("database.as_uri()+'?mode=ro'" in observer, 'actual captured source DB observer opens read-only')
    after = {str(p):inventory(p) for p in paths}
    require(before == after, 'all selected current/failed capture files and metadata byte-exact through independent audit')
    require({n:digest(REPO/n) for n in names} == current_hashes, 'every captured source byte remains current after audit')
    pairs = [p for r in results.values() for p in r['pairs']]
    totals = {'profiles':3,'stages_per_side_per_profile':17,'captured_whole_pngs':102,'paired_frames':51,'strict_comparisons':102,
              'strict_status_counts':{'DIFFERENT':102},'checked_cells':sum(p['grid']['cells_checked'] for p in pairs),
              'different_cells':sum(p['grid']['different_cells'] for p in pairs),'checked_pixels':sum(p['png']['pixels_checked'] for p in pairs),
              'different_pixels':sum(p['png']['different_pixels'] for p in pairs),'equal_cursor_pairs':sum(not p['grid']['cursor_differs'] for p in pairs),
              'different_cursor_pairs':sum(p['grid']['cursor_differs'] for p in pairs),'valid_provider_requests':24,'main_requests':18,'title_requests':6,
              'actual_question_calls':12,'explicit_user_enters':12,'explicit_answer_submissions':6,'readonly_snapshots':30}
    quota_after = owned_allocation()
    result = {'schema_version':1,'status':'INDEPENDENT_QUALIFIED_BEHAVIOR_SLICE_ONLY_STRICT_PARITY_NOT_PASS',
              'head':HEAD,'donor':DONOR,'elapsed_seconds':round(time.monotonic()-started,3),'totals':totals,
              'source':{'derived_members':len(names),'logical_bytes':input_source_bytes,'exact_current_membership_all_bytes':True,
                        'all_three_manifests_equal':True,'producer_canonical_sha256':producer_seal(manifests['wide']),
                        'observed_current_dirty_paths':git('diff','--name-only').decode().splitlines()},
              'executables':identities,'profiles':results,'preserved_failed001':previous,
              'direct_parent_drivers':drivers,
              'capture_stability':{'source_enforced_identical_full_grid_cursor_polls':5,'poll_spacing_ms':200,
                  'through_png_paint_stability_enforced':True,'successful_poll_trace_serialized':False,
                  'scope':'Five polls independently source-verified; actual CAPTURED_TOOL_PREVIEW seals prove producer accepted it, not independently timed sampling'},
               'pending_form_residual':{'owner':'crates/oc-tui/src/question_view.rs:276-445',
                  'original_owner':'opencode/packages/tui/src/routes/session/form.tsx:767-982',
                  'observed_wide':'Original left-bordered/padded Questions title starts y24 (zero-based), native unbordered Question · session · Awaiting answer starts y31. Native full headers/inline descriptions do not match Original truncated24-character tabs and separate description rows.',
                   'action':'Implement the pinned FormPrompt layout/theme/field-row contract in the existing native question_view owner; use these complete unchanged captures to qualify the next bounded source change.',
                   'backend_owner_change_required':False},
               'prerequisite_source_review':{'executed_by_this_verifier':False,
                   'new_native_pty_owner':'crates/oc/tests/pty_t39/question.rs',
                   'reviewed_three_cases':['--auto owned reply, explicit custom review, typed wire and unchanged RAW through clean restart',
                       'Escape durable cancellation, no answer/replay through clean restart',
                       'headless --auto QuestionRequired, failed operation, no answer'],
                   'existing_adapter_owner':'crates/oc-adapters/tests/fixtures/question_lifecycle.rs',
                   'reviewed_adapter_contract':'Binding/stale/invalid answer guards; peer asserts durable completed output before provider continuation; no reasking after restart',
                   'scope':'Source review only. Parent reported three PTY PASS; independent qualification here is existing captures, not a rerun of Cargo/PTY/headless gates.'},
              'byte_and_metadata_preservation':before,'helper_sha256':digest(__file__),
              'resources':{'hard_address_space_bytes':AS,'hard_each_output_file_bytes':FILE,'selected_logical_bytes_bound':TOTAL,
                    'selected_members_bound':MEMBERS,'xz_dictionary_bytes_bound':XZ_DICT,'xz_decoder_bytes_bound':XZ_DECODE,
                    'xz_usage':'NOT_USED: original loose files inspected, no archive created/decoded',
                     'owned_evidence_quota_before':quota_before,'owned_evidence_quota_after':quota_after,
                     'selected_members':sum(i['members'] for i in before.values()),'selected_logical_bytes':sum(i['logical_bytes'] for i in before.values()),
                     'selected_source_plus_capture_logical_bytes':input_source_bytes+sum(i['logical_bytes'] for i in before.values()),
                     'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024},
              'scope':'Existing atomic captures only; no Cargo/runtime/provider/capture/install/env/worktree writes. No wider old-artifact byte claim. No VIS37/R6/T44 PASS. Full comparator has no golden/crop/mask/tolerance or clock normalization.'}
    report = json.dumps(result,ensure_ascii=False,indent=2).encode()+b'\n'
    require(len(report) <= FILE and quota_after['allocated_bytes']+sum(p.stat().st_blocks*512 for p in HERE.iterdir())+len(report)+8192 <= OWNED,
            'same total1GiB guard including new helper/report')
    fd = os.open(HERE/'report.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(report)
        stream.flush()
        os.fsync(stream.fileno())
    summary = {k:v for k,v in result.items() if k in ('status','head','elapsed_seconds','totals','source','executables','resources','helper_sha256')}
    summary['seals'] = {p:r['seals'] for p,r in results.items()}
    summary['answered_cards'] = {p:{k:v for k,v in r['answered_card'].items() if k not in ('owner_rows','owner_differences')} for p,r in results.items()}
    summary['report_sha256'],summary['report_bytes'] = digest(HERE/'report.json'),len(report)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
