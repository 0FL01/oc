#!/usr/bin/env python3
"""Retain v1 verifier unchanged; disambiguate pending title from answered card."""
import sys
sys.dont_write_bytecode = True
import importlib.util
from pathlib import Path

HERE = Path('/home/opencode/.cache/opencode-tmp/opencode/vis37-form-independent-20261012-sole-verifier')
spec = importlib.util.spec_from_file_location('sealed_initial_form_verifier', HERE / 'verifier.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

def owner(grids, title):
    ranges = {}
    for side, grid in grids.items():
        hits = []
        for y, row in enumerate(grid['cells']):
            text = ''.join(c['symbol'] for c in row)
            if text.replace('┃', '').strip() != title:
                continue
            title_x = text.index(title)
            borders = [x for x, c in enumerate(row) if c['symbol'] == '┃' and x < title_x]
            if borders:
                hits.append((y, max(borders)))
        v.inverse.require(len(hits) == 1, f'unique exact {title} header on {side}/{grid["scenario"]}: {hits}')
        y, x = hits[0]
        first = last = y
        while first > 0 and grid['cells'][first-1][x]['symbol'] == '┃': first -= 1
        while last+1 < grid['rows'] and grid['cells'][last+1][x]['symbol'] == '┃': last += 1
        ranges[side] = [first, last, x]
    aligned = ranges['oc'] == ranges['upstream']
    differences = []
    if aligned:
        for y in range(ranges['oc'][0], ranges['oc'][1]+1):
            for x, (a, b) in enumerate(zip(grids['upstream']['cells'][y], grids['oc']['cells'][y], strict=True)):
                if a != b: differences.append({'x': x, 'y': y, 'original': a, 'native': b})
    return {'geometry': ranges, 'aligned': aligned, 'all_owner_styled_cells_equal': aligned and not differences,
            'differences': differences, 'diagnostic_only_full_frames_remain_strictly_compared': True}

v.owner = owner
write = v.write
def refined_write(name, report):
    report['observer_refinement'] = {'path': str(Path(__file__)), 'sha256': v.inverse.digest(__file__),
                                   'cause': 'Cancel-pending frame legitimately contains both completed # Questions and pending Questions titles; v1 substring owner selector was ambiguous. All capture bytes and v1 helper/prepack inventory remain unchanged.'}
    write(name, report)
v.write = refined_write
if __name__ == '__main__':
    v.inverse.require(v.inverse.digest(v.HERE / 'verifier.py') == v.inverse.load(v.HERE / 'before.json')['helper_sha256'], 'sealed initial helper unchanged')
    v.after()
