"""Bounded complete header-color gates and read-only facts; independent inverse."""
import sys
sys.dont_write_bytecode=True
import importlib.util
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS,(384*1024**2,384*1024**2))
REPO=Path('/home/opencode/ai/oc')
TMP=Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT=REPO/'evidence/tui'
sys.path.insert(0,str(REPO/'scripts'))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
observer=module('immutable_header_delivery_inverse',TMP/'vis37-form-independent-20261012-sole-verifier/owner_refinement.py')
check=observer.v.inverse
final=check.load(OUT/'vis37-tab-color-final-after.json')
if sys.argv[1:]==['facts']:
    print(json.dumps(dict(source=final['source'],totals=final['totals'],preserved=final['preserved_prior_proofs'],
                         receipts={p.name:check.load(p) for p in (OUT/'vis37-form-r9-proof.inventory.json',OUT/'vis37-form-r10-proof.inventory.json')},
                         quota=check.quota()),indent=2))
    raise SystemExit()
check.require(sys.argv[1:]==['pack'],'facts or exclusive pack')
proof=module('header_gate_producer',REPO/'scripts/retain_syntax_proof.py')
failed={'tab-padding-role-red':101,'tab-padding-role-green':101,'tab-padding-workspace':101,
        'tab-padding-pulse-stop-red':101,'tab-padding-workspace-final':101}
records={p:check.load(p) for p in sorted(TMP.glob('vis37-form-gate-tab-padding-*.json'))}
labels={r['label'] for r in records.values()}
check.require(set(failed)<=labels,'all failed observations retained')
required={'tab-padding-workspace-complete','tab-padding-clippy-final','tab-padding-fmt-final',
          'tab-padding-debug-locked','tab-padding-debug-ordinary','tab-padding-debug-help','tab-padding-release-build',
          'tab-padding-release-help','tab-padding-python-final','tab-padding-question-python','tab-padding-r10-after',
          'tab-padding-docs-final','tab-padding-progress-final'}
check.require(required<=labels,'complete final code and delivery gates')
paths=[]
for path,record in records.items():
    check.require(record['exit_code']==failed.get(record['label'],0),'honest complete command result')
    paths.extend((path,Path(record['log'])))
workspace=next(r for r in records.values() if r['label']=='tab-padding-workspace-complete')
check.require((workspace['passed'],workspace['failed'],workspace['ignored'],workspace['rust_targets'])==(1858,0,11,46),'actual final workspace totals')
release=[r for r in records.values() if r['label'].startswith('tab-padding-release-') and r['rust_targets']]
check.require(len(release)==7 and sum(r['passed'] for r in release)==9 and not any(r['failed'] or r['ignored'] for r in release),'nine actual release/resource cases')
for label,count in (('tab-padding-python-final',68),('tab-padding-question-python',2)):
    record=next(r for r in records.values() if r['label']==label)
    check.require(f'Ran {count} tests in '.encode() in check.read_bytes(record['log']),'complete stdlib unittest count')
paths.extend((TMP/'vis37-form-gate-20261012.py',TMP/'vis37-model004-archival-audit.py',Path(__file__)))
files={'gates/'+p.name:check.read_bytes(p) for p in paths}
check.require(len(files)==len(paths),'unique original members')
expected={'gates/'+p.name:dict(path=str(p),bytes=len(files['gates/'+p.name]),sha256=check.sha(files['gates/'+p.name])) for p in paths}
proof.ROOTS=check.ROOTS={'gates':TMP}
encoded,raw_sha,raw_bytes=proof.encode(files,{})
def inverse(data):
    raw,xz=check.inverse_xz(data)
    restored,meta=check.inverse_ustar(raw,expected)
    check.require(restored==files and check.sha(raw)==raw_sha,'every complete original gate/program byte and canonical TAR')
    return xz,meta
xz,meta=inverse(encoded)
archive,receipt=OUT/'vis37-tab-color-gates.tar.xz',OUT/'vis37-tab-color-gates.inventory.json'
check.require(not archive.exists() and not receipt.exists(),'exclusive durable proof')
record=dict(version=1,codec='USTAR/single-XZ original full logs; independent manual inverse',archive_sha256=check.sha(encoded),archive_bytes=len(encoded),
            tar_sha256=raw_sha,tar_bytes=raw_bytes,inventory=meta['inventory'],labels={r['label']:r['exit_code'] for r in records.values()},
            current_source=final['source'],helper_sha256=check.digest(Path(__file__)),xz=xz)
data=(json.dumps(record,indent=2)+'\n').encode()
check.require(proof.storage.owned_allocation()+sum((n+4095)//4096*4096 for n in (len(encoded),len(data)))<=proof.storage.CAP,'unchanged actual allocated cap')
proof.storage.durable(archive,encoded)
proof.storage.durable(receipt,data)
inverse(check.read_bytes(archive))
print(json.dumps(dict(status='FULL_BYTE_EXACT_INDEPENDENT_GATES',archive_bytes=len(encoded),archive_sha256=check.sha(encoded),inventory=meta['inventory'],
                      actual_labels=len(records),memory=check.proc_memory(),quota=check.quota())))
