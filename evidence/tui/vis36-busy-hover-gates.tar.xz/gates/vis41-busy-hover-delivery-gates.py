"""Complete busy-hover command bytes with a bounded, independent manual inverse."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO / 'evidence/tui'
sys.path.insert(0, str(REPO / 'scripts'))
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
observer = module('busy_hover_manual_inverse', TMP / 'vis37-form-independent-20261012-sole-verifier/owner_refinement.py')
check = observer.v.inverse
storage = module('busy_hover_actual_allocation', REPO / 'scripts/archive_failed_capture.py')
def quota():
    allocated = storage.owned_allocation()
    check.require(allocated <= storage.CAP and 'vis36-' in storage.PREFIXES, 'unchanged additive allocation cap')
    return dict(allocated_bytes=allocated, quota_bytes=storage.CAP, headroom_bytes=storage.CAP-allocated)
final = check.load(OUT / 'vis41-busy-hover-final-after.json')
if sys.argv[1:] == ['facts']:
    archival = check.load(OUT / 'model-shell-tool-regression-001.archived.json')
    receipts = {name: check.load(OUT / (name + '.inventory.json')) for name in (
        'vis36-busy-hover-wide-proof', 'vis36-busy-hover-small-proof',
        'vis36-busy-hover-r3-wide-proof', 'vis36-busy-hover-r3-small-proof')}
    actual_source = final['source_and_elf']
    source = dict(manifest_sha256=check.producer_sha(actual_source['source']), input_count=len(actual_source['source']), elf=actual_source['elf'])
    compact_receipts = {name:{k:v for k,v in r.items() if k not in ('source_roots','producer_reports')} for name,r in receipts.items()}
    print(json.dumps(dict(source=source, totals=final['totals'], memory=final['memory'],
        preserved_prior_proofs=final['preserved_prior_proofs'], receipts=compact_receipts,
        archival={k:v for k,v in archival.items() if k not in ('original_files','original_directories')}, quota=quota()), indent=2))
    raise SystemExit()
check.require(sys.argv[1:] == ['pack'], 'facts or exclusive pack')
producer = module('busy_hover_gate_producer', REPO / 'scripts/retain_syntax_proof.py')
records = {p:check.load(p) for p in sorted(TMP.glob('vis37-form-gate-vis41-busy-hover-*.json'))}
for label in ('vis41-close-overlay-green', 'vis41-tab-action-guards'):
    path = TMP / ('vis37-form-gate-' + label + '.json')
    records[path] = check.load(path)
failed = {'vis41-busy-hover-red':101, 'vis41-busy-hover-workspace':101}
required = {'vis41-busy-hover-green','vis41-close-overlay-green','vis41-tab-action-guards',
    'vis41-busy-hover-shell-contract','vis41-busy-hover-pty-contract','vis41-busy-hover-clippy-final',
    'vis41-busy-hover-python-storage','vis41-busy-hover-tool001-preflight','vis41-busy-hover-tool001-before',
    'vis41-busy-hover-tool001-archive','vis41-busy-hover-tool001-after','vis41-busy-hover-r3-before',
    'vis41-busy-hover-r3-wide-pack','vis41-busy-hover-r3-wide-audit','vis41-busy-hover-r3-small-pack',
    'vis41-busy-hover-r3-small-audit','vis41-busy-hover-r3-after','vis41-busy-hover-workspace-complete',
    'vis41-busy-hover-fmt','vis41-busy-hover-debug-locked','vis41-busy-hover-debug-ordinary',
    'vis41-busy-hover-debug-help','vis41-busy-hover-release-build','vis41-busy-hover-release-help',
    'vis41-busy-hover-docs-final','vis41-busy-hover-progress-final'}
check.require(required | set(failed) <= {r['label'] for r in records.values()}, 'all actual commands, including failures')
paths = []
for path, record in records.items():
    check.require(record['exit_code'] == failed.get(record['label'], 0), 'honest actual command status')
    paths.extend((path, Path(record['log'])))
workspace = next(r for r in records.values() if r['label'] == 'vis41-busy-hover-workspace-complete')
check.require((workspace['passed'],workspace['failed'],workspace['ignored'],workspace['rust_targets']) == (1868,0,11,46), 'complete current workspace')
release = [r for r in records.values() if r['label'].startswith('vis41-busy-hover-release-') and r['rust_targets']]
check.require(len(release) == 7 and sum(r['passed'] for r in release) == 9 and not any(r['failed'] or r['ignored'] for r in release), 'nine actual release/resource cases')
py = next(r for r in records.values() if r['label'] == 'vis41-busy-hover-python-storage')
check.require(b'Ran 71 tests in ' in check.read_bytes(py['log']), 'complete root Python gate')
paths.extend((TMP / 'vis37-form-gate-20261012.py', TMP / 'vis41-tool001-archival-audit.py', Path(__file__)))
files = {'gates/' + p.name:check.read_bytes(p) for p in paths}
check.require(len(files) == len(paths), 'unique complete original members')
expected = {name:dict(path=str(path), bytes=len(files[name]), sha256=check.sha(files[name])) for path in paths for name in ['gates/' + path.name]}
producer.ROOTS = check.ROOTS = {'gates':TMP}
encoded, raw_sha, raw_bytes = producer.encode(files, {})
def inverse(data):
    raw, xz = check.inverse_xz(data)
    restored, meta = check.inverse_ustar(raw, expected)
    check.require(restored == files and check.sha(raw) == raw_sha, 'every original command/program byte')
    return xz, meta
xz, meta = inverse(encoded)
archive = OUT / 'vis36-busy-hover-gates.tar.xz'
receipt = OUT / 'vis36-busy-hover-gates.inventory.json'
check.require(not archive.exists() and not receipt.exists(), 'exclusive durable outputs')
record = dict(version=1, codec='USTAR/single-XZ complete command bytes; independent manual inverse',
    archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=raw_sha, tar_bytes=raw_bytes,
    inventory=meta['inventory'], labels={r['label']:r['exit_code'] for r in records.values()},
    current_source=final['source_and_elf'], helper_sha256=check.digest(Path(__file__)), xz=xz)
data = (json.dumps(record, indent=2) + '\n').encode()
check.require(storage.owned_allocation() + sum((n+4095)//4096*4096 for n in (len(encoded),len(data))) <= storage.CAP, 'actual unchanged additive cap')
storage.durable(archive, encoded)
storage.durable(receipt, data)
inverse(check.read_bytes(archive))
print(json.dumps(dict(status='FULL_BYTE_EXACT_INDEPENDENT_BUSY_HOVER_GATES', archive_bytes=len(encoded),
    archive_sha256=check.sha(encoded), inventory=meta['inventory'], actual_labels=len(records), memory=check.proc_memory(), quota=quota())))
