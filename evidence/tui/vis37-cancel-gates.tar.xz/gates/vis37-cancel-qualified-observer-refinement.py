"""Correct two observer-only summary predicates without changing sealed bytes."""
import ast
import hashlib
from pathlib import Path
import sys

HERE = Path(__file__)
ORIGINAL = Path('/home/opencode/ai/oc/evidence/tui/vis37-cancel-qualified-audit.py')
tree = ast.parse(ORIGINAL.read_bytes(), filename=str(ORIGINAL))
replacements = {
    ast.dump(ast.parse("p['grid']['status']=='EQUAL'", mode='eval').body):
        "p['grid']['different_cells']==0 and not p['grid']['cursor_differs']",
    ast.dump(ast.parse("p['png']['status']=='EQUAL'", mode='eval').body):
        "p['png']['different_pixels']==0",
}
counts = dict.fromkeys(replacements, 0)
saved = 0

class Refine(ast.NodeTransformer):
    def visit_Compare(self, node):
        key = ast.dump(node)
        if key in replacements:
            counts[key] += 1
            return ast.copy_location(ast.parse(replacements[key], mode='eval').body, node)
        return self.generic_visit(node)

    def visit_Call(self, node):
        global saved
        if (isinstance(node.func, ast.Name) and node.func.id == 'save' and node.args
                and isinstance(node.args[0], ast.Name) and node.args[0].id == 'AFTER'):
            node.func.id = 'save_refined'
            saved += 1
        return self.generic_visit(node)

tree = ast.fix_missing_locations(Refine().visit(tree))
assert all(value == 1 for value in counts.values()) and saved == 1
namespace = {'__name__': '__main__', '__file__': str(ORIGINAL)}

def save_refined(path, value):
    value['observer_refinement'] = {
        'program': str(HERE), 'sha256': hashlib.sha256(HERE.read_bytes()).hexdigest(),
        'cause': 'The independent grid/PNG reader returns numeric differences, not a status key.',
        'changes': ['Grid EQUAL iff zero different styled cells and identical complete cursor metadata.',
                    'PNG EQUAL iff zero differing RGBA pixels. No data, masks, thresholds or original helper bytes changed.'],
    }
    namespace['save'](path, value)

namespace['save_refined'] = save_refined
exec(compile(tree, str(ORIGINAL), 'exec'), namespace)
