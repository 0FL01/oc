import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
label, *command = sys.argv[1:]
if not re.fullmatch(r'[a-z0-9-]+', label) or not command:
    raise SystemExit('invalid gate label/command')
log = TMP / f'vis37-form-gate-{label}.log'
receipt = TMP / f'vis37-form-gate-{label}.json'
if log.exists() or receipt.exists():
    raise SystemExit('refusing existing gate output')
env = os.environ.copy()
env.update(CARGO_BUILD_JOBS='3', RUST_TEST_THREADS='2', TMPDIR=str(TMP), PYTHONDONTWRITEBYTECODE='1')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = time.monotonic_ns()
with log.open('xb') as output:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
data = log.read_bytes()
if len(data) > 16 * 1024 * 1024:
    raise SystemExit('gate output exceeds unchanged file cap')
text = data.decode('utf-8', errors='replace')
summaries = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)
facts = dict(label=label, command=command, started=started, elapsed_ns=time.monotonic_ns()-before,
             exit_code=result.returncode, log=str(log), log_bytes=len(data), rust_targets=len(summaries),
             passed=sum(int(row[1]) for row in summaries), failed=sum(int(row[2]) for row in summaries),
             ignored=sum(int(row[3]) for row in summaries), target_results=summaries)
with receipt.open('x') as output:
    json.dump(facts, output, indent=2)
    output.write('\n')
print(json.dumps({key: value for key, value in facts.items() if key != 'target_results'}, sort_keys=True))
if result.returncode:
    print(text)
raise SystemExit(result.returncode)
