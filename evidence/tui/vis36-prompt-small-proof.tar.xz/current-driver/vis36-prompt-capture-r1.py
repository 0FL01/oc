#!/usr/bin/env python3
"""Exclusive ordinary Prompt approval qualification using the existing real pair."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/home/opencode/ai/oc')
TMP = Path(os.environ['TMPDIR']) / 'opencode'
ROOT = TMP / 'vis36-prompt-current-001'
PROFILES = {'wide': ('prompt-wide-r1', 121), 'small': ('prompt-small-r1', 79)}
assert os.getuid() == 1003 and len(sys.argv) == 2 and sys.argv[1] in PROFILES
profile, columns = PROFILES[sys.argv[1]]
OWNER = 'T44 VIS36 ordinary Prompt: actual Once/Reject/Always, pending no-effect, Home navigation, inline/fullscreen previews, restart grants, MCP and child feedback, read/Shell/glob/URL and Settings transitions through the existing fixture/harness at 121x40 and79x40. Local isolated real effects only; no paid API, no unknown-effect replay. All old auto-cli and Question originals/proofs/helpers remain immutable. Full styled grids/PNGs/cursor/clocks are retained unmasked and unnormalized; behavior and pixel status remain separate. Frozen native Shell success override unchanged.\n'
if not ROOT.exists():
    ROOT.mkdir()
    with (ROOT / 'owner.txt').open('x') as owner:
        owner.write(OWNER)
assert ROOT.is_dir() and ROOT.stat().st_uid == 1003 and (ROOT / 'owner.txt').read_text() == OWNER
assert not (ROOT / profile).exists()
command = ['node', str(REPO / 'scripts/tui_capture/capture.mjs'),
           '--reference', str(TMP / 't44-reference/package/bin/opencode'),
           '--oc', str(REPO / 'target/debug/oc'), '--build-oc', 'true',
           '--geometry', 'true', '--sample', 'short', '--sidebar', 'hide',
           '--permission', 'true', '--permission-mode', 'prompt',
           '--columns', str(columns), '--rows', '40', '--output', str(ROOT / profile)]
env = {**os.environ, 'CARGO_BUILD_JOBS': '3', 'RUST_TEST_THREADS': '2', 'PYTHONDONTWRITEBYTECODE': '1'}
started = time.monotonic_ns()
with (ROOT / (profile + '.log')).open('xb') as log:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
facts = {'command': command, 'exit_code': result.returncode, 'elapsed_ns': time.monotonic_ns() - started}
with (ROOT / (profile + '.json')).open('x') as output:
    json.dump(facts, output, indent=2)
    output.write('\n')
checks = {}
for side in ['upstream', 'oc']:
    path = ROOT / profile / side / 'permission-checks.json'
    if path.exists():
        checks[side] = json.loads(path.read_text())
print(json.dumps({**facts, 'observed_behavior': {s: d['status'] for s, d in checks.items()},
                  'observed_checks': {s: len(d['checks']) for s, d in checks.items()}}))
raise SystemExit(0 if result.returncode in (0, 1) and len(checks) == 2 and
                 all(d['status'] == 'PASS' for d in checks.values()) else 1)
