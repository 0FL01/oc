"""Complete actual gate/helper bytes, exclusive bounded encoder/manual inverse."""
import datetime
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time

sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2,) * 2)
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO / 'evidence/tui'
sys.path.insert(0, str(REPO / 'scripts'))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

audit = load('mcp_tool_gate_observer', OUT / 'vis36-mcp-tool-qualified-audit.py')
check = audit.check
storage = load('mcp_tool_gate_allocation', REPO / 'scripts/archive_failed_capture.py')

def facts():
    final = check.load(audit.AFTER)
    result = dict(source_inputs=len(final['source_and_elf']['source']), source_sha256=check.producer_sha(final['source_and_elf']['source']),
                  totals=final['totals'], historical_totals=check.load(OUT / 'vis36-mcp-tool-historical-after.json')['totals'],
                  preserved_prior_proofs=final['preserved_prior_proofs'], legacy_files=final['legacy_files'], legacy_directories=final['legacy_directories'],
                  memory=final['memory'], receipts={p.name: {k: r for k, r in check.load(p).items() if k in ('archive_sha256', 'archive_bytes', 'tar_sha256', 'tar_bytes', 'inventory')}
                        for p in sorted(OUT.glob('vis36-mcp-tool-*-proof.inventory.json'))},
                  allocation=storage.owned_allocation(), cap=storage.CAP, headroom=storage.CAP - storage.owned_allocation())
    print(json.dumps(result, indent=2))

def pack():
    began = time.monotonic_ns()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = check.load(audit.BEFORE)
    audit.seals(before)
    records = {p: check.load(p) for p in sorted(TMP.glob('vis37-form-gate-vis36-mcp-tool-*.json'))}
    failed = {'vis36-mcp-tool-red': 101, 'vis36-mcp-tool-ui-red': 101, 'vis36-mcp-tool-clippy': 101,
              'vis36-mcp-tool-workspace-qualified': 101, 'vis36-mcp-tool-release-vis38': 101}
    assert {r['label']: r['exit_code'] for r in records.values() if r['exit_code']} == failed
    required = {'green', 'core-qualified', 'workspace-complete', 'clippy-qualified', 'fmt-qualified', 'python',
                'debug-locked', 'debug-ordinary', 'debug-help', 'release-build', 'release-help',
                'before', 'qualified-before', 'qualified-after', 'historical-after', 'preflight',
                'r4-wide-pack', 'r4-small-pack', 'wide-pack', 'small-pack', 'docs-final', 'progress-final'}
    required |= {'release-' + s for s in ('startup', 'term01', 'panic', 'vis31', 's07', 'vis38-isolated', 'aud32')}
    assert {'vis36-mcp-tool-' + s for s in required} <= {r['label'] for r in records.values()}
    paths = [p for path, r in records.items() for p in (path, Path(r['log']))]
    paths += [TMP / 'vis37-form-gate-20261012.py', *sorted(TMP.glob('vis36-mcp-tool-*.py')),
              TMP / 'vis36-prompt-capture-r4.py', TMP / 'vis36-prompt-capture-r5.py',
              *sorted(OUT.glob('vis36-mcp-tool-*.py'))]
    assert len(paths) == len(set(paths))
    files = {('gates/' if p.parent == TMP else 'audit/') + p.name: check.read_bytes(p) for p in paths}
    expected = {name: dict(path=str(path), bytes=len(files[name]), sha256=check.sha(files[name]), original_metadata=check.metadata(path))
                for path in paths for name in [('gates/' if path.parent == TMP else 'audit/') + path.name]}
    assert len(files) <= 2000 and max(map(len, files.values())) <= 16 * 1024**2 and sum(map(len, files.values())) <= 128 * 1024**2
    producer = load('mcp_tool_gate_encoding_only', REPO / 'scripts/retain_syntax_proof.py')
    producer.ROOTS = check.ROOTS = {'gates': TMP, 'audit': OUT}
    encoded, raw_sha, raw_bytes = producer.encode(files, {})
    def inverse(data):
        raw, xz = check.inverse_xz(data)
        restored, tar = check.inverse_ustar(raw, expected)
        assert restored == files and check.sha(raw) == raw_sha and len(raw) == raw_bytes
        return xz, tar
    xz, tar = inverse(encoded)
    archive, receipt = OUT / 'vis36-mcp-tool-gates.tar.xz', OUT / 'vis36-mcp-tool-gates.inventory.json'
    assert not archive.exists() and not receipt.exists()
    outputs = [p for p in sorted(OUT.glob('vis36-mcp-tool-*.json'))]
    outputs += sorted(OUT.glob('vis36-mcp-tool-*-proof.tar.xz'))
    record = dict(version=1, codec='complete original gate/helper bytes; encoder-only USTAR/single XZ; manual independent inverse',
                  archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=raw_sha, tar_bytes=raw_bytes,
                  inventory=tar['inventory'], original_members=expected, xz=xz, labels={r['label']: r['exit_code'] for r in records.values()},
                  current_source=before['source_and_elf'], release_elf=audit.v.frames.elf(REPO / 'target/release/oc'),
                  output_seals={str(p): dict(sha256=check.digest(p), metadata=check.metadata(p)) for p in outputs},
                  command=['python3', '-B', str(Path(__file__)), 'pack'], started=started, elapsed_to_inverse_ns=time.monotonic_ns() - began)
    data = (json.dumps(record, indent=2) + '\n').encode()
    allocated = storage.owned_allocation()
    assert allocated + sum((len(d) + 4095) // 4096 * 4096 for d in (encoded, data)) <= storage.CAP
    storage.durable(archive, encoded)
    storage.durable(receipt, data)
    inverse(check.read_bytes(archive))
    print(json.dumps(dict(status='ALL_GATE_AND_PROGRAM_BYTES_MANUAL_INVERSE_MEMORY_AND_DURABLE',
                         archive_sha256=check.sha(encoded), archive_bytes=len(encoded), inventory=tar['inventory'], gate_pairs=len(records),
                         allocation=storage.owned_allocation(), headroom=storage.CAP - storage.owned_allocation(), memory=check.proc_memory())))

if __name__ == '__main__':
    {'facts': facts, 'pack': pack}[sys.argv[1]]()
