"""Exclusive complete profiles; encoder-only producer, independent manual inverse."""
import importlib.util
import json
from pathlib import Path
import resource
import sys

sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2,) * 2)
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO / 'evidence/tui'
sys.path.insert(0, str(REPO / 'scripts'))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

audit = load('mcp_tool_qualified_observer', OUT / 'vis36-mcp-tool-qualified-audit.py')
check = audit.check
storage = load('mcp_tool_allocation', REPO / 'scripts/archive_failed_capture.py')
producer = load('mcp_tool_encoding_only', REPO / 'scripts/retain_syntax_proof.py')

def quota():
    allocated = storage.owned_allocation()
    assert 'vis36-' in storage.PREFIXES and allocated <= storage.CAP
    return dict(allocated_bytes=allocated, quota_bytes=storage.CAP, headroom_bytes=storage.CAP - allocated)

def scope(attempt):
    qualified = check.load(audit.BEFORE)
    audit.seals(qualified)
    old = check.load(OUT / 'vis36-mcp-tool-before.json')
    assert set(old['source_and_elf']['source']) == set(qualified['source_and_elf']['source'])
    assert [p for p in old['source_and_elf']['source'] if old['source_and_elf']['source'][p] !=
            qualified['source_and_elf']['source'][p]] == ['crates/oc-core/src/approval_tool_tests.rs']
    # Test-only correction; both captures must still bind the actual unchanged
    # debug ELF, and final current manifests remain byte-for-byte exact.
    assert old['source_and_elf']['elf'] == qualified['source_and_elf']['elf']
    return old if attempt == '004' else qualified

def facts():
    current = scope('005')
    result = dict(quota=quota(), current_source=dict(input_count=len(current['source_and_elf']['source']),
                 manifest_sha256=check.producer_sha(current['source_and_elf']['source']), elf=current['source_and_elf']['elf']),
                 before_bytes={n: check.metadata(OUT / n)[0] for n in ('vis36-mcp-tool-before.json', 'vis36-mcp-tool-qualified-before.json')},
                 inventories={a: {p: dict(members=len(i['files']), logical_bytes=sum(r['bytes'] for r in i['files'].values()))
                              for p, i in scope(a)['original_inventory'].items()} for a in ('004', '005')})
    print(json.dumps(result, indent=2))

def pack(attempt, profile):
    assert attempt in ('004', '005') and profile in ('wide', 'small')
    before = scope(attempt)
    expected = before['original_inventory'][profile]['files']
    roots = {'current': TMP / ('vis36-prompt-current-' + attempt) / ('prompt-' + profile + '-r' + str(int(attempt))),
             'current-logs': TMP / ('vis36-prompt-current-' + attempt),
             'current-driver': TMP / ('vis36-prompt-capture-r' + str(int(attempt)) + '.py')}
    previous = audit.v.ROOTS, check.ROOTS
    audit.v.ROOTS = check.ROOTS = roots
    try:
        assert audit.v.inventory() == before['original_inventory'][profile]
        files = {name: check.read_bytes(row['path']) for name, row in expected.items()}
        assert all(len(files[n]) == r['bytes'] and check.sha(files[n]) == r['sha256'] for n, r in expected.items())
        assert len(files) <= 2000 and sum(map(len, files.values())) <= 128 * 1024**2
        # Exact same-side encoded PNG aliases only; never decode/re-encode.
        first, aliases = {}, {}
        for name, data in sorted(files.items()):
            if name.endswith('.png'):
                key = (tuple(name.split('/')[:2]), check.sha(data))
                if key in first:
                    assert files[first[key]] == data
                    aliases[name] = first[key]
                else:
                    first[key] = name
        producer.ROOTS = roots
        encoded, raw_sha, raw_bytes = producer.encode(files, aliases)
        def inverse(data):
            raw, xz = check.inverse_xz(data)
            restored, tar = check.inverse_ustar(raw, expected)
            assert restored == files and check.sha(raw) == raw_sha and len(raw) == raw_bytes
            assert tar['inventory']['same_side_png_aliases'] == len(aliases)
            return xz, tar
        xz, tar = inverse(encoded)
        name = 'vis36-mcp-tool-' + ('r4-' if attempt == '004' else '') + profile + '-proof'
        archive, receipt = OUT / (name + '.tar.xz'), OUT / (name + '.inventory.json')
        assert not archive.exists() and not receipt.exists()
        record = dict(version=1, codec='encoder-only USTAR/single XZ; independent manual inverse of every byte',
                      archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=raw_sha, tar_bytes=raw_bytes,
                      inventory=tar['inventory'], xz=xz, source_roots={k: str(v) for k, v in roots.items()},
                      source_qualification='HISTORICAL_TEST_ONLY_CLIPPY_CORRECTION' if attempt == '004' else 'EXACT_CURRENT_SOURCE',
                      original_source_manifest_sha256=check.producer_sha(before['source_and_elf']['source']),
                      before_sha256=check.digest(OUT / ('vis36-mcp-tool-before.json' if attempt == '004' else 'vis36-mcp-tool-qualified-before.json')),
                      helper_sha256=check.digest(Path(__file__)))
        data = (json.dumps(record, indent=2) + '\n').encode()
        assert quota()['headroom_bytes'] >= sum((len(d) + 4095) // 4096 * 4096 for d in (encoded, data))
        storage.durable(archive, encoded)
        storage.durable(receipt, data)
        inverse(check.read_bytes(archive))
        assert audit.v.inventory() == before['original_inventory'][profile]
        print(json.dumps(dict(status='FULL_BYTE_EXACT_MANUAL_INVERSE_MEMORY_AND_DURABLE', archive=str(archive),
                         archive_bytes=len(encoded), archive_sha256=check.sha(encoded), inventory=tar['inventory'], memory=check.proc_memory(), quota=quota())))
    finally:
        audit.v.ROOTS, check.ROOTS = previous

if __name__ == '__main__':
    if sys.argv[1:] == ['facts']:
        facts()
    else:
        assert len(sys.argv) == 4 and sys.argv[1] == 'pack'
        pack(*sys.argv[2:])
