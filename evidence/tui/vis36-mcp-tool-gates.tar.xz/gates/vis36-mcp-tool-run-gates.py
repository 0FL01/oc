"""Sequential bounded current-source gates through the unchanged exclusive wrapper."""
import subprocess
import sys
from pathlib import Path

REPO = Path('/home/opencode/ai/oc')
GATE = Path('/home/opencode/.cache/opencode-tmp/opencode/vis37-form-gate-20261012.py')
commands = [
    ('crates', ['cargo', 'test', '--locked', '-p', 'oc-core', '-p', 'oc-adapters', '-p', 'oc-tui', '--no-fail-fast']),
    ('workspace', ['cargo', 'test', '--workspace', '--locked', '--no-fail-fast']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('debug-locked', ['cargo', 'build', '--locked']),
    ('debug-ordinary', ['cargo', 'build']),
    ('debug-help', ['target/debug/oc', '--help']),
    ('release-build', ['cargo', 'build', '--release', '--locked']),
    ('release-help', ['target/release/oc', '--help']),
    ('release-startup', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'recovery_startup', 'isolated_', '--', '--nocapture']),
    ('release-term01', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'terminals', 'term01_actual_binary_session_terminals', '--', '--exact', '--nocapture']),
    ('release-panic', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'pty', 'pty_panic_restores_terminal', '--', '--exact', '--nocapture']),
    ('release-vis31', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'pty_t39', 'vis31_', '--', '--nocapture']),
    ('release-s07', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'pty_t39', 's07_pty_equal_view_archive_resource_samples', '--', '--nocapture']),
    ('release-vis38', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'pty_t39', 'vis38_pty_dcp_equal_active_archive_resource_samples', '--', '--nocapture']),
    ('release-aud32', ['cargo', 'test', '--locked', '--release', '-p', 'oc', '--test', 'memory_bounds', 'aud32_actual_binary_bounds_active_context_with_growing_archive', '--', '--exact', '--nocapture']),
    ('python', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_*.py']),
]
assert sys.argv[1:] == ['run']
for label, command in commands:
    result = subprocess.run(['python3', '-B', str(GATE), 'vis36-mcp-tool-' + label, *command], cwd=REPO)
    if result.returncode:
        raise SystemExit(result.returncode)
