"""Retained TERM01 failure isolated; unmodified complete workspace and release."""
import ast
from pathlib import Path
import subprocess

REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
tree = ast.parse((TMP / 'vis36-mcp-tool-run-gates.py').read_bytes())
nodes = [n for n in tree.body if isinstance(n, ast.Assign) and
         any(isinstance(t, ast.Name) and t.id == 'commands' for t in n.targets)]
assert len(nodes) == 1
commands = ast.literal_eval(nodes[0].value)
for label, command in [('workspace-complete', commands[1][1]), *commands[3:]]:
    result = subprocess.run(['python3', '-B', str(TMP / 'vis37-form-gate-20261012.py'),
                             'vis36-mcp-tool-' + label, *command], cwd=REPO)
    if result.returncode:
        raise SystemExit(result.returncode)
