"""Current source: full workspace and actual debug/release gates, sequential."""
import ast
from pathlib import Path
import subprocess

REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
tree = ast.parse((TMP / 'vis36-mcp-tool-run-gates.py').read_bytes())
commands_node = [n for n in tree.body if isinstance(n, ast.Assign) and
                 any(isinstance(t, ast.Name) and t.id == 'commands' for t in n.targets)]
assert len(commands_node) == 1
commands = ast.literal_eval(commands_node[0].value)
commands = [('core-qualified', ['cargo', 'test', '--locked', '-p', 'oc-core', 'tool_marker', '--', '--nocapture']),
            ('fmt-qualified', ['cargo', 'fmt', '--all', '--', '--check']),
            ('workspace-qualified', commands[1][1]), *commands[3:]]
for label, command in commands:
    result = subprocess.run(['python3', '-B', str(TMP / 'vis37-form-gate-20261012.py'),
                             'vis36-mcp-tool-' + label, *command], cwd=REPO)
    if result.returncode:
        raise SystemExit(result.returncode)
