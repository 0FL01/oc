"""Read-only current/historical delivery seals; no obsolete delivery HEAD assertion."""
import importlib.util
import json
from pathlib import Path
import resource
import sys

sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2,) * 2)
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO / 'evidence/tui'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

audit = load('mcp_tool_final_read_only', OUT / 'vis36-mcp-tool-qualified-audit.py')
historical = load('mcp_tool_historical_read_only', OUT / 'vis36-mcp-tool-historical-audit.py')
check = audit.check
storage = load('mcp_tool_final_stat_allocation', REPO / 'scripts/archive_failed_capture.py')

def main():
    before = check.load(audit.BEFORE)
    audit.seals(before)
    historical.seals(check.load(historical.BEFORE))
    after = check.load(audit.AFTER)
    assert before['source_and_elf'] == after['source_and_elf']
    assert after['before_sha256'] == check.digest(audit.BEFORE)
    archives = {}
    for attempt, episode in [('004', historical), ('005', audit)]:
        sealed = check.load(episode.BEFORE)
        for profile in ('wide', 'small'):
            name = 'vis36-mcp-tool-' + ('r4-' if attempt == '004' else '') + profile + '-proof'
            receipt = check.load(OUT / (name + '.inventory.json'))
            packed = check.read_bytes(OUT / (name + '.tar.xz'))
            assert check.sha(packed) == receipt['archive_sha256'] and len(packed) == receipt['archive_bytes']
            raw, xz = check.inverse_xz(packed)
            original_roots = check.ROOTS
            check.ROOTS = {k: Path(p) for k, p in receipt['source_roots'].items()}
            try:
                restored, tar = check.inverse_ustar(raw, sealed['original_inventory'][profile]['files'])
            finally:
                check.ROOTS = original_roots
            assert tar['inventory'] == receipt['inventory'] and xz == receipt['xz']
            assert check.sha(raw) == receipt['tar_sha256'] and len(raw) == receipt['tar_bytes']
            archives[name] = {'bytes': len(packed), 'sha256': check.sha(packed)}
            del raw, restored, packed
    gate = check.load(OUT / 'vis36-mcp-tool-gates.inventory.json')
    assert gate['current_source'] == before['source_and_elf']
    assert gate['release_elf'] == audit.v.frames.elf(REPO / 'target/release/oc')
    for p, row in gate['output_seals'].items():
        assert dict(sha256=check.digest(p), metadata=check.metadata(p)) == row
    expected = gate['original_members']
    for row in expected.values():
        assert check.metadata(row['path']) == row['original_metadata'] and check.digest(row['path']) == row['sha256']
    records = {check.load(p)['label']: check.load(p) for p in sorted(TMP.glob('vis37-form-gate-vis36-mcp-tool-*.json'))}
    assert {label: r['exit_code'] for label, r in records.items()} == gate['labels']
    failed = {'vis36-mcp-tool-red': 101, 'vis36-mcp-tool-ui-red': 101, 'vis36-mcp-tool-clippy': 101,
              'vis36-mcp-tool-workspace-qualified': 101, 'vis36-mcp-tool-release-vis38': 101}
    assert {label: r['exit_code'] for label, r in records.items() if r['exit_code']} == failed
    workspace = records['vis36-mcp-tool-workspace-complete']
    assert [workspace[k] for k in ('passed', 'failed', 'ignored', 'rust_targets')] == [1873, 0, 11, 46]
    assert b'Ran 71 tests in ' in check.read_bytes(records['vis36-mcp-tool-python']['log'])
    release_labels = ('startup', 'term01', 'panic', 'vis31', 's07', 'vis38-isolated', 'aud32')
    release = [records['vis36-mcp-tool-release-' + label] for label in release_labels]
    assert [r['passed'] for r in release] == [2, 1, 1, 2, 1, 1, 1]
    assert all(r['rust_targets'] == 1 and r['exit_code'] == r['failed'] == r['ignored'] == 0 and
               r['command'][:4] == ['cargo', 'test', '--locked', '--release'] for r in release)
    assert all('--exact' not in records['vis36-mcp-tool-release-' + label]['command'] for label in ('s07', 'vis38-isolated'))
    packed = check.read_bytes(OUT / 'vis36-mcp-tool-gates.tar.xz')
    assert check.sha(packed) == gate['archive_sha256'] and len(packed) == gate['archive_bytes']
    raw, xz = check.inverse_xz(packed)
    original_roots = check.ROOTS
    check.ROOTS = {'gates': TMP, 'audit': OUT}
    try:
        restored, tar = check.inverse_ustar(raw, expected)
    finally:
        check.ROOTS = original_roots
    assert tar['inventory'] == gate['inventory'] and xz == gate['xz']
    assert check.sha(raw) == gate['tar_sha256'] and len(raw) == gate['tar_bytes']
    assert all(restored[name] == check.read_bytes(row['path']) for name, row in expected.items())
    state = check.load(REPO / 'progress/STATE.json')
    old = json.loads(check.git('show', audit.BASE + ':progress/STATE.json'))
    assert state['current'] == 'T44' and state['tasks']['T44']['status'] == 'active' and state['tasks']['T44']['last_seq'] == 142
    assert {k: v for k, v in state['tasks'].items() if k != 'T44'} == {k: v for k, v in old['tasks'].items() if k != 'T44'}
    assert {k: v for k, v in state['tasks']['T44'].items() if k not in ('last_seq', 'latest')} == {
        k: v for k, v in old['tasks']['T44'].items() if k not in ('last_seq', 'latest')}
    assert storage.PREFIXES == ('model-shell', 'subagent', 'root-', 'syntax-', 'write-', 'wrap-', 'hover-',
        'raster-', 'caret-', 'blink-', 'mcp-label-', 'shell-wrap-', 'middle-tabs-', 'rail-width-',
        'compact-layout-', 'compact-controls-', 'vis12-', 'vis36-', 'vis37-') and storage.CAP == 1024**3
    allocated = storage.owned_allocation()
    assert allocated <= storage.CAP
    print(json.dumps(dict(status='CURRENT005_TYPED_TOOL_DELIVERY_SEALS_PASS_T44_ACTIVE_NOT_PASS',
        producer=audit.BASE, delivery_head=check.git('rev-parse', 'HEAD').decode().strip(),
        source_inputs=715, source_sha256=check.producer_sha(before['source_and_elf']['source']),
        archives=archives, gate_archive_sha256=gate['archive_sha256'], gate_pairs=len(records), gate_members=len(expected),
        workspace=[1873, 0, 11, 46], actual_release_cases=9, python_tests=71, preserved_prior_proofs=after['preserved_prior_proofs'],
        legacy_files=after['legacy_files'], legacy_directories=after['legacy_directories'], totals=after['totals'],
        actual_allocation=allocated, cap=storage.CAP, headroom=storage.CAP - allocated, memory=check.proc_memory()), indent=2))

if __name__ == '__main__':
    assert sys.argv[1:] == []
    main()
