"""Preserve sealed observer; identify full actual Subagent caption, not description."""
import ast
import hashlib
from pathlib import Path
import sys
sys.dont_write_bytecode = True
original = Path('/home/opencode/ai/oc/evidence/tui/vis36-subagent-gap-audit.py')
tree = ast.parse(original.read_bytes(), filename=str(original))
function = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'subagent_header']
assert len(function) == 1
labels = [n for n in ast.walk(function[0]) if isinstance(n, ast.Constant) and n.value == 'VIS36 child permission feedback']
assert len(labels) == 1
labels[0].value = 'Vis36-Child Subagent — VIS36 child permission feedback'
namespace = {'__name__':'__main__', '__file__':str(original)}
self_path = Path(__file__)
provenance = dict(path=str(self_path), sha256=hashlib.sha256(self_path.read_bytes()).hexdigest(),
                  cause='Sealed observer located description inside caption rather than the whole actual actor/description label. No capture/source/metric/threshold change.',
                  refinement='One diagnostic label constant changed to exact paired completed caption; all full-frame/inverse/source guards unchanged.')
save_call = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'save'
             and isinstance(n.args[0], ast.Name) and n.args[0].id == 'AFTER']
assert len(save_call) == 1
save_call[0].func.id = 'save_refined'
def save_refined(path, value):
    value['observer_refinement'] = provenance
    namespace['save'](path, value)
namespace['save_refined'] = save_refined
exec(compile(tree, str(original), 'exec'), namespace)
