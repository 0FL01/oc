"""Independent own FAILED model019 byte/metadata archival; no producer imports."""
import sys
sys.dont_write_bytecode = True
import ast
from decimal import Decimal
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import resource
import stat

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO/'evidence/tui'
spec = importlib.util.spec_from_file_location('immutable_manual_observer', TMP/'vis37-form-independent-20261012-sole-verifier/verifier.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
check = v.inverse
check.require('vis36-' not in check.PREFIXES, 'known legacy quota scope')
check.PREFIXES = (*check.PREFIXES, 'vis36-')
BASE = '70ad2d3b3b155d6ce4cc75f982e88e711a7c8b05'
ROOT = OUT/'model-shell-019'
BEFORE, AFTER = OUT/'vis36-model019-before.json', OUT/'vis36-model019-after.json'
PAX_SOURCE = OUT/'vis37-retention-recovery-audit.py'
tree = ast.parse(check.read_bytes(PAX_SOURCE), filename=str(PAX_SOURCE))
functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'inverse_pax']
check.require(len(functions) == 1, 'one delivered independent PAX reader, no old entrypoint')
roots = [n for n in ast.walk(functions[0]) if isinstance(n, ast.Constant) and n.value == 'model-shell-001']
check.require(len(roots) == 1, 'one fixed PAX diagnostic root')
roots[0].value = 'model-shell-019'
namespace = dict(check=check, Decimal=Decimal, PurePosixPath=PurePosixPath)
exec(compile(ast.Module(body=functions, type_ignores=[]), str(PAX_SOURCE), 'exec'), namespace)
inverse_pax = namespace['inverse_pax']

def snapshot():
    files, directories = {}, {}
    for p in sorted([ROOT, *ROOT.rglob('*')]):
        m = p.lstat()
        check.require(m.st_uid == os.getuid() and not p.is_symlink(), 'owned selected original')
        name = p.relative_to(OUT).as_posix()
        metadata = [stat.S_IMODE(m.st_mode), m.st_uid, m.st_gid, m.st_mtime_ns]
        if stat.S_ISDIR(m.st_mode):
            directories[name] = metadata
        else:
            check.require(stat.S_ISREG(m.st_mode) and m.st_nlink == 1 and m.st_size <= check.FILE, 'regular bounded original')
            files[name] = dict(bytes=m.st_size, sha256=check.digest(p), metadata=metadata)
    check.require(len(files) == 103 and len(directories) == 3 and sum(r['bytes'] for r in files.values()) <= check.TOTAL,
                  'whole selected103 files/3 directories')
    return dict(files=files, directories=directories)

def save(path, report):
    data = (json.dumps(report, separators=(',', ':'))+'\n').encode()
    check.require(len(data) <= check.FILE and check.quota()['headroom_bytes'] >= (len(data)+4095)//4096*4096,
                  'exclusive report within unchanged cap including vis36')
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(dict(output=str(path), bytes=len(data), sha256=check.sha(data), status=report['status'],
                          memory=check.proc_memory(), quota=check.quota())))

check.require(os.getuid() == 1003 and check.git('rev-parse','HEAD').decode().strip() == BASE, 'dedicated owner and known base')
helpers = {str(p):check.digest(p) for p in [Path(__file__), PAX_SOURCE,
           TMP/'vis37-form-independent-20261012-sole-verifier/verifier.py', *sorted(v.OLD_HELPERS.glob('*.py'))]}
if sys.argv[1:] == ['before']:
    check.require(ROOT.stat().st_dev == TMP.stat().st_dev and TMP.stat().st_uid == os.getuid(), 'same filesystem and approved owned temp')
    check.require(not (OUT/'model-shell-019.tar.xz').exists() and not (OUT/'model-shell-019.archived.json').exists(), 'new archive absent')
    original = snapshot()
    statuses = {s:check.load(ROOT/s/'tool-preview-checks.json')['status'] for s in ('oc','upstream')}
    check.require(statuses == dict(oc='FAILED', upstream='PASS_BEHAVIOR_ONLY'), 'actual FAILED side, not DIFFERENT only')
    prior = {str(p):dict(sha256=check.digest(p), metadata=check.metadata(p)) for p in sorted(OUT.iterdir())
             if p.name.endswith(('.tar.xz','.inventory.json','.archived.json'))}
    check.require(snapshot() == original, 'unchanged original while sealing')
    save(BEFORE, dict(status='INDEPENDENT_MODEL019_SEALED_BEFORE_T44_ACTIVE', original=original, statuses=statuses,
                      helpers=helpers, prior=prior, source=v.source(), quota=check.quota()))
elif sys.argv[1:] == ['after']:
    before = check.load(BEFORE)
    check.require(helpers == before['helpers'] and v.source() == before['source'], 'helpers and source unchanged')
    archive = OUT/'model-shell-019.tar.xz'
    receipt = check.load(OUT/'model-shell-019.archived.json')
    raw, xz = check.inverse_xz(check.read_bytes(archive))
    inverse = inverse_pax(raw, before['original'])
    check.require(inverse['files'] == 103 and inverse['directories'] == 3 and
                  check.digest(archive) == receipt['archive_sha256'] and receipt['statuses_unchanged'] == before['statuses'],
                  'durable all103 byte/meta inverse and preserved failures')
    check.require(list(ROOT.iterdir()) == [ROOT/'ARCHIVED.md'] and b'FAILED / NOT_QUALIFIED' in check.read_bytes(ROOT/'ARCHIVED.md'),
                  'failure-visible original-path pointer')
    check.require(all(check.digest(p) == r['sha256'] and check.metadata(p) == r['metadata'] for p,r in before['prior'].items()),
                  'all existing retained proof bytes and metadata unchanged')
    save(AFTER, dict(status='INDEPENDENT_MODEL019_FULL_BYTE_EXACT_T44_ACTIVE_NOT_PASS', before_sha256=check.digest(BEFORE),
                     archive_sha256=check.digest(archive), inverse=inverse, xz=xz, helpers=helpers,
                     preserved_prior_proofs=len(before['prior']), memory=check.proc_memory(), quota=check.quota()))
else:
    raise SystemExit('before or after; existing outputs immutable')
