"""Complete Subagent command bytes; bounded independent manual inverse."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS, (384*1024**2, 384*1024**2))
REPO, TMP = Path('/home/opencode/ai/oc'), Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO/'evidence/tui'
sys.path.insert(0, str(REPO/'scripts'))
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
observer = module('subagent_manual_inverse', TMP/'vis37-form-independent-20261012-sole-verifier/owner_refinement.py')
check = observer.v.inverse
storage = module('subagent_actual_allocation', REPO/'scripts/archive_failed_capture.py')
def quota():
    allocated = storage.owned_allocation()
    check.require(allocated <= storage.CAP and 'vis36-' in storage.PREFIXES, 'unchanged additive cap')
    return dict(allocated_bytes=allocated, quota_bytes=storage.CAP, headroom_bytes=storage.CAP-allocated, prefixes=storage.PREFIXES)
final = check.load(OUT/'vis36-subagent-gap-after.json')
if sys.argv[1:] == ['facts']:
    archival = check.load(OUT/'model-shell-019.archived.json')
    print(json.dumps(dict(source=final['source'], totals=final['totals'], preserved=final['preserved_prior_proofs'],
                         memory=final.get('memory'), observer_refinement=final['observer_refinement'],
                         receipt=check.load(OUT/'vis36-subagent-gap-proof.inventory.json'),
                         archival={k:v for k,v in archival.items() if k not in ('original_files','original_directories')}, quota=quota()), indent=2))
    raise SystemExit()
check.require(sys.argv[1:] == ['pack'], 'facts or exclusive pack')
proof = module('subagent_gate_producer', REPO/'scripts/retain_syntax_proof.py')
failed = {'vis39-subagent-gap-red':101, 'vis39-subagent-gap-green':101, 'vis39-subagent-gap-after':1}
records = {p:check.load(p) for p in sorted(TMP.glob('vis37-form-gate-vis39-subagent-*.json'))}
labels = {r['label'] for r in records.values()}
required = {'vis39-subagent-style-observation','vis39-subagent-gap-green-complete','vis39-subagent-gap-clippy',
            'vis39-subagent-gap-python','vis39-subagent-model019-preflight','vis39-subagent-model019-before',
            'vis39-subagent-model019-archive','vis39-subagent-model019-after','vis39-subagent-gap-before',
            'vis39-subagent-gap-measure','vis39-subagent-gap-pack','vis39-subagent-gap-audit','vis39-subagent-gap-after-complete',
            'vis39-subagent-gap-workspace','vis39-subagent-gap-fmt','vis39-subagent-gap-debug-locked',
            'vis39-subagent-gap-debug-ordinary','vis39-subagent-gap-debug-help','vis39-subagent-gap-release-build',
            'vis39-subagent-gap-release-help','vis39-subagent-gap-docs-final','vis39-subagent-gap-progress-final'}
check.require(required|set(failed) <= labels, 'all actual gates, no discarded failures')
paths = []
for path, record in records.items():
    check.require(record['exit_code'] == failed.get(record['label'], 0), 'honest actual command status')
    paths.extend((path, Path(record['log'])))
workspace = next(r for r in records.values() if r['label'] == 'vis39-subagent-gap-workspace')
check.require((workspace['passed'],workspace['failed'],workspace['ignored'],workspace['rust_targets']) == (1868,0,11,46), 'complete workspace totals')
release = [r for r in records.values() if r['label'].startswith('vis39-subagent-gap-release-') and r['rust_targets']]
check.require(len(release) == 7 and sum(r['passed'] for r in release) == 9 and not any(r['failed'] or r['ignored'] for r in release), 'nine actual release/resource cases')
py = next(r for r in records.values() if r['label'] == 'vis39-subagent-gap-python')
check.require(b'Ran 70 tests in ' in check.read_bytes(py['log']), 'complete root Python tests')
paths.extend((TMP/'vis37-form-gate-20261012.py', TMP/'vis39-subagent-style-observation-001.py',
              TMP/'vis39-model019-archival-audit.py', TMP/'vis39-subagent-gap-observer-refinement.py', Path(__file__)))
files = {'gates/'+p.name:check.read_bytes(p) for p in paths}
check.require(len(files) == len(paths), 'unique complete original members')
expected = {'gates/'+p.name:dict(path=str(p), bytes=len(files['gates/'+p.name]), sha256=check.sha(files['gates/'+p.name])) for p in paths}
proof.ROOTS = check.ROOTS = {'gates':TMP}
encoded, raw_sha, raw_bytes = proof.encode(files, {})
def inverse(data):
    raw, xz = check.inverse_xz(data)
    restored, meta = check.inverse_ustar(raw, expected)
    check.require(restored == files and check.sha(raw) == raw_sha, 'every complete original log/program byte')
    return xz, meta
xz, meta = inverse(encoded)
archive, receipt = OUT/'vis36-subagent-gap-gates.tar.xz', OUT/'vis36-subagent-gap-gates.inventory.json'
check.require(not archive.exists() and not receipt.exists(), 'exclusive durable proof')
record = dict(version=1, codec='USTAR/single-XZ full original logs; independent manual inverse',
              archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=raw_sha, tar_bytes=raw_bytes,
              inventory=meta['inventory'], labels={r['label']:r['exit_code'] for r in records.values()},
              current_source=final['source'], helper_sha256=check.digest(Path(__file__)), xz=xz)
data = (json.dumps(record, indent=2)+'\n').encode()
check.require(storage.owned_allocation()+sum((n+4095)//4096*4096 for n in (len(encoded),len(data))) <= storage.CAP, 'actual additive allocation in unchanged cap')
storage.durable(archive, encoded)
storage.durable(receipt, data)
inverse(check.read_bytes(archive))
print(json.dumps(dict(status='FULL_BYTE_EXACT_INDEPENDENT_SUBAGENT_GATES', archive_bytes=len(encoded), archive_sha256=check.sha(encoded),
                      inventory=meta['inventory'], actual_labels=len(records), memory=check.proc_memory(), quota=quota())))
