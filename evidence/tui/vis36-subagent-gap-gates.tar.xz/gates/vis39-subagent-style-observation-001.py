"""Read-only exact structured-cell roles from preserved completed child frames."""
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
root = Path('/home/opencode/.cache/opencode-tmp/opencode/vis36-mode-current-009')
for profile in ('cli-wide-r9', 'cli-small-r9'):
    for side in ('oc', 'upstream'):
        grid = json.loads((root/profile/side/'permission-auto-childroot-completed.cells.json').read_bytes())
        rows = [''.join(c['symbol'] for c in row) for row in grid['cells']]
        headers = [y for y, text in enumerate(rows) if ' Subagent — ' in text]
        assert len(headers) == 1
        y = headers[0]
        icon = [x for x, c in enumerate(grid['cells'][y]) if c['symbol'] == '✓']
        assert len(icon) == 1
        x = icon[0]
        print(json.dumps(dict(profile=profile, side=side, header=(x,y),
                              cells=[dict(x=i,y=y,cell=grid['cells'][y][i]) for i in range(x-1,x+4)],
                              cursor=grid['cursor']), ensure_ascii=False))
