"""Retain every storage-recovery gate, including failed RED/preflight, byte-exact."""
import importlib.util
import json
from pathlib import Path
import resource
import sys
sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
sys.path.insert(0, str(REPO / 'scripts'))
import retain_syntax_proof as codec
spec = importlib.util.spec_from_file_location('immutable_manual_inverse', TMP / 'vis37-independent-20261012-sole-verifier/inverse_verifier.py')
inverse = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inverse)
labels = ('retention-archiver-red', 'retention-archiver-green', 'retention-python-final',
          'retention-model-preflight', 'retention-independent-before', 'retention-model-archive',
          'retention-current004-measure', 'retention-model-archive-actual', 'retention-current004-measure-unblocked',
          'retention-current004-pack', 'retention-current004-audit', 'retention-independent-after',
          'retention-docs-final', 'retention-progress-final')
paths = [TMP / ('vis37-form-gate-' + label + suffix) for label in labels for suffix in ('.json', '.log')]
paths.append(Path(__file__))
codec.ROOTS = inverse.ROOTS = {'gates': TMP}
files = {'gates/' + p.name: p.read_bytes() for p in paths}
for label in labels:
    fact = json.loads(files['gates/vis37-form-gate-' + label + '.json'])
    codec.require(fact['label'] == label and fact['exit_code'] == (1 if label in ('retention-archiver-red', 'retention-current004-measure') else 0), 'all expected actual gate exits')
encoded, tar_sha, tar_bytes = codec.encode(files, {})
raw, xz = inverse.inverse_xz(encoded)
expected = {'gates/' + p.name: {'path': str(p), 'bytes': p.stat().st_size, 'sha256': inverse.digest(p)} for p in paths}
restored, report = inverse.inverse_ustar(raw, expected)
codec.require(all(restored[n] == data for n, data in files.items()), 'independent every original gate byte')
record = {'archive_sha256': codec.digest(encoded), 'archive_bytes': len(encoded), 'tar_sha256': tar_sha,
          'tar_bytes': tar_bytes, 'inventory': report['inventory'], 'gate_labels': list(labels),
          'manual_inverse_xz': xz, 'helper_sha256': inverse.digest(__file__), 'memory': inverse.proc_memory()}
metadata = (json.dumps(record, indent=2) + '\n').encode()
root = REPO / 'evidence/tui/vis37-retention-recovery-gates'
archive, receipt = Path(str(root) + '.tar.xz'), Path(str(root) + '.inventory.json')
codec.require(not archive.exists() and not receipt.exists(), 'exclusive new gate bundle')
extra = sum((len(data) + 4095) // 4096 * 4096 for data in (encoded, metadata))
codec.require(codec.storage.owned_allocation() + extra <= codec.storage.CAP, 'unchanged aggregate cap')
codec.storage.durable(archive, encoded)
codec.storage.durable(receipt, metadata)
saved, _ = inverse.inverse_xz(archive.read_bytes())
inverse.inverse_ustar(saved, expected)
print(json.dumps({'status': 'INDEPENDENT_FULL_BYTE_EXACT_RECOVERY_GATES', **record, 'quota': inverse.quota()}, sort_keys=True))
