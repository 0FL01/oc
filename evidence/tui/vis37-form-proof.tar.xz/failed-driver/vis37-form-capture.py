#!/usr/bin/env python3
"""Fresh pending-panel/real-mouse qualification; never replay an episode."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/home/opencode/ai/oc')
TEMP = Path(os.environ['TMPDIR']) / 'opencode'
ROOT = TEMP / 'vis37-form-current-001'
parser = argparse.ArgumentParser()
parser.add_argument('case', choices=('small', 'wide', 'tall'))
case = parser.parse_args().case
if not ROOT.exists():
    ROOT.mkdir()
    (ROOT / 'owner.txt').write_text('T44 sole-parent VIS37 pending panel and real mouse controls; preserve all prior attempts.\n')
output = ROOT / case
if output.exists():
    raise SystemExit('Existing episode is never replayed: ' + str(output))
columns, rows = {'small': (80, 24), 'wide': (120, 40), 'tall': (160, 48)}[case]
argv = ['node', str(REPO / 'scripts/tui_capture/capture.mjs'),
        '--reference', str(TEMP / 't44-reference/package/bin/opencode'),
        '--oc', str(REPO / 'target/debug/oc'), '--build-oc', 'true', '--geometry', 'true',
        '--sample', 'short', '--sidebar', 'hide', '--tool-preview', 'true', '--question-forms', 'true',
        '--columns', str(columns), '--rows', str(rows), '--output', str(output)]
process = subprocess.run(argv, cwd=REPO, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         env={**os.environ, 'CARGO_BUILD_JOBS': '3', 'RUST_TEST_THREADS': '2'})
with (ROOT / ('driver-' + case + '-' + str(time.monotonic_ns()) + '.log')).open('x') as log:
    log.write(process.stdout)
print(process.stdout, end='')
lock = json.loads((output / 'capture.lock.json').read_text())
checks = [json.loads((output / side / 'tool-preview-checks.json').read_text()) for side in ('upstream', 'oc')]
print(json.dumps({'case': case, 'exit': process.returncode, 'captures': len(lock['captures']),
                  'attempts': len(lock['attempts']), 'sides': [{'origin': c['origin'], 'status': c['status'],
                   'reason': c.get('reason'), 'stages': len(c['stages'])} for c in checks]}, indent=2))
if process.returncode not in (0, 1) or any(c['status'] != 'PASS_BEHAVIOR_ONLY' for c in checks):
    raise SystemExit(1)
