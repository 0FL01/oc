"""Fresh exclusive Prompt007 after observed trailing-value whitespace correction."""
import ast
import os
from pathlib import Path
import sys

# Reuse only the immutable acquisition driver declarations, with fixed literal
# new acquisition paths. No old entrypoint, existing episode, or side-effect replay.
ROOT=Path('/home/opencode/.cache/opencode-tmp/opencode')
tree=ast.parse((ROOT/'vis36-prompt-capture-r6.py').read_bytes())
for node in ast.walk(tree):
    if isinstance(node,ast.Constant) and isinstance(node.value,str):
        node.value=node.value.replace('vis36-prompt-current-006','vis36-prompt-current-007').replace('prompt-wide-r6','prompt-wide-r7').replace('prompt-small-r6','prompt-small-r7').replace('Prompt006','Prompt007')
exec(compile(ast.fix_missing_locations(tree),str(Path(__file__)),'exec'))
