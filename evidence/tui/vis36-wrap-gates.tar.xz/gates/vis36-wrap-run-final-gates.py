"""Exclusive continuation after observed external observer timeout; no test change."""
import ast
from pathlib import Path
import subprocess

ROOT = Path('/home/opencode/.cache/opencode-tmp/opencode')
tree = ast.parse((ROOT/'vis36-mcp-tool-run-gates.py').read_bytes())
commands = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='commands' for t in n.targets))
commands = [('workspace-r1',['cargo','test','--workspace','--locked','--no-fail-fast','--','--test-threads=1'])] + [(label,argv) for label,argv in commands if label not in ('crates','workspace','clippy')]
for label,argv in commands:
    result = subprocess.run(['python3','-B',str(ROOT/'vis37-form-gate-20261012.py'),'vis36-wrap-'+label,*argv],cwd='/home/opencode/ai/oc')
    if result.returncode: raise SystemExit(result.returncode)
