"""Exclusive fresh form012: request-bound custom caret uses focused field color."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
ROOT = TMP/'vis37-form-current-012'
PROFILES = {'small': (80,24), 'wide': (120,40), 'tall': (160,48)}
profile = sys.argv[1]
columns, rows = PROFILES[profile]
output = ROOT/profile
if output.exists():
    raise SystemExit('refusing existing question/provider episode')
ROOT.mkdir(exist_ok=True)
owner = ROOT/'owner.txt'
if not owner.exists():
    with owner.open('x') as stream:
        stream.write('T44 owned fresh form012; same 18 real stages. Custom answer caret uses the focused Question field token through the existing terminal-color owner; normal/modal/Approval priority and all cell geometry preserved. No cell-FG/cursor-coordinate/clock normalization. Original001011 never replayed or overwritten.\n')
command = ['node',str(REPO/'scripts/tui_capture/capture.mjs'),
           '--reference',str(TMP/'t44-reference/package/bin/opencode'),
           '--oc',str(REPO/'target/debug/oc'),'--build-oc','true','--geometry','true',
           '--sample','short','--sidebar','hide','--tool-preview','true','--question-forms','true',
           '--columns',str(columns),'--rows',str(rows),'--output',str(output)]
env = os.environ.copy()
env.update(CARGO_BUILD_JOBS='3',RUST_TEST_THREADS='2',TMPDIR=str(TMP.parent))
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (ROOT/(profile+'.log')).open('xb') as log:
    result = subprocess.run(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    log.flush()
    os.fsync(log.fileno())
record = dict(profile=profile,command=command,started=started,exit_code=result.returncode,output=str(output))
with (ROOT/(profile+'.json')).open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
lock = json.loads((output/'capture.lock.json').read_bytes())
checks = [json.loads((output/side/'tool-preview-checks.json').read_bytes()) for side in ('upstream','oc')]
print(json.dumps({**record, 'captures':len(lock['captures']), 'attempts':len(lock['attempts']),
                  'sides':[dict(origin=c['origin'],status=c['status'],reason=c.get('reason'),stages=len(c['stages'])) for c in checks]}))
if result.returncode not in (0,1) or any(c['status'] != 'PASS_BEHAVIOR_ONLY' for c in checks):
    raise SystemExit(1)
