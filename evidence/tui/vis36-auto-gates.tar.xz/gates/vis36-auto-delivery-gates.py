"""Complete VIS36 command logs; bounded producer and independent manual inverse."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS, (384*1024**2, 384*1024**2))
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO/'evidence/tui'
sys.path.insert(0, str(REPO/'scripts'))
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
observer = module('sealed_vis36_manual_inverse', TMP/'vis37-form-independent-20261012-sole-verifier/owner_refinement.py')
check = observer.v.inverse
storage = module('actual_vis36_allocation_scope', REPO/'scripts/archive_failed_capture.py')
def quota():
    allocated = storage.owned_allocation()
    check.require(allocated <= storage.CAP and 'vis36-' in storage.PREFIXES, 'unchanged cap includes new VIS36 proofs')
    return dict(allocated_bytes=allocated, quota_bytes=storage.CAP, headroom_bytes=storage.CAP-allocated,
                prefixes=storage.PREFIXES, scope='All established evidence/tui prefixes PLUS vis36-; TMP separate')
final = check.load(OUT/'vis36-auto-after.json')
if sys.argv[1:] == ['facts']:
    print(json.dumps(dict(source=final['source'], totals=final['totals'], preserved=final['preserved_prior_proofs'],
                         receipt=check.load(OUT/'vis36-auto-proof.inventory.json'), quota=quota()), indent=2))
    raise SystemExit()
check.require(sys.argv[1:] == ['pack'], 'facts or exclusive pack')
proof = module('vis36_gate_producer', REPO/'scripts/retain_syntax_proof.py')
failed = {'vis36-auto-alias-red':101, 'vis36-cli-priority-red':101, 'vis36-cli-priority-green':101,
          'vis36-cli-priority-green-complete':101, 'vis36-cli-priority-events':101, 'vis36-mode-family-and-prompt':101,
          'vis36-permission-model-red':1, 'vis36-permission-model-green':1, 'vis36-permission-admitted-catalog-red':1,
          'vis36-auto-independent-facts':1, 'vis36-auto-independent-facts-generations':1,
          'vis36-auto-independent-after':1, 'vis36-auto-independent-after-qualified':1}
records = {p:check.load(p) for p in sorted(TMP.glob('vis37-form-gate-vis36-*.json'))}
labels = {r['label'] for r in records.values()}
required = {'vis36-auto-clippy-final','vis36-auto-workspace','vis36-auto-fmt','vis36-auto-debug-locked',
            'vis36-auto-debug-ordinary','vis36-auto-debug-help','vis36-auto-release-build','vis36-auto-release-help',
            'vis36-auto-python-qualified','vis36-auto-independent-after-complete','vis36-auto-docs-final',
            'vis36-auto-progress-final','vis36-mode-family-and-prompt-qualified','vis36-auto-owner-binary',
            'vis36-auto-alias-question','vis36-permission-admitted-catalog-green'}
check.require(required|set(failed) <= labels, 'complete current gates and every actual failed command retained')
paths = []
for path, record in records.items():
    check.require(record['exit_code'] == failed.get(record['label'], 0), 'honest actual result, no discarded failures')
    paths.extend((path, Path(record['log'])))
workspace = next(r for r in records.values() if r['label'] == 'vis36-auto-workspace')
check.require((workspace['passed'],workspace['failed'],workspace['ignored'],workspace['rust_targets']) == (1864,0,11,46), 'complete actual workspace totals')
release = [r for r in records.values() if r['label'].startswith('vis36-auto-release-') and r['rust_targets']]
check.require(len(release) == 7 and sum(r['passed'] for r in release) == 9 and not any(r['failed'] or r['ignored'] for r in release), 'nine actual release/resource cases')
py = next(r for r in records.values() if r['label'] == 'vis36-auto-python-qualified')
check.require(b'Ran 70 tests in ' in check.read_bytes(py['log']), 'complete root Python tests')
paths.extend((TMP/'vis37-form-gate-20261012.py', TMP/'vis36-auto-observer-refinement.py',
              TMP/'vis36-auto-observer-refinement-r2.py', Path(__file__)))
files = {'gates/'+p.name:check.read_bytes(p) for p in paths}
check.require(len(files) == len(paths), 'unique complete original members')
expected = {'gates/'+p.name:dict(path=str(p), bytes=len(files['gates/'+p.name]), sha256=check.sha(files['gates/'+p.name])) for p in paths}
proof.ROOTS = check.ROOTS = {'gates':TMP}
encoded, raw_sha, raw_bytes = proof.encode(files, {})
def inverse(data):
    raw, xz = check.inverse_xz(data)
    restored, meta = check.inverse_ustar(raw, expected)
    check.require(restored == files and check.sha(raw) == raw_sha, 'every original complete log/program byte, canonical TAR')
    return xz, meta
xz, meta = inverse(encoded)
archive, receipt = OUT/'vis36-auto-gates.tar.xz', OUT/'vis36-auto-gates.inventory.json'
check.require(not archive.exists() and not receipt.exists(), 'exclusive durable proof')
record = dict(version=1, codec='USTAR/single-XZ full original logs; independent manual inverse',
              archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=raw_sha, tar_bytes=raw_bytes,
              inventory=meta['inventory'], labels={r['label']:r['exit_code'] for r in records.values()},
              current_source=final['source'], helper_sha256=check.digest(Path(__file__)), xz=xz)
data = (json.dumps(record, indent=2)+'\n').encode()
check.require(storage.owned_allocation()+sum((n+4095)//4096*4096 for n in (len(encoded),len(data))) <= storage.CAP, 'actual allocated unchanged cap includes vis36-')
storage.durable(archive, encoded)
storage.durable(receipt, data)
inverse(check.read_bytes(archive))
print(json.dumps(dict(status='FULL_BYTE_EXACT_INDEPENDENT_GATES', archive_bytes=len(encoded), archive_sha256=check.sha(encoded),
                      inventory=meta['inventory'], actual_labels=len(records), memory=check.proc_memory(), quota=quota())))
