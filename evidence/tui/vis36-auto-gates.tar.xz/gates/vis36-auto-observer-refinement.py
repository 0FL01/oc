"""Refine only the sealed observer's capture-status field; preserve all metrics."""
import ast
from pathlib import Path
import sys
sys.dont_write_bytecode = True
PROGRAM = Path('/home/opencode/ai/oc/evidence/tui/vis36-auto-audit.py')
tree = ast.parse(PROGRAM.read_bytes(), filename=str(PROGRAM))
class Refine(ast.NodeTransformer):
    changes = 0
    reports = 0
    def visit_Compare(self, node):
        if (isinstance(node.left,ast.Call) and isinstance(node.left.func,ast.Attribute) and
            isinstance(node.left.func.value,ast.Name) and node.left.func.value.id=='item' and node.left.func.attr=='get' and
            len(node.left.args)==1 and isinstance(node.left.args[0],ast.Constant) and node.left.args[0].value=='status' and
            len(node.ops)==1 and isinstance(node.ops[0],ast.Eq) and len(node.comparators)==1 and
            isinstance(node.comparators[0],ast.Constant) and node.comparators[0].value=='CAPTURED_PERMISSION'):
            self.changes += 1
            return ast.parse("item.get('capture_status')=='CAPTURED'",mode='eval').body
        return self.generic_visit(node)
    def visit_Call(self, node):
        if (isinstance(node.func,ast.Name) and node.func.id=='save' and len(node.args)==2 and
            isinstance(node.args[0],ast.Name) and node.args[0].id=='AFTER'):
            self.reports += 1
            node.args[1] = ast.Call(func=ast.Name(id='refined_report',ctx=ast.Load()),args=[node.args[1]],keywords=[])
        return self.generic_visit(node)
refinement = Refine()
tree = ast.fix_missing_locations(refinement.visit(tree))
assert (refinement.changes,refinement.reports)==(1,1), 'one exact field correction and explicit provenance only'
context = {'__file__':str(PROGRAM),'__name__':'__main__'}
def refined_report(value):
    value['observer_refinement'] = {'path':__file__,'sha256':context['check'].digest(__file__),
        'cause':'Producer records capture_status=CAPTURED, not status=CAPTURED_PERMISSION; all 16 full pairs and inverse checks retained.'}
    return value
context['refined_report'] = refined_report
sys.argv = [str(PROGRAM),'after']
exec(compile(tree,str(PROGRAM),'exec'),context)
