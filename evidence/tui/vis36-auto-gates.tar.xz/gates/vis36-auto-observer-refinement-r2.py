"""Read all sixteen actual captured states, including Escape's separate frame."""
import ast
from pathlib import Path
import sys
sys.dont_write_bytecode = True
PROGRAM = Path('/home/opencode/ai/oc/evidence/tui/vis36-auto-audit.py')
tree = ast.parse(PROGRAM.read_bytes(), filename=str(PROGRAM))
STAGES = ('home auto-once-completed auto-shell-completed auto-mixed-completed settings-prompt '
          'settings-autoaccept settings-auto-first-escape auto-autoonce-completed settings-palette-filtered '
          'settings-auto-reopen settings-restored-prompt settings-prompt-first-escape auto-promptagain-completed '
          'auto-childroot-completed cli-restart auto-clirestart-completed').split()
class Refine(ast.NodeTransformer):
    changes = 0
    reports = 0
    def visit_Assign(self, node):
        if len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='stages':
            assert isinstance(node.value,ast.ListComp), 'only old observer stage-selection expression'
            self.changes += 1
            node.value = ast.List(elts=[ast.Constant(value=s) for s in STAGES],ctx=ast.Load())
        return self.generic_visit(node)
    def visit_Call(self, node):
        if (isinstance(node.func,ast.Name) and node.func.id=='save' and len(node.args)==2 and
            isinstance(node.args[0],ast.Name) and node.args[0].id=='AFTER'):
            self.reports += 1
            node.args[1] = ast.Call(func=ast.Name(id='refined_report',ctx=ast.Load()),args=[node.args[1]],keywords=[])
        return self.generic_visit(node)
refinement = Refine()
tree = ast.fix_missing_locations(refinement.visit(tree))
assert (refinement.changes,refinement.reports)==(1,1), 'one stage-selector correction and explicit provenance only'
context = {'__file__':str(PROGRAM),'__name__':'__main__'}
def refined_report(value):
    check = context['check']
    lock = context['lock']
    assert [p['scenario'] for p in lock['attempts'] if p['mode']=='grid']==['permission-'+s for s in STAGES], 'all actual recorded full pairs'
    value['observer_refinement'] = {'path':__file__,'sha256':check.digest(__file__),
        'earlier_refinement_sha256':check.digest(Path(__file__).with_name('vis36-auto-observer-refinement.py')),
        'cause':'Fourteen rows carry capture_status; two Escape frame rows are separately recorded. Recount all sixteen literal actual full pairs.'}
    return value
context['refined_report'] = refined_report
sys.argv = [str(PROGRAM),'after']
exec(compile(tree,str(PROGRAM),'exec'),context)
