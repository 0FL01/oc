"""Read-only factual observation of external build artifact disappearance."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
TMP=Path('/home/opencode/.cache/opencode-tmp/opencode')
REPO=Path('/home/opencode/ai/oc')
spec=importlib.util.spec_from_file_location('vis38_loss_audit',TMP/'vis38-durable-audit-20261013.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
before=audit.check.load(audit.BEFORE)
audit.preservation(before)
source=audit.current_source()
changed=[p for p in source if source[p]!=before['source'][p]]
assert set(changed)=={'crates/oc-adapters/src/storage_dcp_view.rs','crates/oc-adapters/src/storage_dcp_view_tests.rs',
    'scripts/tui_capture/dcp_display_audit.py','scripts/tui_capture/dcp_display_fixture.py','scripts/tui_capture/dcp_from_native.ts',
    'scripts/tui_capture/dcp_native_bridge.py','scripts/tui_capture/dcp_native_qualify.py','scripts/tui_capture/dcp_reference_capture.mjs'}
mem={p[0].rstrip(':'):int(p[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if len(p:=l.split())==3}
procs=subprocess.run(['ps','-u','1003','-o','comm='],capture_output=True,text=True,check=True).stdout.splitlines()
assert not any(p in ('cargo','rustc','chromium','chrome') for p in procs)
assert mem['MemAvailable']>=4*1024**3 and shutil.disk_usage(REPO).free>=4*1024**3 and os.getuid()==1003
assert not (REPO/'target').exists()
audit.save(TMP/'vis38-durable-artifact-loss-20261013.json',dict(status='OBSERVED_TARGET_DISAPPEARANCE_NO_CAUSE_ATTRIBUTED',
    last_existing_elf_record=str(TMP/'vis38-durable-current-008/producer-identity.json'),failed_preflight='vis38-durable-preflight-009',
    source=source,source_sha256=audit.check.producer_sha(source),changed_source=changed,
    prior_seals_preserved=True,mem_available_bytes=mem['MemAvailable'],disk_free_bytes=shutil.disk_usage(REPO).free,
    owned_cargo_capture_absent=True,next_step='fresh locked debug/release builds; do not replay provider/tool effects'))
