"""Exclusive VIS38 verifier: immutable declarations only, no legacy entrypoints."""
import ast
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import resource
import stat
import subprocess
import sys
import types

sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2,) * 2)
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO / 'evidence/tui'
BASE = '3afe7ff294061499ae14b70c636295481a65d466'
NAME = 'model-shell-tool-regression-002'
BEFORE = TMP / 'vis38-durable-baseline-20261013.json'

def declarations(path, functions, assignments=(), imports=False, replacements=None):
    tree = ast.parse(path.read_bytes(), filename=str(path))
    nodes = [n for n in tree.body if
             (imports and isinstance(n, (ast.Import, ast.ImportFrom))) or
             (isinstance(n, ast.FunctionDef) and n.name in functions) or
             (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in assignments for t in n.targets))]
    assert {n.name for n in nodes if isinstance(n, ast.FunctionDef)} == set(functions)
    for n in ast.walk(ast.Module(body=nodes, type_ignores=[])):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and replacements and n.value in replacements:
            n.value = replacements[n.value]
    return ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))

check = types.ModuleType('manual_vis38')
source = TMP / 'vis37-independent-20261012-sole-verifier/inverse_verifier.py'
names = {'require','sha','digest','read_bytes','load','canonical_sha','metadata','git','producer_sha',
         'proc_memory','quota','vli','inverse_xz','cstring','octal','make_header','path_ok','inverse_ustar','decode_png','compare_png'}
exec(compile(declarations(source, names, ('SCOPE','PREFIXES'), True), str(source), 'exec'), check.__dict__)
check.AS, check.FILE, check.TOTAL, check.OWNED = 384*1024**2, 16*1024**2, 128*1024**2, 1024**3
check.MEMBERS, check.XZ_DICT, check.XZ_DECODE = 2000, 16*1024**2, 32*1024**2
check.REPO, check.TEMP = REPO, TMP
check.PREFIXES = (*check.PREFIXES, 'vis36-')
check.ROOTS = {}
exec(compile(declarations(OUT / 'vis37-retention-recovery-audit.py', {'inverse_pax'}, replacements={'model-shell-001': NAME}), __file__, 'exec'), globals())

def current_source():
    names = check.git('ls-files','-z','--cached','--others','--exclude-standard','--',*check.SCOPE).decode().split('\0')
    return {n: check.digest(REPO/n) for n in sorted(set(names)) if n and (REPO/n).exists()}

def record(p):
    return dict(sha256=check.digest(p), metadata=check.metadata(p))

def save(path, value):
    data = (json.dumps(value, separators=(',',':'), ensure_ascii=False)+'\n').encode()
    assert len(data) <= check.FILE
    with path.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    print(json.dumps(dict(output=str(path),bytes=len(data),sha256=check.sha(data),memory=check.proc_memory(),quota=check.quota())))

def selected():
    root = OUT/NAME
    files, dirs = {}, {}
    for p in sorted([root,*root.rglob('*')]):
        m = p.lstat()
        assert m.st_uid == 1003 and not p.is_symlink()
        name = p.relative_to(OUT).as_posix()
        meta = [stat.S_IMODE(m.st_mode),m.st_uid,m.st_gid,m.st_mtime_ns]
        if stat.S_ISDIR(m.st_mode):
            dirs[name] = meta
        else:
            assert stat.S_ISREG(m.st_mode) and m.st_nlink == 1 and m.st_size <= check.FILE
            files[name] = dict(bytes=m.st_size,sha256=check.digest(p),metadata=meta)
    assert len(files)+len(dirs) <= 2000 and sum(r['bytes'] for r in files.values()) <= check.TOTAL
    return dict(files=files,directories=dirs)

def preservation(before):
    for group in ('prior','helpers'):
        for p,r in before[group].items():
            assert record(p) == r, p
    for p,r in before['original_files'].items():
        assert check.digest(p) == r[0] and check.metadata(p) == r[1], p
    for p,m in before['original_dirs'].items():
        assert check.metadata(p) == m, p

def baseline():
    assert check.git('rev-parse','HEAD').decode().strip() == BASE and os.getuid() == 1003
    assert not check.git('diff','--name-only') and not check.git('diff','--cached','--name-only')
    old = check.load(OUT/'vis36-mcp-tool-qualified-before.json')
    assert current_source() == old['source_and_elf']['source']
    assert check.producer_sha(current_source()) == '22ae1dbaaf6d2e5ba2c64bf5e4bfd3b4163aa32884613341aa290a60e997f84c'
    files, dirs = dict(old['legacy']['files']), dict(old['legacy']['directories'])
    helpers = dict(old['helpers'])
    for leaf in ('vis36-mcp-tool-qualified-before.json','vis36-mcp-tool-before.json'):
        value = check.load(OUT/leaf)
        for inv in value['original_inventory'].values():
            for row in inv['files'].values():
                files[row['path']] = [row['sha256'],row['original_metadata']]
            dirs.update(inv['directories'])
        helpers.update(value['helpers'])
    gates = check.load(OUT/'vis36-mcp-tool-gates.inventory.json')
    for row in gates['original_members'].values():
        files[row['path']] = [row['sha256'],row['original_metadata']]
    helpers.update({str(p):record(p) for p in sorted(TMP.glob('vis36-*.py'))})
    helpers.update({str(p):record(p) for p in sorted(TMP.glob('vis37-*.py'))})
    helpers.update({str(p):record(p) for p in sorted(OUT.glob('vis*.py'))})
    prior = {str(p):record(p) for p in sorted(OUT.iterdir()) if p.name.endswith(('.tar.xz','.inventory.json','.archived.json'))}
    statuses = {s:check.load(OUT/NAME/s/'tool-preview-checks.json')['status'] for s in ('oc','upstream')}
    assert statuses == dict(oc='FAILED',upstream='PASS_BEHAVIOR_ONLY')
    assert not check.git('ls-files','--',str((OUT/NAME).relative_to(REPO)))
    assert (OUT/NAME).stat().st_dev == TMP.stat().st_dev
    # Only literal obsolete diagnostics; current consumer pointers must remain elsewhere.
    assert b'model-shell-tool-regression-006' in check.git('show', BASE+':evidence/T44/report.md')
    value = dict(source=current_source(),elf={str(p):check.digest(p) for p in
        (REPO/'target/debug/oc',REPO/'target/release/oc',TMP/'t44-reference/package/bin/opencode')},
        prior=prior,helpers=helpers,original_files=files,original_dirs=dirs,selected=selected(),statuses=statuses,
        state=check.load(REPO/'progress/STATE.json'),quota=check.quota())
    preservation(value)
    save(BEFORE,value)

def archived():
    before = check.load(BEFORE)
    preservation(before)
    archive = OUT/(NAME+'.tar.xz')
    receipt = check.load(OUT/(NAME+'.archived.json'))
    raw,xz = check.inverse_xz(check.read_bytes(archive))
    inverse = inverse_pax(raw,before['selected'])
    assert receipt['archive_sha256'] == check.digest(archive) and receipt['statuses_unchanged'] == before['statuses']
    assert list((OUT/NAME).iterdir()) == [OUT/NAME/'ARCHIVED.md']
    assert b'FAILED / NOT_QUALIFIED' in check.read_bytes(OUT/NAME/'ARCHIVED.md')
    save(TMP/'vis38-durable-tool002-after-20261013.json',dict(inverse=inverse,xz=xz,archive_sha256=check.digest(archive),
        prior=len(before['prior']),files=len(before['original_files']),directories=len(before['original_dirs']),memory=check.proc_memory(),quota=check.quota()))

if __name__ == '__main__':
    {'baseline':baseline,'archived':archived}[sys.argv[1]]()
