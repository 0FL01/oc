"""Preserve failed r1; correct the source-traced current consumer document."""
import ast
from pathlib import Path
SOURCE = Path('/home/opencode/.cache/opencode-tmp/opencode/vis38-durable-audit-20261013.py')
tree = ast.parse(SOURCE.read_bytes(),filename=str(SOURCE))
for n in ast.walk(tree):
    if isinstance(n,ast.Constant) and n.value == ':evidence/T44/report.md':
        n.value = ':evidence/tui/model-shell.md'
exec(compile(ast.fix_missing_locations(tree),str(SOURCE),'exec'))
