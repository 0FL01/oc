"""Run actual documented release gate arguments sequentially, fresh receipts."""
import json
from pathlib import Path
import subprocess
import sys
TMP=Path('/home/opencode/.cache/opencode-tmp/opencode')
for label in ('startup','term01','panic','vis31','s07','vis38-isolated','aud32'):
    previous=json.loads((TMP/f'vis37-form-gate-vis36-mcp-tool-release-{label}.json').read_bytes())
    assert previous['exit_code']==0 and previous['command'][:4]==['cargo','test','--locked','--release']
    command=['python3',str(TMP/'vis37-form-gate-20261012.py'),'vis38-durable-release-'+label,*previous['command']]
    subprocess.run(command,check=True)
