"""Fresh approved TMP acquisition and immutable producer source identity."""
import datetime
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

REPO=Path('/home/opencode/ai/oc')
TMP=Path('/home/opencode/.cache/opencode-tmp/opencode')
spec=importlib.util.spec_from_file_location('vis38_audit',TMP/'vis38-durable-audit-20261013.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
attempt=sys.argv[1]
assert attempt in ('001','002','003','004','005','006') and os.getuid()==1003
root=TMP/('vis38-durable-current-'+attempt)
assert not root.exists()
mem={p[0].rstrip(':'):int(p[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if len(p:=line.split())==3}
disk=shutil.disk_usage(REPO).free
procs=subprocess.run(['ps','-u','1003','-o','comm='],text=True,capture_output=True,check=True).stdout.splitlines()
assert mem['MemAvailable']>=4*1024**3 and disk>=4*1024**3
assert not any(p in ('cargo','rustc','chromium','chrome') for p in procs)
root.mkdir()
(root/'producer').mkdir()
paths=[REPO/'scripts/archive_failed_capture.py',REPO/'scripts/test_archive_failed_capture.py',
       *sorted((REPO/'scripts/tui_capture').glob('dcp_*'))]
assert all(p.is_file() for p in paths)
for p in paths:
    with (root/'producer'/p.name).open('xb') as f:f.write(p.read_bytes())
source=audit.current_source()
record=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),UID=os.getuid(),
    actual_producer_HEAD=audit.check.git('rev-parse','HEAD').decode().strip(),source=source,
    source_count=len(source),source_sha256=audit.check.producer_sha(source),
    ELF={str(p):audit.check.digest(p) for p in (REPO/'target/debug/oc',REPO/'target/release/oc',TMP/'t44-reference/package/bin/opencode')},
    mem_available_bytes=mem['MemAvailable'],disk_free_bytes=disk,allocation=audit.check.quota())
audit.save(root/'producer-identity.json',record)
print(json.dumps(dict(root=str(root),source_count=len(source),source_sha256=record['source_sha256'],ELF=record['ELF'])))
