"""Exclusive final VIS38 compression preflight; bounded metadata, no capture/build."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode=True
TMP=Path('/home/opencode/.cache/opencode-tmp/opencode')
spec=importlib.util.spec_from_file_location('vis38_preflight_declarations',TMP/'vis38-durable-audit-20261013.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
check=audit.check
assert os.getuid()==1003
mem={r.split(':')[0]:int(r.split()[1])*1024 for r in Path('/proc/meminfo').read_text().splitlines()}
disk=shutil.disk_usage(audit.REPO).free
assert mem['MemAvailable']>=4*1024**3 and disk>=4*1024**3
names=subprocess.check_output(['ps','-eo','comm='],text=True).splitlines()
assert not [n for n in names if n.strip() in ('cargo','rustc','chromium','chrome')]
assert not (audit.OUT/'vis36-vis38-durable-gates.tar.xz').exists()
assert not (audit.OUT/'vis36-vis38-durable-gates.inventory.json').exists()
print(json.dumps(dict(uid=os.getuid(),MemAvailable_bytes=mem['MemAvailable'],disk_free_bytes=disk,
    active_Cargo_or_capture=0,quota=check.quota(),memory=check.proc_memory())))
