"""Fresh exclusive Prompt006: Generic/MCP primitive summary qualification."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
ROOT = TMP / 'vis36-prompt-current-006'
PROFILES = {'wide': ('prompt-wide-r6', 121), 'small': ('prompt-small-r6', 79)}
assert os.getuid() == 1003 and len(sys.argv) == 2 and sys.argv[1] in PROFILES
profile, columns = PROFILES[sys.argv[1]]
OWNER = 'T44 Generic summary Prompt006. Actual full same-profile Native/Original 51-stage Prompt qualification after aggregate-bounded primitive summary correction. Existing permissions, structured previews, grant/tool identities, RAW/history, busy-close refusal, successful Shell card and resource/security bounds preserved. All previous episodes/helpers/seals immutable. Local isolated effects only; no paid API/replay/crop/mask/tolerance/golden/clock or cursor normalization/PNG reencoding. Behavior and full comparisons are separate. T44 ACTIVE_NOT_PASS.\n'
if not ROOT.exists():
    ROOT.mkdir()
    with (ROOT / 'owner.txt').open('x') as output:
        output.write(OWNER)
assert ROOT.is_dir() and ROOT.stat().st_uid == 1003 and (ROOT / 'owner.txt').read_text() == OWNER
assert not (ROOT / profile).exists()
command = ['node', str(REPO / 'scripts/tui_capture/capture.mjs'),
           '--reference', str(TMP / 't44-reference/package/bin/opencode'),
           '--oc', str(REPO / 'target/debug/oc'), '--build-oc', 'true',
           '--geometry', 'true', '--sample', 'short', '--sidebar', 'hide',
           '--permission', 'true', '--permission-mode', 'prompt',
           '--columns', str(columns), '--rows', '40', '--output', str(ROOT / profile)]
env = {**os.environ, 'CARGO_BUILD_JOBS': '3', 'RUST_TEST_THREADS': '2', 'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(TMP)}
started = time.monotonic_ns()
with (ROOT / (profile + '.log')).open('xb') as output:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
assert (ROOT / (profile + '.log')).stat().st_size <= 16*1024**2
facts = {'command': command, 'exit_code': result.returncode, 'elapsed_ns': time.monotonic_ns()-started}
with (ROOT / (profile + '.json')).open('x') as output:
    json.dump(facts, output, indent=2); output.write('\n')
checks = {}
for side in ('upstream', 'oc'):
    path = ROOT / profile / side / 'permission-checks.json'
    if path.exists(): checks[side] = json.loads(path.read_bytes())
print(json.dumps({**facts, 'observed_behavior': {s:d['status'] for s,d in checks.items()},
                  'observed_checks': {s:len(d['checks']) for s,d in checks.items()}}))
raise SystemExit(0 if result.returncode in (0,1) and len(checks)==2 and all(d['status']=='PASS' for d in checks.values()) else 1)
