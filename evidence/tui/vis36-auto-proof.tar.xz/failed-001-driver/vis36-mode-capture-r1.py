#!/usr/bin/env python3
"""Exclusive VIS36 CLI-auto Settings/child/restart paired acquisition."""
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/home/opencode/ai/oc')
TMP = Path(os.environ['TMPDIR']) / 'opencode'
ROOT = TMP / 'vis36-mode-current-001'
assert os.getuid() == 1003 and not ROOT.exists()
ROOT.mkdir()
(ROOT / 'owner.txt').write_text('T44 VIS36 CLI-auto owner priority; canonical --auto, saved Prompt, actual Settings/palette, root/child Once, Deny, restart. No old episode replay, masks, crop, clock/cursor normalization or qualification weakening.\n')
command = ['node', str(REPO / 'scripts/tui_capture/capture.mjs'),
           '--reference', str(TMP / 't44-reference/package/bin/opencode'),
           '--oc', str(REPO / 'target/debug/oc'), '--build-oc', 'true',
           '--geometry', 'true', '--sample', 'short', '--sidebar', 'hide',
           '--permission', 'true', '--permission-mode', 'auto-cli',
           '--columns', '121', '--rows', '40', '--output', str(ROOT / 'cli-wide')]
env = {**os.environ, 'CARGO_BUILD_JOBS': '3', 'RUST_TEST_THREADS': '2',
       'PYTHONDONTWRITEBYTECODE': '1'}
started = time.monotonic_ns()
with (ROOT / 'cli-wide.log').open('xb') as log:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
facts = {'command': command, 'exit_code': result.returncode,
         'elapsed_ns': time.monotonic_ns() - started}
with (ROOT / 'cli-wide.json').open('x') as output:
    json.dump(facts, output, indent=2)
    output.write('\n')
checks = {side: json.loads((ROOT / 'cli-wide' / side / 'permission-checks.json').read_text())
          for side in ['upstream', 'oc']}
print(json.dumps({**facts, 'behavior': {side: data['status'] for side, data in checks.items()},
                  'stages': {side: len(data['checks']) for side, data in checks.items()}}))
raise SystemExit(0 if result.returncode in (0, 1) and all(data['status'] == 'PASS' for data in checks.values()) else 1)
