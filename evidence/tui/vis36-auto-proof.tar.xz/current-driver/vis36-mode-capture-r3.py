#!/usr/bin/env python3
"""Fresh VIS36 episode after strict fixture config/catalog regressions."""
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/home/opencode/ai/oc')
TMP = Path(os.environ['TMPDIR']) / 'opencode'
ROOT = TMP / 'vis36-mode-current-003'
assert os.getuid() == 1003 and not ROOT.exists()
ROOT.mkdir()
(ROOT / 'owner.txt').write_text('T44 VIS36 current003: actual upstream providers and native provider config shapes; explicit GPT patch model and advertised canonical shell(command). Attempts001/002 preserved including real prefix effect and strict rejections. No execution/admission bypass, source replay, masks or clock normalization. Actual CLI priority Settings/root/child Once/Deny/restart.\n')
command = ['node', str(REPO / 'scripts/tui_capture/capture.mjs'),
           '--reference', str(TMP / 't44-reference/package/bin/opencode'),
           '--oc', str(REPO / 'target/debug/oc'), '--build-oc', 'true',
           '--geometry', 'true', '--sample', 'short', '--sidebar', 'hide',
           '--permission', 'true', '--permission-mode', 'auto-cli',
           '--columns', '121', '--rows', '40', '--output', str(ROOT / 'cli-wide-r3')]
env = {**os.environ, 'CARGO_BUILD_JOBS': '3', 'RUST_TEST_THREADS': '2',
       'PYTHONDONTWRITEBYTECODE': '1'}
started = time.monotonic_ns()
with (ROOT / 'cli-wide-r3.log').open('xb') as log:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
facts = {'command': command, 'exit_code': result.returncode,
         'elapsed_ns': time.monotonic_ns() - started}
with (ROOT / 'cli-wide-r3.json').open('x') as output:
    json.dump(facts, output, indent=2)
    output.write('\n')
checks = {}
for side in ['upstream', 'oc']:
    path = ROOT / 'cli-wide-r3' / side / 'permission-checks.json'
    if path.exists():
        checks[side] = json.loads(path.read_text())
print(json.dumps({**facts, 'observed_behavior': {side: data['status'] for side, data in checks.items()},
                  'observed_checks': {side: len(data['checks']) for side, data in checks.items()}}))
raise SystemExit(0 if result.returncode in (0, 1) and len(checks) == 2 and
                 all(data['status'] == 'PASS' for data in checks.values()) else 1)
