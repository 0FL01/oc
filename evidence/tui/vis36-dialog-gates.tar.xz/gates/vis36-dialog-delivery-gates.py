"""Complete Dialog geometry/hint command bytes; bounded manual inverse."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS, (384*1024**2, 384*1024**2))
REPO, TMP = Path('/home/opencode/ai/oc'), Path('/home/opencode/.cache/opencode-tmp/opencode')
OUT = REPO/'evidence/tui'
sys.path.insert(0, str(REPO/'scripts'))
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
observer = module('dialog_manual_inverse', TMP/'vis37-form-independent-20261012-sole-verifier/owner_refinement.py')
check = observer.v.inverse
storage = module('dialog_actual_allocation', REPO/'scripts/archive_failed_capture.py')
def quota():
    allocated = storage.owned_allocation()
    check.require(allocated <= storage.CAP and 'vis36-' in storage.PREFIXES, 'unchanged additive cap')
    return dict(allocated_bytes=allocated, quota_bytes=storage.CAP, headroom_bytes=storage.CAP-allocated, prefixes=storage.PREFIXES)
final = check.load(OUT/'vis36-dialog-final-after.json')
if sys.argv[1:] == ['facts']:
    print(json.dumps(dict(source=final['source'], totals=final['totals'], preserved=final['preserved_prior_proofs'],
                         receipt=check.load(OUT/'vis36-dialog-r6-proof.inventory.json'), quota=quota()), indent=2))
    raise SystemExit()
check.require(sys.argv[1:] == ['pack'], 'facts or exclusive pack')
proof = module('dialog_gate_producer', REPO/'scripts/retain_syntax_proof.py')
failed = {name:101 for name in ('vis36-dialog-center-red','vis36-dialog-center-red-complete',
                             'vis36-dialog-hint-red','vis36-dialog-hint-red-complete')}
failed.update({'vis36-dialog-before':1, 'vis36-dialog-before-complete':1})
records = {p:check.load(p) for p in sorted(TMP.glob('vis37-form-gate-vis36-dialog-*.json'))}
labels = {r['label'] for r in records.values()}
required = {'vis36-dialog-center-green','vis36-dialog-center-owner','vis36-dialog-center-tui',
            'vis36-dialog-hint-green','vis36-dialog-hint-owner','vis36-dialog-clippy-final','vis36-dialog-python-final',
            'vis36-dialog-workspace','vis36-dialog-fmt','vis36-dialog-debug-locked','vis36-dialog-debug-ordinary',
            'vis36-dialog-debug-help','vis36-dialog-release-build','vis36-dialog-release-help',
            'vis36-dialog-before-qualified','vis36-dialog-pack','vis36-dialog-audit','vis36-dialog-after',
            'vis36-dialog-r6-before','vis36-dialog-r6-measure','vis36-dialog-r6-pack','vis36-dialog-r6-audit','vis36-dialog-r6-after',
            'vis36-dialog-model008-preflight','vis36-dialog-model008-before','vis36-dialog-model008-archive','vis36-dialog-model008-after',
            'vis36-dialog-docs-final','vis36-dialog-progress-final'}
check.require(required|set(failed) <= labels, 'all actual gates, no discarded failures')
paths = []
for path, record in records.items():
    check.require(record['exit_code'] == failed.get(record['label'], 0), 'honest actual command status')
    paths.extend((path, Path(record['log'])))
workspace = next(r for r in records.values() if r['label'] == 'vis36-dialog-workspace')
check.require((workspace['passed'],workspace['failed'],workspace['ignored'],workspace['rust_targets']) == (1866,0,11,46), 'complete workspace totals')
release = [r for r in records.values() if r['label'].startswith('vis36-dialog-release-') and r['rust_targets'] and r['passed']]
check.require(len(release) == 7 and sum(r['passed'] for r in release) == 9 and not any(r['failed'] or r['ignored'] for r in release), 'nine actual release/resource cases')
for label in ('vis36-dialog-release-s07','vis36-dialog-release-dcp-archive'):
    zero = next(r for r in records.values() if r['label'] == label)
    check.require(zero['passed'] == 0 and zero['failed'] == 0, 'unqualified exact filter run honestly retained')
py = next(r for r in records.values() if r['label'] == 'vis36-dialog-python-final')
check.require(b'Ran 70 tests in ' in check.read_bytes(py['log']), 'complete root Python tests')
paths.extend((TMP/'vis37-form-gate-20261012.py', TMP/'vis36-model008-archival-audit.py', Path(__file__)))
files = {'gates/'+p.name:check.read_bytes(p) for p in paths}
check.require(len(files) == len(paths), 'unique complete original members')
expected = {'gates/'+p.name:dict(path=str(p), bytes=len(files['gates/'+p.name]), sha256=check.sha(files['gates/'+p.name])) for p in paths}
proof.ROOTS = check.ROOTS = {'gates':TMP}
encoded, raw_sha, raw_bytes = proof.encode(files, {})
def inverse(data):
    raw, xz = check.inverse_xz(data)
    restored, meta = check.inverse_ustar(raw, expected)
    check.require(restored == files and check.sha(raw) == raw_sha, 'every complete original log/program byte')
    return xz, meta
xz, meta = inverse(encoded)
archive, receipt = OUT/'vis36-dialog-gates.tar.xz', OUT/'vis36-dialog-gates.inventory.json'
check.require(not archive.exists() and not receipt.exists(), 'exclusive durable proof')
record = dict(version=1, codec='USTAR/single-XZ full original logs; independent manual inverse',
              archive_sha256=check.sha(encoded), archive_bytes=len(encoded), tar_sha256=raw_sha, tar_bytes=raw_bytes,
              inventory=meta['inventory'], labels={r['label']:r['exit_code'] for r in records.values()},
              current_source=final['source'], helper_sha256=check.digest(Path(__file__)), xz=xz)
data = (json.dumps(record, indent=2)+'\n').encode()
check.require(storage.owned_allocation()+sum((n+4095)//4096*4096 for n in (len(encoded),len(data))) <= storage.CAP, 'actual additive allocation in unchanged cap')
storage.durable(archive, encoded)
storage.durable(receipt, data)
inverse(check.read_bytes(archive))
print(json.dumps(dict(status='FULL_BYTE_EXACT_INDEPENDENT_DIALOG_GATES', archive_bytes=len(encoded), archive_sha256=check.sha(encoded),
                      inventory=meta['inventory'], actual_labels=len(records), memory=check.proc_memory(), quota=quota())))
