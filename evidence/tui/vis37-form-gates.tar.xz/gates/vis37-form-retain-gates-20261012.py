"""Exclusive retention of already-completed offline gates, not a capture replay."""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys

sys.dont_write_bytecode = True
REPO = Path('/home/opencode/ai/oc')
TMP = Path('/home/opencode/.cache/opencode-tmp/opencode')
sys.path.insert(0, str(REPO / 'scripts'))
import retain_syntax_proof as proof

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
proof.require(os.getuid() == 1003, 'dedicated non-root owner')
proof.ROOTS = {'gates': TMP}
archive = REPO / 'evidence/tui/vis37-form-gates.tar.xz'
receipt = REPO / 'evidence/tui/vis37-form-gates.inventory.json'
proof.require(not archive.exists() and not receipt.exists(), 'exclusive gate delivery')
expected = {'final-workspace': (1856, 11, 46),
            **{name: (0, 0, 0) for name in ('final-fmt', 'final-clippy',
               'final-debug-locked', 'final-debug-ordinary', 'final-debug-help',
               'final-release-build', 'final-release-help', 'final-root-python',
               'final-nested-question', 'final-js', 'final-docs', 'final-progress',
               'final-code-size', 'final-captured-debug')},
            'final-release-startup': (2, 0, 1), 'final-release-term01': (1, 0, 1),
            'final-release-panic': (1, 0, 1), 'final-release-vis31': (2, 0, 1),
            'final-release-s07': (1, 0, 1), 'final-release-vis38': (1, 0, 1),
            'final-release-aud32': (1, 0, 1)}
files, gates = {}, []
for label, counts in expected.items():
    name = 'vis37-form-gate-' + label
    meta = json.loads((TMP / (name + '.json')).read_bytes())
    proof.require(meta['label'] == label and meta['exit_code'] == 0 and meta['failed'] == 0
                  and (meta['passed'], meta['ignored'], meta['rust_targets']) == counts,
                  'actual complete gate ' + label)
    log = (TMP / (name + '.log')).read_bytes()
    proof.require(len(log) == meta['log_bytes'] and len(log) <= proof.MAX_FILE, 'complete bounded log')
    if label == 'final-root-python':
        proof.require(b'Ran 63 tests' in log and log.rstrip().endswith(b'OK'), 'root Python actual63')
    if label == 'final-nested-question':
        proof.require(b'Ran 2 tests' in log and log.rstrip().endswith(b'OK'), 'nested Python actual2')
    gates.append({**meta, 'log_sha256': proof.digest(log)})
    for suffix in ('.json', '.log'):
        files['gates/' + name + suffix] = (TMP / (name + suffix)).read_bytes()
for label in ('r4-measure-default-detailed', 'r4-measure-strong', 'r4-independent-recount'):
    for suffix in ('.json', '.log'):
        path = TMP / ('vis37-form-gate-' + label + suffix)
        files['gates/' + path.name] = path.read_bytes()
helper = Path(__file__)
files['gates/' + helper.name] = helper.read_bytes()
files['gates/vis37-form-gate-20261012.py'] = (TMP / 'vis37-form-gate-20261012.py').read_bytes()
independent = json.loads((TMP / 'vis37-form-r4-independent.json').read_bytes())
manifest = json.loads((TMP / 'vis37-form-current-004/small/source-manifest.json').read_bytes())
proof.require(len(manifest) == 713, 'captured source count')
for relative, digest in manifest.items():
    proof.require(proof.digest((REPO / relative).read_bytes()) == digest, 'current captured source ' + relative)
for side, fact in independent['elf'].items():
    with Path(fact['path']).open('rb') as stream:
        proof.require(hashlib.file_digest(stream, 'sha256').hexdigest() == fact['sha256'], 'current captured ELF ' + side)
encoded, tar_sha, tar_bytes = proof.encode(files, {})
restored, aliases, restored_sha, restored_bytes = proof.unpack(encoded)
proof.require(restored == files and not aliases and restored_sha == tar_sha and restored_bytes == tar_bytes,
              'all complete gate bytes inverse')
allocated = proof.storage.owned_allocation()
record = {'status': 'CURRENT_CODE_GATES_PASS_CAPTURE004_RETENTION_BLOCKED_T44_NOT_PASS',
          'archive_sha256': proof.digest(encoded), 'archive_bytes': len(encoded),
          'tar_sha256': tar_sha, 'tar_bytes': tar_bytes, 'files': len(files),
          'logical_bytes': sum(map(len, files.values())), 'gates': gates,
          'source_manifest_sha256': independent['source_manifest_sha256'],
          'captured_elf': independent['elf'], 'quota_before': allocated,
          'quota_cap': proof.storage.CAP,
          'scope': 'Complete offline gate logs only; no004 images/protocol/source retained by this gate archive.'}
metadata = (json.dumps(record, indent=2) + '\n').encode()
extra = sum((len(data) + 4095) // 4096 * 4096 for data in (encoded, metadata))
proof.require(len(encoded) <= proof.MAX_FILE and len(metadata) <= proof.MAX_FILE
              and allocated + extra <= proof.storage.CAP, 'unchanged gate/evidence bounds')
proof.storage.durable(archive, encoded)
proof.storage.durable(receipt, metadata)
proof.require(archive.read_bytes() == encoded and receipt.read_bytes() == metadata, 'durable gate reopen')
print(json.dumps({'archive_bytes': len(encoded), 'archive_sha256': proof.digest(encoded),
                  'receipt_bytes': len(metadata), 'receipt_sha256': proof.digest(metadata),
                  'files': len(files), 'quota_after': proof.storage.owned_allocation(),
                  'source_manifest_sha256': independent['source_manifest_sha256'],
                  'workspace': expected['final-workspace'], 'release_tests': 9}, sort_keys=True))
