"""Fresh exclusive Prompt008: actual full source-space wrapping qualification."""
import ast
from pathlib import Path

ROOT = Path('/home/opencode/.cache/opencode-tmp/opencode')
tree = ast.parse((ROOT / 'vis36-prompt-capture-r6.py').read_bytes())
for node in ast.walk(tree):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        node.value = node.value.replace('vis36-prompt-current-006', 'vis36-prompt-current-008').replace('prompt-wide-r6', 'prompt-wide-r8').replace('prompt-small-r6', 'prompt-small-r8').replace('Prompt006', 'Prompt008').replace('aggregate-bounded primitive summary correction', 'source-space wrap correction with unchanged aggregate bounds')
exec(compile(ast.fix_missing_locations(tree), str(Path(__file__)), 'exec'))
