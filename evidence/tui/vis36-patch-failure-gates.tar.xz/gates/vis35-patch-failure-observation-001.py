"""Read-only structured-cell observation of the preserved mixed Patch failure."""
import json
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
root = Path('/home/opencode/.cache/opencode-tmp/opencode/vis36-mode-current-008')
for profile in ('cli-wide-r8', 'cli-small-r8'):
    for side in ('oc', 'upstream'):
        path = root/profile/side/'permission-auto-mixed-completed.cells.json'
        grid = json.loads(path.read_bytes())
        rows = [''.join(c['symbol'] for c in row) for row in grid['cells']]
        headers = [y for y, text in enumerate(rows) if '# Patch failed' in text]
        assert len(headers) == 1
        header = headers[0]
        x = rows[header].index('# Patch failed')
        border = x - 3
        top, bottom = header - 1, header + 1
        while bottom < grid['rows'] and grid['cells'][bottom][border]['symbol'] == '┃':
            bottom += 1
        assert grid['cells'][top][border]['symbol'] == '┃'
        print(json.dumps(dict(profile=profile, side=side, header=(x, header), card_rows=[
            dict(y=y, text=rows[y].rstrip(), padding=grid['cells'][y][border+1:border+3])
            for y in range(top, bottom)]), ensure_ascii=False))
